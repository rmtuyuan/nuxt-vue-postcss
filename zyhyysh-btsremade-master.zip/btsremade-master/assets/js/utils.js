// import parseJson from 'parse-json'

export function findCurrentCategory (nav, path) {
  return nav.filter(c => path.match(c.absname)).pop()
}

export function findCurrentSection (nav, path, upLevel) {
  path = path.replace(/^\/(zh|en)\//, '/').split('?')[0]

  if (typeof upLevel === 'number' && upLevel <= 0) {
    const pathArr = path.split('/')
    path = `${pathArr.slice(0, pathArr.length + upLevel).join('/')}`
  }

  return nav.reduce((res, item) => {
    if (res.found) {
      return res
    } else if (item.absname === path) {
      return {found: true, nav: item}
    } else if ('children_nav' in item) {
      return findCurrentSection(item.children_nav, path)
    } else {
      return res
    }
  }, {found: false, nav: null})
}

export function getCategoryOfSection (nav, id) {
  return nav.reduce((res, item) => {
    if (res.found) {
      return res
    } else if (item.id === id) {
      return {found: true, id: item.id}
    } else if ('children_nav' in item) {
      const result = getCategoryOfSection(item.children_nav, id)
      if (result.found) {
        return {found: true, id: item.id}
      } else {
        return res
      }
    } else {
      return res
    }
  }, {found: false, category: null})
}

export function getLinkById (nav, id) {
  return nav.reduce((res, item) => {
    if (res.found) {
      return res
    } else if (item.id === id) {
      return {found: true, link: item.absname, category: item.name_zh}
    } else if ('children_nav' in item) {
      const result = getLinkById(item.children_nav, id)
      if (result.found) {
        return {'found': true, link: result.link, category: item.name_zh}
      } else {
        return res
      }
    } else {
      return res
    }
  }, {found: false, link: '/', category: 'home'})
}

// export function readPageData (n) {
//   function delHtmlTag (str) {
//     return str.replace(/(<p[^>]*>)|(<\/p>)/gi, '') // 去掉所有的html标记
//   }

//   var Node = document.querySelector('.article-container')

//   let read = function () {
//     n.child.forEach(function (val) {
//       if (val.child) {
//         val.child.forEach(function (value) {
//           if (value.tag === 'img') {
//             let Img = document.createElement('img')
//             Img.src = value.attr.src
//             Node.appendChild(Img)
//           } else if (value.tag === 'p') {
//             if (value.child[0].text === '请输入文本') { } else {
//               var P = document.createElement('p')
//               // let html = transfer.json2html(value)
//               let html = json2html(value)
//               // console.log(delHtmlTag(html))
//               P.innerHTML = delHtmlTag(html)
//               Node.appendChild(P)
//             }
//           }
//         })
//       }
//     })
//   }
//   read()
// }

export function parseJSON (raw) {
  const json = JSON || window.JSON
  let obj = {}

  try {
    obj = json.parse(raw)
  } catch (e) {
    console.error('[JSON] Parse error', e)
  }

  return obj
}

export function readContent (raw, acceptTags, acceptAttrs, ignoreClasses) {
  let obj = {child: []}
  acceptTags = acceptTags || ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'img', 'b', 'font', 'i', 'ol', 'ul', 'li', 'a', 'embed']
  acceptAttrs = acceptAttrs || ['src', 'style', 'size', 'class', 'href', 'type', 'width', 'height']
  ignoreClasses = ignoreClasses || []
  ignoreClasses = ignoreClasses.concat(['text-handle_list', 'paragraph'])

  const json = JSON || window.JSON

  try {
    obj = json.parse(raw)
  } catch (e) {
    console.error('parse json error', e)
  }

  function convertAttr (attr, isImg) {
    isImg = isImg === undefined ? false : isImg
    if (attr) {
      return Object.keys(attr).map(key => {
        if (acceptAttrs.includes(key)) {
          if (isImg && key === 'src') {
            return `${key}="${attr[key]}?x-oss-process=image/resize,w_1200"`
          }

          return `${key}="${attr[key]}"`
        } else {
          return ''
        }
      }).join(' ')
    }

    return ''
  }

  function read (node, isp) {
    if (node.node === 'text') {
      /* 文字节点过滤后直接输出 */
      if (isp && 'text' in node && !node.text.match(/(请输入文本|undefined)/g)) {
        return `${node.text}`
      } else {
        return ''
      }
    } else if (node.node === 'root') {
      /* 根结点遍历递归子节点 */
      return node.child.map(c => {
        return read(c, isp)
      }).join('')
    } else if (node.node === 'element') {
      /* 元素节点，判断是否需要显示节点 */
      if ('attr' in node && 'class' in node.attr && ignoreClasses.includes(node.attr.class)) {
        return ''
      }

      let nodePrefix = ''
      let nodeAffix = ''
      let nodeChild = ''

      if (nodePrefix || acceptTags.includes(node.tag)) {
        nodePrefix = `<${node.tag} ${convertAttr(node.attr, node.tag === 'img')}>`
        nodeAffix = `</${node.tag}>`
      }

      if ('child' in node) {
        nodeChild = node.child.map(c => {
          return read(c, isp || acceptTags.includes(node.tag))
        }).join('')
      }

      return `${nodePrefix}${nodeChild}${nodeAffix}`
    }
  }

  return read(obj, false)
}
