import Vue from 'vue'
import Vuex from 'vuex'
import querystring from 'querystring'
import { getLinkById } from '../assets/js/utils.js'

Vue.use(Vuex)

const store = () => new Vuex.Store({
  state: {
    nav: [],
    tempNavInfo: {
      8: {},
      9: {},
      10: {},
      11: {},
      12: {},
      13: {},
      14: {},
      15: {},
      16: {},
      17: {},
      18: {},
      19: {},
      20: {},
      21: {},
      22: {},
      23: {},
      24: {},
      26: {},
      27: {},
      28: {},
      29: {},
      30: {},
      31: {},
      32: {},
      33: {},
      34: {},
      35: {},
      37: {},
      39: {},
      40: {
        sub_name_zh: '连接与共生',
        sub_name_en: 'Connection and Coexistence',
        descp_zh: ['2015年北京国际设计周——“白塔寺再生计划”以“连接与共生”为主题，通过40余项设计展览展示活动、论坛，以及强化的可视化项目和线上线下一体化平台，将成为领略和重新发现该区域丰富文化、独一无二城市结构和历史的出发点。'],
        descp_en: ['Reflecting the theme of “connection and coexistence”, and involving over 40 design exhibition and display events and forums, as well as enhanced visualization projects and an online-and-offline-integrated platform, 2015 Beijing Design Week – “Baitasi Remade” will become the starting point to appreciate and rediscover the diverse culture, unique urban structure, and history in this area.'],
        imgs: ['/cover_bjdw2015.jpg'],
        cover: '/bj_bjdw2015@2x.jpg'
      },
      41: {
        sub_name_zh: '城市研习·共享未来',
        sub_name_en: 'The Future of Sharing as Urban Making',
        descp_zh: ['2016白塔寺再生计划以设计周为开端，进一步促进现有社区与未来的对话以及专业人士之间的互动，涉及人群将涵盖来自经济和学术领域的专家、设计领域的创意先锋以及当地居民。'],
        descp_en: ['First launched with the 2015 edition of Beijing Design Week in the context of Baitasi historic hutong district, Baitasi Remade is a program of urban renewal tasked to integrate communal engagement, architectural and infrastructural upgrading by way of soft-strategies of development taking design thinking and cultural making at their heart.'],
        imgs: ['/cover_bjdw2016.jpg'],
        cover: '/bj_bjdw2016@2x.jpg'
      },
      42: {
        sub_name_zh: '新邻里关系',
        sub_name_en: 'New Neighborhoods',
        descp_zh: [''],
        imgs: ['/cover_bjdw2017.jpg'],
        cover: '/bj_bjdw2017@2x.jpg'
      },
      43: {
        sub_name_zh: '北京小院儿的重生',
        descp_zh: ['2016白塔寺院落更新国际方案征集是“白塔寺再生计划”中的一部分。'],
        imgs: ['/cover_2016_comp.jpg']
      },
      44: {
        descp_zh: ['作为白塔寺再生计划的一部分，继2016白塔寺院落更新国际方案征集之后，2017年，白塔寺再生计划与新街口街道办事处联合，再次启动设计方案征集活动。'],
        imgs: ['/cover_2017_comp.jpg']
      },
      46: {
        sub_name_zh: '',
        descp_zh: ['“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平 行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作，使整个展览过程形成一部充满共享与不断交融的创新大戏，打破建筑空间的边界，产生设计、艺术、 人文、科技、互联网和新兴产业的共振。“白塔寺再生计划”作为威尼斯双年展平行展“城市核心区”展览单元，参展第十五届威尼斯建筑双年展，于2016年5月26日-2016年11月27日在威尼斯展示，使得白塔寺项目获得广泛的国际关注，加强了优秀资源合作的可能性。'],
        imgs: ['/cover_venice.jpg']
      },
      47: {
        sub_name_zh: '',
        descp_zh: ['2016“上海设计之变”由上海市文联、上海市文广局、上海市教委、上海市徐汇区人民政府主办，致力于通过展览来构建新型的城市形态和生活形态，其意义不仅可以改善不同文化背景的人群行为文明，更有利于通过缩减城乡差别，而达到更改城市容貌的效应。“白塔寺再生计划”参展“上海设计之变”，对白塔寺项目在国内乃至国际艺术设计领域的交流和推广有积极的作用。'],
        imgs: ['/cover_snh_design.jpg']
      }
    },
    homeList: [],
    lists: {},
    articles: {}
  },
  getters: {
  },
  mutations: {
    init (state, payload) {
      function generateLink (nav, sup) {
        if (nav.id === 18 || nav.id === 19 || nav.id === 20) {
          nav['link'] = `${sup}#${String(nav.name_en).replace(/[ ,./]/g, '-').toLowerCase()}`
          // nav['link'] = `${sup}#${String(nav.name_zh).replace(/[ ,.]/g, '-').toLowerCase()}`
        } else {
          nav['link'] = `${sup.replace('#', '/')}/${String(nav.name_en).replace(/[ ,./]/g, '-').toLowerCase()}`
          // nav['link'] = `${sup}/${String(nav.name_zh).replace(/[ ,.]/g, '-').toLowerCase()}`
        }
        nav['absname'] = `${sup}/${String(nav.name_en).replace(/[ ,./]/g, '-').toLowerCase()}`
        nav['relname'] = `${String(nav.name_en).replace(/[ ,./]/g, '-').toLowerCase()}`
        // nav['absname'] = `${sup}/${String(nav.name_zh).replace(/[ ,.]/g, '-').toLowerCase()}`

        if ('children_nav' in nav) {
          nav['children_nav'].map(n => generateLink(n, nav.absname))
        }

        return nav
      }
      const nav = payload.map(n => generateLink(n, ''))
      Vue.set(state, 'nav', nav)
    },
    updataHomeList (state, payload) {
      Vue.set(state, 'homeList', state.homeList.concat(payload))
    },
    updateList (state, payload) {
      // console.log('updateList', payload)
      Vue.set(state.lists, payload.id, payload.list)
      // console.log(state.lists)
    },
    updateArticle (state, payload) {
      Vue.set(state.articles, payload.id, payload.article)
    }
  },
  actions: {
    async init (context) {
      if (context.state.nav.length === 0) {
        try {
          let res = await this.$axios.$post('/nav_list', querystring.stringify({login_uid: 'glabcms', nav_type: 'article'}))

          if (String(res.code) === '100200') {
            context.commit('init', res.data)
          }
        } catch (e) {
          console.error(e)
          // window.alert('网络错误')
        }
      }
    },
    async fetchArticleListByPage (context, payload) {
      const id = payload.id
      const n = payload.n

      if (n) {
        try {
          let params = { n }

          if (id) {
            params['id'] = id
          }
          let { code, data } = await this.$axios.$post('/article_list_all', querystring.stringify({login_uid: 'glabcms', ...params}))

          if (String(code) === '100200') {
            return data.map(a => {
              const res = getLinkById(context.state.nav, a.nav_id)

              if (res.found) {
                a['link'] = `${res.link}/${a.id}`
                a['category'] = res.category
                return a
              }
            })
          }
        } catch (e) {
          console.error(e)
        }
      }
    },
    async fetchArticleListOfCategory (context, payload) {
      const id = payload.id
      if (id in context.state.lists) {
        return context.state.lists[id].filter(a => {
          return !payload.lang || ['zh', 'en'][a.lang] === payload.lang
        })
      } else {
        try {
          let { code, data } = await this.$axios.$post('/article_list', querystring.stringify({login_uid: 'glabcms', nav_id: id, count: 10000}))

          if (String(code) === '100200') {
            const list = 'list_data' in data ? data.list_data : data
            context.commit('updateList', {id, list})
            return list.filter(a => {
              return !payload.lang || ['zh', 'en'][a.lang] === payload.lang
            })
          } else if (String(code) === '100203') {
            context.commit('updateList', {id, list: []})
            return []
          }
        } catch (e) {
          console.error(e)
          // window.alert('网络错误')
        }
      }
    },
    async fetchArticleContent (context, payload) {
      const id = payload.id
      if (id in context.state.articles) {
        return context.state.articles[id]
      } else {
        try {
          let { code, data } = await this.$axios.$post('/articleinfo', querystring.stringify({login_uid: 'glabcms', article_id: id}))

          if (String(code) === '100200') {
            data['id'] = id
            context.commit('updateArticle', {id, article: data})
            return data
          }
        } catch (e) {
          console.error(e)
          // window.alert('网络错误')
        }
      }
    }
  }
})

export default store
