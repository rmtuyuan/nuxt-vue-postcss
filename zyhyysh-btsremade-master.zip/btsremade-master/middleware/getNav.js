export default async function ({ route, store, app, redirect }) {
  // if (route.fullPath.length > 4 && !route.fullPath.match(/\/(robots|favico)/) && (!route.params.lang || !route.params.lang.match(/(zh|en)/))) {
  //   redirect(`/zh/${route.fullPath}`)
  // }
  console.log(route.fullPath.match(/^\/(zh\/|en\/|api\/|robots|favico|_nuxt)/))
  if (!route.fullPath.match(/^\/(zh\/|en\/|api\/|robots|favico|_nuxt)/)) {
    if (route.path !== '/' && route.path !== '/zh' && route.path !== '/en') {
      redirect(`/zh${route.fullPath}`)
    }
  }
  await store.dispatch('init')
}
