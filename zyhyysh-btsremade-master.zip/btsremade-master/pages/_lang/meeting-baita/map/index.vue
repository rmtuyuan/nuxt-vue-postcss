<style lang="less">
.map-root {
  position: fixed;
  top: 52px;
  left: 0;
  right: 0;
  bottom: 48px;
  z-index: 1;
  background: black;

  @media only screen and (min-width: 720px) {
    position: relative;
    top: auto;
    left: auto;
    right: auto;
    bottom: auto;
  }

  .map-container {
    position: relative;
    height: 100%;
    overflow: hidden;
    z-index: 1;

    @media only screen and (min-width: 720px) {
      height: 0;
      padding-bottom: 50%;
      border: 1px solid black;
    }

    &.dragging {
      cursor: move;
    }
  }

  .map-infos {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 2;
  }

  .map-anchor {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 1000px;
    height: 600px;
    margin-left: -500px;
    margin-top: -300px;
    transition: transform .2s;
  }

  .map-content {
    position: relative;
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
  }

  .spot-anchor {
    position: absolute;
    z-index: 1;
    transition: transform .2s;
    
    .spot {
      display: flex;
      width: 48px;
      height: 48px;
      margin-left: -24px;
      margin-top: -24px;
      background: black;
      border: none;
      border-radius: 2px;
      outline: none;
      align-items: center;
      justify-content: center;
      padding: 0;

      &:before {
        display: block;
        content: '';
        width: 40px;
        height: 40px;
        border: 1px solid white;
        position: absolute;
        border-radius: 2px;
      }
    }

    span.spot {
      background: transparent;
      opacity: 0;
    }

    &.active {
      z-index: 2;
    }
  }

  .spot-info {
    position: absolute;
    width: 240px;
    height: auto;
    background: black;
    color: white;
    margin-left: -24px;
    margin-top: 22px;
    box-shadow: 0 30px 80px rgba(0, 0, 0, .5);

    .spot-cover,
    .spot-content {
      position: relative;
      z-index: 1;
      color: white;
    }

    .spot-cover {
      width: 100%;
      height: 160px;
      background-size: cover;
      background-position: center;
      border-top: 2px solid black;
    }

    .spot-content {
      width: 100%;
      padding: 15px 12px;

      h4 {
        margin-top: 0;
      }

      p {
        margin-bottom: 0;
      }
    }

    &:hover {
      cursor: pointer;
    }

    &:before {
      display: block;
      content: '';
      width: 48px;
      height: 48px;
      position: absolute;
      top: -24px;
      left: 0px;
      transform: rotate(45deg) scale(.5);
      background: black;
      z-index: 0;
    }

    &.above {
      margin-top: -70px;
      transform: translateY(-100%);

      &:before {
        top: auto;
        bottom: -24px;
      }
    }

    &.before {
      margin-left: -216px;

      &:before {
        left: auto;
        right: 0;
      }
    }
  }

  .map-control-group {
    position: absolute;
    z-index: 3;
    left: 0;
    right: 0;
    bottom: -48px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    background-color: black;

    ul {
      display: flex;
      flex-direction: row;
      margin-bottom: 0;
    }

    @media only screen and (min-width: 720px) {
      left: auto;
      right: 30px;
      bottom: 10px;
      display: block;
      background: transparent;

      ul {
        display: block;
        margin-bottom: 10px;
      }

      li + li {
        &:before {
          content: "";
          display: block;
          position: absolute;
          top: 0;
          left: 10px;
          right: 10px;
          height: 1px;
          background-color: white;
        }
      }
    }

    li {
      position: relative;

      button {
        border-radius: 0;
        svg, span {
          opacity: .5;
        }

        &.active {
          svg, span {
            opacity: 1;
          }
        }
      }

      &:first-child {
        button {
          border-top-left-radius: 2px;
          border-top-right-radius: 2px;
        }
      }

      &:last-child {
        button {
          border-bottom-left-radius: 2px;
          border-bottom-right-radius: 2px;
        }
      }
    }

    button {
      padding: 0;
      width: 48px;
      height: 48px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      // align-content: flex-start;
      // justify-items: space-between;
      background-color: black;
      border: none;
      outline: none;

      .icon {
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 1;
      }

      svg {
        transform: scale(.65);
      }

      span {
        flex: initial;
        font-size: 12px;
        color: white;
      }

      &.btn-zoom {
        border-radius: 2px;
      }
    }
  }

  [class|=map-indicator] {
    position: absolute;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-top: 3px solid transparent;
    border-left: 10px solid transparent;
    border-right: 10px solid transparent;
    border-bottom: 17px solid black;
    color: blue;
    // background-color: black;
    transition: transform .2s;
    // box-shadow: 0 0 10px black;
    // transform: skew(45deg);

    &.map-indicator-north {
      top: 0;
      left: 50%;
      margin-left: -10px;
    }

    &.map-indicator-east {
      top: 50%;
      right: 0;
      margin-top: -10px;
      transform: rotate(90deg);
    }

    &.map-indicator-south {
      left: 50%;
      bottom: 0;
      margin-left: -10px;
      transform: rotate(180deg);
    }

    &.map-indicator-west {
      top: 50%;
      left: 0;
      margin-top: -10px;
      transform: rotate(-90deg);
    }
  }

  .map-container.dragging {
    .map-anchor, [class|=map-indicator] {
      transition: none;
    }
  }
}
</style>

<template>
  <div class="row page-list">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="$route.params.lang === 'en' ? 'Meeting Baita' : '邂逅白塔'" :sub="subNav" :lang="$route.params.lang"></nav-aside>
        <!-- <nav-aside category="邂逅白塔" :sub="subNav"></nav-aside> -->
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <div class="row">
        <div class="col-xs-12">
          <div class="map-root">
            <div class="map-container"
                 :class="{'dragging': dragging}"
                 ref="container"
                 @mousedown="dragging = true"
                 @mouseup="dragging = false"
                 @mouseleave="dragging = false"
                 @mousemove="mmove"
                 @touchstart="tstart"
                 @touchend="tend"
                 @touchcancel="tend"
                 @touchmove.prevent="tmove">
              <div class="map-anchor" :style="anchorStyle">
                <div class="map-content" style="background-image: url('/map.jpg')" v-if="containerWidth > 0">
                  <template v-for="(spot, index) in pSpots">
                    <div class="spot-anchor"
                         :class="{'active': index === selectedSpotIndex}"
                         :style="[spot.pos, spotStyle]">
                      <button class="spot" @click="toggleSpot(index)">
                        <template v-if="spot.keywords === 'shopping'">
                          <svg width="22px" height="21px" viewBox="0 0 22 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy" fill="#FFFFFF">
                              <path d="M20.8095238,12 L22,7 L0,7 L1.19047619,12 L20.8095238,12 Z M20.5714286,13 L18.6666667,21 L3.33333333,21 L1.42857143,13 L20.5714286,13 Z M17,6 L5,6 C5,2.6862915 7.6862915,0 11,0 C14.3137085,0 17,2.6862915 17,6 Z M15,6 C15,3.790861 13.209139,2 11,2 C8.790861,2 7,3.790861 7,6 L15,6 Z" id="Combined-Shape"></path>
                            </g>
                          </svg>
                        </template>
                        <template v-if="spot.keywords === 'restaurant'">
                          <svg width="28px" height="18px" viewBox="0 0 28 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy"fill="#FFFFFF">
                              <path d="M12.7564093,3.56645918 C6.99002237,4.1865 2.5,9.06889954 2.5,15 L25.5,15 C25.5,9.06889954 21.0099776,4.1865 15.2435907,3.56645918 C15.7044935,3.20006549 16,2.63454237 16,2 C16,0.8954305 15.1045695,0 14,0 C12.8954305,0 12,0.8954305 12,2 C12,2.63454237 12.2955065,3.20006549 12.7564093,3.56645918 Z M0,16 L28,16 L28,18 L0,18 L0,16 Z" id="Combined-Shape"></path>
                            </g>
                          </svg>
                        </template>
                        <template v-if="spot.keywords === 'culture'">
                          <svg width="24px" height="26px" viewBox="0 0 24 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy" fill-rule="nonzero" fill="#FFFFFF">
                              <path d="M3.39143826,2.47412354 L3.39143826,0.477462437 C3.39143826,0.217028381 3.60791475,0 3.86768654,0 L20.0601279,0 C20.3198997,0 20.5363762,0.217028381 20.5363762,0.477462437 L20.5363762,2.47412354 C20.5363762,2.7345576 20.3198997,2.95158598 20.0601279,2.95158598 L3.86768654,2.95158598 C3.60791475,2.95158598 3.39143826,2.7345576 3.39143826,2.47412354 Z M21.532168,8.42070117 C20.5363762,7.07512521 19.8869467,5.46911519 19.7137655,3.8196995 L4.21404892,3.8196995 C3.99757243,5.51252087 3.34814297,7.07512521 2.35235112,8.46410684 C0.663834505,10.721202 -0.245366748,13.6293823 0.0577003363,16.7111853 C0.404062718,20.6176962 2.6554182,24.0033389 5.90256553,25.9131886 C5.98915613,25.9565943 6.07574673,26 6.16233732,26 L17.895363,26 C17.9819536,26 18.0685442,25.9565943 18.1551348,25.9131886 C21.6620539,23.8297162 24,19.966611 24,15.5826377 C23.9567047,12.9348915 23.0475034,10.4607679 21.532168,8.42070117 Z" id="Shape"></path>
                            </g>
                          </svg>
                        </template>
                        <template v-if="spot.keywords === 'scenespot'">
                          <svg width="22px" height="26px" viewBox="0 0 22 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy" fill="#FFFFFF">
                              <path d="M13.7623734,4 L12.4347826,0 L9.56521739,0 L8.28334208,4 L13.7623734,4 Z M15.0899641,8 L18.408941,18 L3.79677848,18 L7.00146676,8 L15.0899641,8 Z M0,20 L22,20 L22,26 L0,26 L0,20 Z M4.7826087,5 L17.2173913,5 L17.2173913,7 L4.7826087,7 L4.7826087,5 Z" id="Combined-Shape"></path>
                            </g>
                          </svg>
                        </template>
                      </button>
                      <!-- <transition name="fade">
                        <div class="spot-info"
                             :class="{
                             'above': (Number(spot.pos.top.slice(0, -1)) - 50) * zoomRatio + 50 + draggingOffset[1] / containerHeight * 100 > 50,
                             'before': (Number(spot.pos.left.slice(0, -1)) - 50) * zoomRatio + 50 + draggingOffset[0] / containerWidth * 100 > 50}"
                             v-if="index === selectedSpotIndex">
                          <nuxt-link :to="`/${$route.params.lang}${currentCategory.link}/article/${spot.id}`">
                            <div class="spot-cover" :style="`background-image: url(${spot.cover})`"></div>
                            <div class="spot-content">
                              <h4>{{spot.title}}</h4>
                              <p>{{spot.description}}</p>
                            </div>
                          </nuxt-link>
                        </div>
                      </transition> -->
                    </div>
                  </template>
                </div>
              </div>
              <div class="map-indicator-north"
                   :style="`transform: scale(${0.5 - draggingOffset[1] / (contentHeight * mapScale - containerHeight) || 0})`"></div>
              <div class="map-indicator-east"
                   :style="`transform: scale(${0.5 + draggingOffset[0] / (contentWidth * mapScale - containerWidth) || 0}) rotate(90deg)`"></div>
              <div class="map-indicator-south"
                   :style="`transform: scale(${0.5 + draggingOffset[1] / (contentHeight * mapScale - containerHeight) || 0}) rotate(180deg)`"></div>
              <div class="map-indicator-west"
                   :style="`transform: scale(${0.5 - draggingOffset[0] / (contentWidth * mapScale - containerWidth) || 0}) rotate(-90deg)`"></div>
            </div>
            <div class="map-infos" v-if="selectedSpotIndex >= 0">
              <div class="map-anchor" :style="anchorStyle">
                <div class="map-content" v-if="containerWidth > 0" @click.self="selectedSpotIndex = -1">
                  <template v-for="(spot, idx) in pSpots">
                    <div class="spot-anchor"
                         :class="{'active': idx === selectedSpotIndex}"
                         :style="[spot.pos, spotStyle]">
                      <!-- <button class="spot" @click="toggleSpot(index)">
                        <template v-if="spot.keywords === 'shopping'">
                          <svg width="22px" height="21px" viewBox="0 0 22 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy" fill="#FFFFFF">
                              <path d="M20.8095238,12 L22,7 L0,7 L1.19047619,12 L20.8095238,12 Z M20.5714286,13 L18.6666667,21 L3.33333333,21 L1.42857143,13 L20.5714286,13 Z M17,6 L5,6 C5,2.6862915 7.6862915,0 11,0 C14.3137085,0 17,2.6862915 17,6 Z M15,6 C15,3.790861 13.209139,2 11,2 C8.790861,2 7,3.790861 7,6 L15,6 Z" id="Combined-Shape"></path>
                            </g>
                          </svg>
                        </template>
                        <template v-if="spot.keywords === 'restaurant'">
                          <svg width="28px" height="18px" viewBox="0 0 28 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy"fill="#FFFFFF">
                              <path d="M12.7564093,3.56645918 C6.99002237,4.1865 2.5,9.06889954 2.5,15 L25.5,15 C25.5,9.06889954 21.0099776,4.1865 15.2435907,3.56645918 C15.7044935,3.20006549 16,2.63454237 16,2 C16,0.8954305 15.1045695,0 14,0 C12.8954305,0 12,0.8954305 12,2 C12,2.63454237 12.2955065,3.20006549 12.7564093,3.56645918 Z M0,16 L28,16 L28,18 L0,18 L0,16 Z" id="Combined-Shape"></path>
                            </g>
                          </svg>
                        </template>
                        <template v-if="spot.keywords === 'culture'">
                          <svg width="24px" height="26px" viewBox="0 0 24 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy" fill-rule="nonzero" fill="#FFFFFF">
                              <path d="M3.39143826,2.47412354 L3.39143826,0.477462437 C3.39143826,0.217028381 3.60791475,0 3.86768654,0 L20.0601279,0 C20.3198997,0 20.5363762,0.217028381 20.5363762,0.477462437 L20.5363762,2.47412354 C20.5363762,2.7345576 20.3198997,2.95158598 20.0601279,2.95158598 L3.86768654,2.95158598 C3.60791475,2.95158598 3.39143826,2.7345576 3.39143826,2.47412354 Z M21.532168,8.42070117 C20.5363762,7.07512521 19.8869467,5.46911519 19.7137655,3.8196995 L4.21404892,3.8196995 C3.99757243,5.51252087 3.34814297,7.07512521 2.35235112,8.46410684 C0.663834505,10.721202 -0.245366748,13.6293823 0.0577003363,16.7111853 C0.404062718,20.6176962 2.6554182,24.0033389 5.90256553,25.9131886 C5.98915613,25.9565943 6.07574673,26 6.16233732,26 L17.895363,26 C17.9819536,26 18.0685442,25.9565943 18.1551348,25.9131886 C21.6620539,23.8297162 24,19.966611 24,15.5826377 C23.9567047,12.9348915 23.0475034,10.4607679 21.532168,8.42070117 Z" id="Shape"></path>
                            </g>
                          </svg>
                        </template>
                        <template v-if="spot.keywords === 'scenespot'">
                          <svg width="22px" height="26px" viewBox="0 0 22 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="地图-copy" fill="#FFFFFF">
                              <path d="M13.7623734,4 L12.4347826,0 L9.56521739,0 L8.28334208,4 L13.7623734,4 Z M15.0899641,8 L18.408941,18 L3.79677848,18 L7.00146676,8 L15.0899641,8 Z M0,20 L22,20 L22,26 L0,26 L0,20 Z M4.7826087,5 L17.2173913,5 L17.2173913,7 L4.7826087,7 L4.7826087,5 Z" id="Combined-Shape"></path>
                            </g>
                          </svg>
                        </template>
                      </button> -->
                      <span class="spot"></span>
                      <transition name="fade">
                        <div class="spot-info"
                             :class="{
                             'above': (Number(spot.pos.top.slice(0, -1)) - 50) * zoomRatio + 50 + draggingOffset[1] / containerHeight * 100 > 60,
                             'before': (Number(spot.pos.left.slice(0, -1)) - 50) * zoomRatio + 50 + draggingOffset[0] / containerWidth * 100 > 40}"
                             v-if="idx === selectedSpotIndex">
                          <nuxt-link :to="`/${$route.params.lang}${currentCategory.link}/article/${spot.id}`">
                            <div class="spot-cover" :style="`background-image: url(${spot.cover})`"></div>
                            <div class="spot-content">
                              <h4>{{spot.title}}</h4>
                              <p>{{spot.description}}</p>
                            </div>
                          </nuxt-link>
                        </div>
                      </transition>
                    </div>
                  </template>
                </div>
              </div>
            </div>
            <div class="map-control-group">
              <ul class="list-unstyled">
                <li>
                  <button :class="{'active': filter['shopping']}"
                          @click="toggleFliter('shopping')">
                    <div class="icon">
                      <svg width="22px" height="21px" viewBox="0 0 22 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="地图-copy" fill="#FFFFFF">
                          <path d="M20.8095238,12 L22,7 L0,7 L1.19047619,12 L20.8095238,12 Z M20.5714286,13 L18.6666667,21 L3.33333333,21 L1.42857143,13 L20.5714286,13 Z M17,6 L5,6 C5,2.6862915 7.6862915,0 11,0 C14.3137085,0 17,2.6862915 17,6 Z M15,6 C15,3.790861 13.209139,2 11,2 C8.790861,2 7,3.790861 7,6 L15,6 Z" id="Combined-Shape"></path>
                        </g>
                      </svg>
                    </div>
                    <span>购物</span>
                  </button>
                </li>
                <li>
                  <button :class="{'active': filter['restaurant']}"
                          @click="toggleFliter('restaurant')">
                    <div class="icon">
                      <svg width="28px" height="18px" viewBox="0 0 28 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="地图-copy"fill="#FFFFFF">
                          <path d="M12.7564093,3.56645918 C6.99002237,4.1865 2.5,9.06889954 2.5,15 L25.5,15 C25.5,9.06889954 21.0099776,4.1865 15.2435907,3.56645918 C15.7044935,3.20006549 16,2.63454237 16,2 C16,0.8954305 15.1045695,0 14,0 C12.8954305,0 12,0.8954305 12,2 C12,2.63454237 12.2955065,3.20006549 12.7564093,3.56645918 Z M0,16 L28,16 L28,18 L0,18 L0,16 Z" id="Combined-Shape"></path>
                        </g>
                      </svg>
                    </div>
                    <span>餐饮</span>
                  </button>
                </li>
                <li>
                  <button :class="{'active': filter['culture']}"
                          @click="toggleFliter('culture')">
                    <div class="icon">
                      <svg width="24px" height="26px" viewBox="0 0 24 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="地图-copy" fill-rule="nonzero" fill="#FFFFFF">
                          <path d="M3.39143826,2.47412354 L3.39143826,0.477462437 C3.39143826,0.217028381 3.60791475,0 3.86768654,0 L20.0601279,0 C20.3198997,0 20.5363762,0.217028381 20.5363762,0.477462437 L20.5363762,2.47412354 C20.5363762,2.7345576 20.3198997,2.95158598 20.0601279,2.95158598 L3.86768654,2.95158598 C3.60791475,2.95158598 3.39143826,2.7345576 3.39143826,2.47412354 Z M21.532168,8.42070117 C20.5363762,7.07512521 19.8869467,5.46911519 19.7137655,3.8196995 L4.21404892,3.8196995 C3.99757243,5.51252087 3.34814297,7.07512521 2.35235112,8.46410684 C0.663834505,10.721202 -0.245366748,13.6293823 0.0577003363,16.7111853 C0.404062718,20.6176962 2.6554182,24.0033389 5.90256553,25.9131886 C5.98915613,25.9565943 6.07574673,26 6.16233732,26 L17.895363,26 C17.9819536,26 18.0685442,25.9565943 18.1551348,25.9131886 C21.6620539,23.8297162 24,19.966611 24,15.5826377 C23.9567047,12.9348915 23.0475034,10.4607679 21.532168,8.42070117 Z" id="Shape"></path>
                        </g>
                      </svg>
                    </div>
                    <span>文化</span>
                  </button>
                </li>
                <li>
                  <button :class="{'active': filter['scenespot']}"
                          @click="toggleFliter('scenespot')">
                    <div class="icon">
                      <svg width="22px" height="26px" viewBox="0 0 22 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g id="地图-copy" fill="#FFFFFF">
                          <path d="M13.7623734,4 L12.4347826,0 L9.56521739,0 L8.28334208,4 L13.7623734,4 Z M15.0899641,8 L18.408941,18 L3.79677848,18 L7.00146676,8 L15.0899641,8 Z M0,20 L22,20 L22,26 L0,26 L0,20 Z M4.7826087,5 L17.2173913,5 L17.2173913,7 L4.7826087,7 L4.7826087,5 Z" id="Combined-Shape"></path>
                        </g>
                      </svg>
                    </div>
                    <span>景点</span>
                  </button>
                </li>
              </ul>

              <button class="btn-zoom" @click="toggleZoom">
                <div class="icon">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="地图-copy" fill="#FFFFFF">
                      <path d="M9.5,0 L9.5,0 C14.7467051,-9.63804095e-16 19,4.25329488 19,9.5 L19,9.5 C19,14.7467051 14.7467051,19 9.5,19 C4.25329488,19 6.42536064e-16,14.7467051 0,9.5 L0,9.5 L0,9.5 C-6.42536064e-16,4.25329488 4.25329488,9.63804095e-16 9.5,0 L9.5,0 Z M9.5,2 L9.5,2 C5.35786438,2 2,5.35786438 2,9.5 L2,9.5 C2,13.6421356 5.35786438,17 9.5,17 L9.5,17 C13.6421356,17 17,13.6421356 17,9.5 L17,9.5 C17,5.35786438 13.6421356,2 9.5,2 L9.5,2 Z M16.2171165,18.3384369 L16.2171165,16.9242233 L16.9242233,16.2171165 L18.3384369,16.2171165 L23.9952911,21.8739708 L21.8739708,23.9952911 L16.2171165,18.3384369 Z" id="Combined-Shape"></path>
                      <rect id="Rectangle-21" x="5" y="8.5" width="9" height="2"></rect>
                      <transition name="fade">
                        <rect v-if="zoomRatio === 1" id="Rectangle-21-Copy" x="8.5" y="5" width="2" height="9"></rect>
                      </transition>
                    </g>
                  </svg>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import { findCurrentCategory, findCurrentSection, parseJSON } from '~/assets/js/utils'

export default {
  components: {
    FixedContainer, NavAside
  },
  async asyncData ({ route, store, app }) {
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const subNav = currentCategory.children_nav || []
    const currentSection = findCurrentSection(store.state.nav, route.fullPath).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id })

    await Promise.all(subNav.map(s => {
      return store.dispatch('fetchArticleListOfCategory', { id: s.id })
    }))

    return {
      currentCategory,
      currentSection,
      subNav,
      spots: articleList.filter(a => a.meta && a.meta.length > 0).map(a => {
        // console.log(a.meta, parseJSON)
        const meta = parseJSON(a.meta)
        // console.log(meta)
        a['geo'] = meta.geo
        return a
      })
    }
  },
  data () {
    return {
      corner: [
        {
          // nw
          lat: 39.934357,
          lon: 116.362701
        },
        {
          // ne
          lat: 39.934402,
          lon: 116.373543
        },
        {
          // se
          lat: 39.929637,
          lon: 116.373534
        },
        {
          // sw
          lat: 39.929402,
          lon: 116.362737
        }
      ],
      // spots: [
      //   {
      //     title: 'test 1',
      //     description: '',
      //     keywords: 'restaurant',
      //     cover: '/img01.jpg',
      //     geo: {
      //       lat: 39.926213,
      //       lon: 116.361208
      //     }
      //   },
      //   {
      //     title: 'test nw',
      //     description: 'hello',
      //     keywords: 'shopping',
      //     cover: '/img02.jpg',
      //     geo: {
      //       lat: 39.928370,
      //       lon: 116.357166
      //     }
      //   },
      //   {
      //     title: 'test conjoinction',
      //     description: 'xxxxxx',
      //     keywords: 'scenespot',
      //     cover: '/img03.jpg',
      //     geo: {
      //       lat: 39.923879,
      //       lon: 116.364944
      //     }
      //   },
      //   {
      //     title: 'test lx',
      //     description: 'xxxxxx',
      //     keywords: 'culture',
      //     cover: '/img04.jpg',
      //     geo: {
      //       lat: 39.925303,
      //       lon: 116.358738
      //     }
      //   }
      // ],
      filter: {
        shopping: true,
        restaurant: true,
        culture: true,
        scenespot: true
      },
      selectedSpotIndex: -1,
      containerWidth: 0,
      containerHeight: 0,
      contentWidth: 1000,
      contentHeight: 600,
      zoomRatio: 1,
      draggingTick: false,
      dragging: false,
      draggingOffset: [0, 0],
      touchMovements: []
    }
  },
  computed: {
    pSpots () {
      return this.spots.map(s => {
        s['pos'] = this.calcPosition(s.geo)
        return s
      }).filter(s => {
        return this.filter[s.keywords]
      })
    },
    mapScale () {
      if (this.containerWidth > this.containerHeight) {
        return this.containerWidth / 1000 * this.zoomRatio
      } else {
        return this.containerHeight / 600 * this.zoomRatio
      }
    },
    anchorStyle () {
      return {
        transform: `translate(${this.draggingOffset[0]}px, ${this.draggingOffset[1]}px) scale(${this.mapScale})`
      }
    },
    spotStyle () {
      return {
        transform: `scale(${1 / this.mapScale})`
      }
    }
  },
  methods: {
    calcPosition (geo) {
      const startLat = (this.corner[0].lat + this.corner[1].lat) / 2
      const endLat = (this.corner[2].lat + this.corner[3].lat) / 2
      const startLon = (this.corner[0].lon + this.corner[3].lon) / 2
      const endLon = (this.corner[1].lon + this.corner[2].lon) / 2
      return {
        top: `${(geo.lat - startLat) / (endLat - startLat) * 100}%`,
        left: `${(geo.lon - startLon) / (endLon - startLon) * 100}%`
      }
    },
    toggleSpot (idx) {
      this.selectedSpotIndex = this.selectedSpotIndex !== idx ? idx : -1
    },
    toggleFliter (keyword) {
      this.selectedSpotIndex = -1
      this.filter[keyword] = !this.filter[keyword]
    },
    toggleZoom () {
      console.log('toggleZoom', this.zoomRatio)
      if (this.zoomRatio === 3) {
        this.zoom(-2)
      } else {
        this.zoom(1)
      }
    },
    zoom (ratio) {
      this.zoomRatio = Math.max(1, Math.min(3, this.zoomRatio + ratio))
      if (this.zoomRatio === 1) {
        this.draggingOffset = [0, 0]
      }
    },
    mmove (ev) {
      if (!this.draggingTick) {
        this.draggingTick = true
        window.requestAnimationFrame(() => {
          this.draggingTick = false
          if (this.dragging) {
            this.moveMap(ev.movementX, ev.movementY)
          }
        })
      }
    },
    tstart (ev) {
      const touch = ev.touches[0]
      if (touch) {
        this.dragging = true
        this.touchMovements.push(touch)
      }
    },
    tmove (ev) {
      if (!this.draggingTick) {
        this.draggingTick = true
        window.requestAnimationFrame(() => {
          this.draggingTick = false
          if (this.dragging) {
            const touch = ev.touches[0]
            const lastTouch = this.touchMovements.pop()

            if (touch && lastTouch) {
              const movementX = touch.clientX - lastTouch.clientX
              const movementY = touch.clientY - lastTouch.clientY

              this.moveMap(movementX, movementY)
            }

            this.touchMovements = [lastTouch, touch]
          }
        })
      }
    },
    tend () {
      this.dragging = false
      this.touchMovements = []
    },
    moveMap (mx, my) {
      this.selectedSpotIndex = -1
      this.draggingOffset = [
        Math.max(
          (this.containerWidth - this.contentWidth * this.mapScale) / 2,
          Math.min(
            (this.contentWidth * this.mapScale - this.containerWidth) / 2,
            this.draggingOffset[0] + mx)),
        Math.max(
          (this.containerHeight - this.contentHeight * this.mapScale) / 2,
          Math.min(
            (this.contentHeight * this.mapScale - this.containerHeight) / 2,
            this.draggingOffset[1] + my))
      ]
    }
  },
  mounted () {
    this.containerWidth = this.$refs.container.offsetWidth
    this.containerHeight = this.$refs.container.offsetHeight

    let th = 0
    window.addEventListener('resize', () => {
      window.clearTimeout(th)
      th = window.setTimeout(() => {
        this.containerWidth = this.$refs.container.offsetWidth
        this.containerHeight = this.$refs.container.offsetHeight
        this.dragging = false
        this.selectedSpotIndex = -1
        this.draggingOffset = [0, 0]
      }, 100)
    })
  }
}
</script>