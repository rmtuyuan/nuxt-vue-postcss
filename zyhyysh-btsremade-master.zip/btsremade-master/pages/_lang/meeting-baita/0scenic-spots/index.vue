<style lang="less">
.page-list {
  .section-header {
    background-color: #e1e1e1;
    height: 0;
    padding-bottom: 42.5%;
    position: relative;
    margin-bottom: 40px;

    .section-header-inner {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 60px;
      // text-align: right;

      h3 {
        margin: 0;
        font-weight: bold;
        letter-spacing: .02em;
        font-size: 26px;
      }

      h4 {
        font-size: 20px;
        margin-top: 16px;
        margin-bottom: 24px;
      }

      p {
        font-size: .875rem;
        line-height: 1.6em;
      }

      hr {
        border-color: black;
        border-width: 2px;
        margin-bottom: 24px;
      }
    }
  }

  .section-item {
    header {
      height: 0;
      padding-bottom: 66.67%;
      background-color: #e1e1e1;
      position: relative;

      .section-item-header-label {
        position: absolute;
        right: 15px;
        bottom: 10px;
        padding: 0px 10px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
      }
    }

    a {
      display: block;
      text-decoration: none;
      letter-spacing: .05em;

      h3 {
        color: black;
      }

      h4 {
        color: #959595;
        margin-top: 12px;
        margin-bottom: 28px;
        line-height: 20px;
        height: 20px;
      }

      p {
        color: #959595;
        font-size: .75rem;
        line-height: 18px;
        height: 72px;
      }

      &:hover {
        span {
          background-color: black;
          color: white;
        }
      }
    }

    hr {
      margin-top: 50px;
      margin-bottom: 60px;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    margin-top: 30px;
  }
}
</style>

<template>
  <div class="page-list container">
    <div class="row">
      <div class="col-xs-2">
        <nav-aside :category="4" title="邂逅白塔" :sections="sections" :active="2"></nav-aside>
      </div>

      <div class="col-xs-10">
        <!-- <header class="section-header">
          <div class="section-header-inner">
            <div class="row">
              <div class="col-xs-4 col-xs-offset-7">
                <hr>
                <h3>2015年北京国际设计周</h3>
                <h4>连接与共生</h4>
                <p>2015年北京国际设计周——“白塔寺再生计划”以“连接与共生”为主题，通过40余项设计展览展示活动、论坛，以及强化的可视化项目和线上线下一体化平台，将成为领略和重新发现该区域丰富文化、独一无二城市结构和历史的出发点。</p>
              </div>
            </div>
          </div>
        </header> -->

        <h3>
          <span class="impact">Scenic Spots</span><br>
          <span>景点</span>
        </h3>

        <div class="row article-list">
          <template v-for="article in articles">
            <article-item class="col-xs-4"
                          :title="article.title"
                          :time="getTime(article.update_time)"
                          :link="getLink(article)"
                          :img="article.cover"></article-item>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { mapGetters } from 'vuex'
import querystring from 'querystring'

const section = 'scenic-spots'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  async asyncData ({ route, store, app }) {
    const sections = store.getters.meeting.sub

    let currentSection = sections.filter(s => {
      return s.name === section
    }).pop()

    let newarticle = await Promise.all(currentSection.articles.filter(id => {
      return !Object.keys(store.state.articles).includes(id)
    }).map(id => {
      return new Promise(async (resolve, reject) => {
        let res = await app.$axios.$post('articleinfo', querystring.stringify({
          login_uid: 'glabcms',
          article_id: id,
          status: '0'
        }))

        if (String(res.code) === '100200' && res.data.content) {
          res.data['id'] = id
          res.data['section'] = section
          store.commit('updateArticle', res.data)
          resolve(res.data)
        } else {
          resolve(null)
          // reject(new Error('xxx'))
        }
      })
    }))

    return {
      sections,
      currentSection,
      newarticle
    }
  },
  computed: {
    ...mapGetters(['meeting']),
    articles () {
      return this.currentSection.articles.map(id => {
        return this.$store.state.articles[id]
      }).filter(article => {
        if (article) {
          return article
        }
      })
    },
    currentSectionIdx () {
      return 1
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `/meeting-baita/scenic-spots/${article.id}`
    }
  }
}
</script>
