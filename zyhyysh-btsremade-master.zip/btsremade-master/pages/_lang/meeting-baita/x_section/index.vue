<template>
  <div class="row page-section">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
          <nav-aside category="邂逅白塔" :sub="subNav"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <section-header :section="currentSection"></section-header>

      <div class="row article-list">
        <h5 class="col-xs-12" v-if="articleList.length === 0">暂无内容</h5>
        <template v-for="article in articleList">
          <article-item class="col-xs-12 col-sm-6 col-md-4"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="getLink(article)"
                        :img="article.cover"></article-item>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import SectionHeader from '~/components/SectionHeader.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { findCurrentCategory, findCurrentSection } from '~/assets/js/utils'

export default {
  components: {
    FixedContainer, NavAside, SectionHeader, ArticleItem
  },
  async asyncData ({ store, route, app, redirect }) {
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const subNav = currentCategory.children_nav || []
    const currentSection = findCurrentSection(store.state.nav, route.fullPath).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id })

    // if (articleList.length === 1) {
    //   redirect(``)
    // }

    return {
      subNav,
      currentSection,
      articleList
    }
  },
  computed: {},
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.fullPath}/${article.id}`
    },
    getExtendInro (id) {
      return this.$store.state.tempNavInfo[id]
    }
  }
}
</script>
