<template>
  <div class="row page-article">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
          <nav-aside category="邂逅白塔" :sub="subNav"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-7">
      <article>
        <h2>{{article.title}}</h2>
        <h5>{{article.description}}</h5>
        <!-- <h3 class="time">{{getTime(article.add_time)}}</h3> -->

        <section class="article-container" v-html="articleContent"></section>
      </article>
    </div>

    <div class="col-xs-12 col-md-3">
      <div class="row article-list">
        <template v-for="article in articleList">
          <article-item class="col-xs-12 col-sm-6 col-md-12 in-aside"
                        in-parent="aside"
                        :category="2"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="getLink(article)"
                        :img="article.cover"></article-item>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { findCurrentCategory, findCurrentSection, readContent } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    FixedContainer, NavAside, ArticleItem
  },
  async asyncData ({ route, store, app }) {
    const id = route.params.article
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const subNav = currentCategory.children_nav || []
    const currentSection = findCurrentSection(store.state.nav, route.fullPath, -1).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id })
    const article = await store.dispatch('fetchArticleContent', { id })

    return {
      subNav,
      currentSection,
      article,
      articleList: articleList.slice(0, 6),
      articleContent: readContent(article.content)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path.split('/').slice(0, -1).join('/')}/${article.id}`
    }
  }
}
</script>