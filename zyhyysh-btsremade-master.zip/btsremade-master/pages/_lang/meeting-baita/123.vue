<style lang="less">
.page-meeting-baita {
}
</style>

<template>
  <div class="row page-list">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside category="邂逅白塔" :sub="subNav"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <nuxt/>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { findCurrentCategory } from '~/assets/js/utils'
// import { mapGetters } from 'vuex'
// import querystring from 'querystring'

// const section = 'scenic-spots'

export default {
  layout: 'default',
  components: {
    FixedContainer, NavAside, ArticleItem
  },
  async asyncData ({ route, store, app }) {
    // const sections = store.getters.meeting.sub

    // let currentSection = sections.filter(s => {
    //   return s.name === section
    // }).pop()

    // let newarticle = await Promise.all(currentSection.articles.filter(id => {
    //   return !Object.keys(store.state.articles).includes(id)
    // }).map(id => {
    //   return new Promise(async (resolve, reject) => {
    //     let res = await app.$axios.$post('articleinfo', querystring.stringify({
    //       login_uid: 'glabcms',
    //       article_id: id,
    //       status: '0'
    //     }))

    //     if (String(res.code) === '100200' && res.data.content) {
    //       res.data['id'] = id
    //       res.data['section'] = section
    //       store.commit('updateArticle', res.data)
    //       resolve(res.data)
    //     } else {
    //       resolve(null)
    //       // reject(new Error('xxx'))
    //     }
    //   })
    // }))

    // return {
    //   sections,
    //   currentSection,
    //   newarticle
    // }
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const subNav = currentCategory.children_nav || []

    await Promise.all(subNav.map(s => {
      return store.dispatch('fetchArticleListOfCategory', { id: s.id })
    }))

    return {
      currentCategory,
      subNav
    }
  },
  computed: {
    // ...mapGetters(['meeting']),
    // articles () {
    //   return this.currentSection.articles.map(id => {
    //     return this.$store.state.articles[id]
    //   }).filter(article => {
    //     if (article) {
    //       return article
    //     }
    //   })
    // },
    // currentSectionIdx () {
    //   return 1
    // }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `/meeting-baita/scenic-spots/${article.id}`
    }
  }
}
</script>
