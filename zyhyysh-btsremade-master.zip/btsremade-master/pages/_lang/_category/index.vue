<style lang="less">
.page-category {
  section.content-section {
    margin-bottom: 50px;
  }

  .content-placeholder {
    // padding: 2rem 0;
    // background: #f0f0f0;
    div {
      border-top: 2px solid black;
    }
  }

  .no-content {
    // text-align: center;
    padding-top: 4rem;
    padding-bottom: 4rem;
  }

  .article-in-category {
    background-color: #2b2b2b;
    color: white;
    // margin-top: 50px;
    margin-bottom: 40px;
    // padding: 30px 0;
    padding-top: 40px;

    header {
      text-align: right;

      hr {
        border-width: 2px;
        border-color: white;
      }
    }

    article p {
      color: white;
      opacity: .8;
      line-height: 2em;
    }
  }
}
</style>

<template>
  <div class="row page-category">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="currentCategory[`name_${lang}`]" :sub="subNav" :lang="lang"></nav-aside>
      </fixed-container>
    </div>
    <div class="col-xs-12 col-md-10">

      <div class="article-in-category" v-if="cArticle.id">
        <div class="row">
          <div class="col-xs-10 col-xs-offset-1">
            <header>
              <h3>{{cArticle.title}}</h3>
              <h5>{{cArticle.description}}</h5>
              <hr>
            </header>

            <g-article :content="cArticle.content"></g-article>
          </div>
        </div>
      </div>

      <section class="content-section" v-for="section in subNav">
        <section-header :section="section"></section-header>

        <div class="row article-list">
          <template v-for="article in articleLists[section.id]">
            <div class="col-xs-12 col-sm-6 col-md-4" v-if="currentCategory.absname.match(/^\/media-center/)">
              <media-article-item :link="`/${$route.params.lang}${currentCategory.link}/article/${article.id}`"
                                  :cover="article.cover"
                                  :title="article.title"
                                  :media="article.keywords"
                                  :date="article.description"></media-article-item>
            </div>
            <article-item v-else
                          class="col-xs-12 col-sm-6 col-md-4"
                          :title="article.title"
                          :link="`/${$route.params.lang}${currentCategory.link}/article/${article.id}`"
                          :img="article.cover"></article-item>
          </template>

          <template v-if="articleLists[section.id] && articleLists[section.id].length < 3">
            <div class="col-xs-12 col-sm-6 col-md-4 content-placeholder" v-for="i in 3 - articleLists[section.id].length" :class="{'hidden-xs': i > 1, 'hidden-sm': i > 2}">
              <div>
              </div>
            </div>

            <h4 class="col-xs-12 no-content" v-if="articleLists[section.id].length === 0">
              <span v-if="$route.params.lang === 'en'">No Content</span>
              <span v-else>暂无内容</span>
            </h4>
          </template>
        </div>
      </section>
    </div>

  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import SectionHeader from '~/components/SectionHeader.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import MediaArticleItem from '~/components/MediaArticleItem.vue'
import GArticle from '~/components/GArticle'
import { findCurrentCategory } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: { FixedContainer, NavAside, SectionHeader, ArticleItem, MediaArticleItem, GArticle },
  async asyncData ({ store, route }) {
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const subNav = currentCategory.children_nav || []
    const subNavIds = subNav.map(s => s.id)

    await Promise.all(subNav.map(s => {
      return store.dispatch('fetchArticleListOfCategory', { id: s.id })
    }))

    const sArticleLists = subNavIds.reduce((o, k) => {
      o[k] = store.state.lists[k].filter(a => {
        const langs = ['zh', 'en']
        return langs[a.lang] === route.params.lang
      })
      return o
    }, {})

    const sArticleIds = subNavIds.reduce((list, id) => {
      return list.concat(sArticleLists[id].map(a => a.id))
    }, [])

    const cArticleList = (await store.dispatch('fetchArticleListOfCategory', { id: currentCategory.id, lang: route.params.lang })).filter(cArticle => {
      return !sArticleIds.includes(cArticle.id)
    })

    let cArticle = {}

    if (cArticleList.length >= 1) {
      cArticle = await store.dispatch('fetchArticleContent', { id: cArticleList[0].id })
    }

    return {
      subNavIds,
      // sArticleIds,
      currentCategory,
      subNav,
      sArticleLists,
      cArticleList,
      cArticle
    }
  },
  computed: {
    articleLists () {
      return this.subNavIds.reduce((o, id) => {
        o[id] = this.sArticleLists[id].slice(0, 6)
        return o
      }, {})
    },
    // currentCategory () {
    //   return findCurrentCategory(this.$store.state.nav, this.$route.fullPath)
    // },
    // subNav () {
    //   console.log()
    //   return this.currentCategory.children_nav || []
    // },
    lang () {
      return this.$route.params.lang
    },
    // articleLists () {
    //   return Object.keys(this.$store.state.lists).reduce((o, k) => {
    //     o[k] = this.$store.state.lists[k].filter(a => {
    //       const langs = ['zh', 'en']
    //       return langs[a.lang] === this.$route.params.lang
    //     }).slice(0, 6)
    //     return o
    //   }, {})
    // },
    needShowAsideNav () {
      return this.subNav.reduce((need, sub) => {
        return need || 'children_nav' in sub
      }, false)
    },
    contentClass () {
      if (this.needShowAsideNav) {
        return 'col-xs-12 col-md-10'
      } else {
        return 'col-xs-12'
      }
    }
  }
}
</script>