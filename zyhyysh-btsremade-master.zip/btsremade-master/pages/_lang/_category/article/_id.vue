<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;

    h5 {
      margin-top: 0;
      margin-bottom: 20px;
      font-weight: bolder;
    }
  }
}
</style>

<template>
  <div class="row page-article">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="currentCategory[`name_${$route.params.lang}`]" :sub="subNav" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12" :class="hasList ? 'col-md-7' : 'col-md-10'">
      <!-- <ol class="breadcrumb">
        <li>
          <nuxt-link :to="currentCategory.link">{{currentCategory.name_zh}}</nuxt-link>
        </li>
        <li>
          <nuxt-link :to="currentSection.link">{{currentSection.name_zh}}</nuxt-link>
        </li>
      </ol> -->
      <article>
        <h2>{{article.title}}</h2>
        <h5>{{article.description}}</h5>
        <!-- <h3 class="time">{{time}}</h3> -->

        <section v-html="articleContent">
        </section>
      </article>
    </div>

    <div class="col-xs-12 col-md-3" v-if="hasList">
      <div class="row article-list">
        <h5 class="col-xs-12">相关内容</h5>
        <template v-for="article in articleList">
          <div class="col-xs-12 col-sm-6 col-md-12" v-if="currentCategory.absname.match(/^\/media-center/)">
            <media-article-item :link="`/${$route.params.lang}${currentCategory.link}/article/${article.id}`"
                                :cover="article.cover"
                                :title="article.title"
                                :media="article.keywords"
                                :date="article.description"></media-article-item>
          </div>
          <article-item v-else
                        class="col-xs-12 col-sm-6 col-md-12 in-aside"
                        in-parent="aside"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="`/${$route.params.lang}${currentCategory.link}/article/${article.id}`"
                        :img="article.cover"></article-item>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import MediaArticleItem from '~/components/MediaArticleItem.vue'
import { findCurrentCategory, readContent } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    FixedContainer, NavAside, ArticleItem, MediaArticleItem
  },
  async asyncData ({ store, route, app }) {
    const id = route.params.id
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    // const currentSection = findCurrentSection(store.state.nav, route.fullPath, -1).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentCategory.id, lang: route.params.lang })
    // console.log('category: ', getCategoryOfSection(store.state.nav, currentSection.id).id, currentCategory.id, articleList)
    const article = await store.dispatch('fetchArticleContent', { id })

    return {
      currentCategory,
      // currentSection,
      articleList: articleList.filter(a => String(a.id) !== String(article.id)).slice(0, 6),
      hasList: articleList.length > 1,
      article,
      articleContent: readContent(article.content)
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    },
    subNav () {
      console.log()
      return this.currentCategory.children_nav || []
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    contentClass () {
      if (this.hasList) {
        return 'col-xs-12 col-md-6'
      } else {
        return 'col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2'
      }
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path.split('/').slice(0, -1).join('/')}/${article.id}`
    }
  }
}
</script>