<style lang="less">
.page-section {
  .content-placeholder {
    // padding: 2rem 0;
    // background: #f0f0f0;
    div {
      border-top: 2px solid black;
    }
  }

  .no-content {
    // text-align: center;
    padding-top: 4rem;
    padding-bottom: 4rem;
  }
}
</style>
<template>
  <div class="row page-section">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="currentCategory[`name_${$route.params.lang}`]" :sub="subNav" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>
    <div class="col-xs-12 col-md-10">

      <section-header :section="currentSection"></section-header>

      <div class="row article-list">
        <!-- <h5 class="col-xs-12" v-if="articleList.length === 0">暂无内容</h5> -->
        <template v-for="article in displayList">
          <div class="col-xs-12 col-sm-6 col-md-4" v-if="currentCategory.absname.match(/^\/media-center/)">
            <media-article-item :link="`/${$route.params.lang}${currentCategory.link}/article/${article.id}`"
                                :cover="article.cover"
                                :title="article.title"
                                :media="article.keywords"
                                :date="article.description"></media-article-item>
          </div>
          <article-item v-else 
                        class="col-xs-12 col-sm-6 col-md-4"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="`/${$route.params.lang}${currentCategory.link}/article/${article.id}`"
                        :img="article.cover"></article-item>
        </template>

        <template v-if="articleList.length < 3">
          <div class="col-xs-12 col-sm-6 col-md-4 content-placeholder" v-for="i in 3 - articleList.length" :class="{'hidden-xs': i > 1, 'hidden-sm': i > 2}">
            <div>
            </div>
          </div>

          <h4 class="col-xs-12 no-content" v-if="articleList.length === 0">
            <span v-if="$route.params.lang === 'en'">No Content</span>
            <span v-else>暂无内容</span>
          </h4>
        </template>
      </div>

      <footer>
        <!-- <button class="btn-page-prev" :disabled="currentPage === 1">
          <span class="caret"></span>
        </button>
        <input type="number" v-model="currentPage">
        <p class="total-page">{{pageCount}}</p>
        <button class="btn-page-next" :disabled="currentPage === pageCount">
          <span class="caret"></span>
        </button> -->
        <pager v-model="currentPage" :max="pageCount" v-if="pageCount > 1"></pager>
      </footer>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import SectionHeader from '~/components/SectionHeader.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import MediaArticleItem from '~/components/MediaArticleItem.vue'
import Pager from '~/components/Pager.vue'
import { findCurrentCategory, findCurrentSection } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    FixedContainer, SectionHeader, NavAside, ArticleItem, MediaArticleItem, Pager
  },
  async asyncData ({ store, route, app, redirect }) {
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const currentSection = findCurrentSection(store.state.nav, route.fullPath).nav
    const subNav = currentCategory.children_nav

    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id, lang: route.params.lang })

    if (articleList.length === 1) {
      redirect(`/${route.params.lang}${currentCategory.link}/article/${articleList[0].id}`)
    }

    return {
      currentCategory,
      currentSection,
      subNav,
      articleList,
      currentPage: Number(route.query.page) || 1
    }
  },
  data () {
    return {
      articlePerPage: 24
      // currentPage: 1
    }
  },
  watch: {
    currentPage (v) {
      window.scroll(0, 0)
    }
  },
  computed: {
    displayList () {
      const startIdx = (this.currentPage - 1) * this.articlePerPage
      const endIdx = Math.min(this.currentPage * this.articlePerPage, this.articleList.length)

      return this.articleList.slice(startIdx, endIdx)
    },
    pageCount () {
      return Math.ceil(this.articleList.length / this.articlePerPage)
    },
    // currentCategory () {
    //   return findCurrentCategory(this.$store.state.nav, this.$route.fullPath)
    // },
    // subNav () {
    //   console.log()
    //   return this.currentCategory.children_nav || []
    // },
    extendInfo () {
      return this.$store.state.tempNavInfo[this.currentSection.id]
    },
    descp () {
      return this.extendInfo['descp_zh'] || []
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.fullPath}/${article.id}`
    },
    getExtendInro (id) {
      return this.$store.state.tempNavInfo[id]
    }
  }
}
</script>