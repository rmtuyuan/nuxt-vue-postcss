<style lang="less">
.page-home {
  section {
    header {
      margin-bottom: 50px;
    }

    p {
      &.p1 {
        font-size: 1rem;
        font-weight: 400;
        line-height: 2rem;
        // background-color: white;
      }

      &.p2 {
        font-size: .875rem;
        font-weight: 400;
        line-height: 2em;
        margin-bottom: 20px;
        // background-color: white;
      }

      &.p3 {
        font-size: .75rem;
        font-weight: 400;
        line-height: 1.5em;
        // background-color: white;
      }

      &.p-address {
        opacity: .5;
      }
    }

    p.p1 + p.p1 {
      margin-top: 2rem;
    }

    &.index-section-1 {
      
    }

    .group-section-sel {
      margin-top: 60px;
      display: flex;
      align-items: flex-end;
    }

    .btn-section-sel {
      border: none;
      background: none;
      outline: none;
      margin: 0;
      padding: .5em 0;
      width: 100%;
      text-align: left;
      border-bottom: 2px solid rgba(0, 0, 0, 0.1);
      min-height: 44px;
      // margin-top: 60px;
      color: rgba(0, 0, 0, .3);

      @media only screen and (min-width: 768px) {
        border-bottom: 2px solid black;
      }

      &.active {
        border-color: black;
        color: black;
      }
    }

    article {
      // .row + .row {
      //   margin-top: 60px;
      // }

      h3, h4, h5 {
        span {
          // background-color: white;
        }
      }

      hr {
        opacity: .1;
        margin-top: 100px;
        margin-bottom: 50px;
      }

      .content-img {
        margin-top: 30px;
        margin-bottom: 30px;
      }

      .content-img-s {
        // margin-top: 20px;
        margin-bottom: 20px;
      }

      .inner-section + .inner-section {
        margin-top: 60px;
      }

      .inner-section-s + .inner-section-s {
        margin-top: 20px;
      }

      p + h5 {
        margin-top: 30px;
      }

      .figure {
        padding-top: 60px;

        &.figure-4 {
          hr {
            margin-top: 40px;
            margin-bottom: 60px;
          }
        }
      }

      .figure :first-child :first-child {
        margin-top: 0;
      }

      .flex-bottom {
        display: flex;
        flex-direction: column;
        justify-content: flex-end;

        p:last-child {
          margin-bottom: 20px;
        }
      }

      .offset-desktop {
        @media only screen and (min-width: 960px) {
          margin-top: -40px!important;
        }
      }
    }
  }

  section + section {
    margin-top: 200px;
  }

  .home-header {
    position: relative;

    .sh-cover {
      width: 100%;
      height: 0;
      padding-bottom: 50%;
      background-size: cover;
      background-position: 80% 50%;
      background-repeat: no-repeat;

      @media only screen and (min-width: 768px) {
        padding-bottom: 40%;
        background-position: center;
      }
    }

    .title-group {
      position: absolute;
      // left: 50px;
      // right: 50px;
      left: 0;
      bottom: 0px;

      @media only screen and (min-width: 768px) {
        bottom: 30px;
      }

      h3 span {
        font-size: 25px;
        background-color: white;
      }

      hr {
        border-color: white;
        border-width: 2px;
      }
    }
  }
}
</style>

<template>
  <div class="page-home">
    <section class="row index-section-1">
      <div class="col-xs-12">
        <header class="home-header">
          <div class="sh-inner">
            <div class="row">
              <div class="col-xs-12">
                <div class="sh-cover" :style="`background-image: url(/index_section_1.jpg)`"></div>
              </div>
              <div class="title-group has-cover col-xs-12 col-sm-10 col-sm-offset-1">
                <h3>
                  <span class="impact" v-if="lang === 'en'">About BAITASI Historical Culture District</span>
                  <span v-else>关于白塔寺历史文化保护区</span>
                </h3>
                <hr>
              </div>
            </div>
          </div>
        </header>
      </div>
      <div class="col-xs-12 col-sm-10 col-sm-offset-1">
        <div class="row">
          <div class="col-xs-12 col-sm-6" v-if="lang === 'en'">
            <p class="p2">Baitasi (the White Pagoda Temple) is a historical and cultural preservation zone covering about 37 h㎡ located just across Beijing’s Financial Street in Xicheng district. To its north is the Xizhimen business district and to its west is the Fuchengmen commercial area and the Sanlihe administrative district. The Xidan and Xisi shopping areas border the temple to its east. Baitasi remains a peaceful cultural oasis for the public in the heart of new Beijing.</p>
            <p class="p2"> Baitasi (the White Pagoda Temple) is a historical and cultural preservation zone covering about 37 h㎡ located just across Beijing’s Financial Street in Xicheng district. To its north is the Xizhimen business district and to its west is the Fuchengmen commercial area and the Sanlihe administrative district. The Xidan and Xisi shopping areas border the temple to its east. Baitasi remains a peaceful cultural oasis for the public in the heart of new Beijing.</p>
          </div>
          <div class="col-xs-12 col-sm-6" v-else>
            <p class="p1">白塔寺历史文化保护区位于北京市西城区，总占地面积约为37公顷，与国家金融中心——“北京金融街”仅一街之隔，北面西直门商务区，西望阜成门商圈、三里河政务区，东临西单、西四商圈。白塔寺区域是一个为众商圈包围的拥有丰富文化遗产的绿洲，社区生活恬静安逸。</p>
            <p class="p1"> “白塔寺历史文化保护区”的历史可追溯至元代，历经明清延续至今，是横贯首都朝阜干线的西起点，具有深厚的历史底蕴和丰富的文化内涵。区内拥有元朝修建的北京最古老的城市景点——妙应寺白塔、罕见的藏经阁、以中国文学巨匠鲁迅故居为基础修建的北京鲁迅博物馆和鲁迅故居，还有体现中西合璧建筑艺术的民国四合院……汇集了古都文化、市井风情文化和名人故居，堪称西城区的“文脉”。</p>
          </div>

          <div class="col-xs-12 col-sm-5 col-sm-offset-1">
            <img class="img-responsive" src="/index_s1_content_1.jpg">
          </div>
        </div>
      </div>
    </section>

    <section class="row index-section-2">
      <div class="col-xs-12">
        <header class="home-header">
          <div class="sh-inner">
            <div class="row">
              <div class="col-xs-12">
                <div class="sh-cover" :style="`background-image: url(/index_section_2.jpg)`"></div>
              </div>
              <div class="title-group has-cover col-xs-12 col-sm-10 col-sm-offset-1">
                <h3>
                  <span class="impact" v-if="lang === 'en'">About BAITASI Remade</span>
                  <span v-else>关于白塔寺再生计划</span>
                </h3>
                <hr>
              </div>
            </div>
          </div>
        </header>
      </div>
      <article class="col-xs-12 col-sm-10 col-sm-offset-1">
        <div class="row">
          <div class="col-xs-12" v-if="lang === 'en'">
            <p class="p2">Baitasi is located in an old low-rise residential district of Beijing, one of the last remaining traditional residential areas in the capital. Currently, options are being explored to provide an alternative path for urban renovation and community revival.</p>
            <p class="p2">With societal advancements, people have realized that standard large-scale demolition and construction of Beijing’s urban core is no longer viable. In its stead, small-scale, organic renovation models are attracting greater attention and use. The main objective of the Beijing Huarong Jinying Investment & Development Company’s “Baitasi Remade” project is to establish a new model for local residents with the aid of public participation and model enterprises and government leadership. It hopes to establish a sustainable population, revitalize the physical spaces, upgrade to basic energy sources, and re-engineer the public environment, thus fostering a cultural revitalization of the region as a whole. While maintaining the unique character of Hutong neighbourhoods and the residential functions of traditional courtyards, “Baitasi Remade” will inject new elements of design as well as cultural and creative models to create a new cultural district comprehensively integrating tradition, innovation, and style.</p>
          </div>
          <div class="col-xs-12" v-else>
            <p class="p1">白塔寺区域地处北京民宅聚集的老街区，也是这个古都仅存的最后几个低矮建筑群居民区之一，目前正在探索和开辟一条新的城市升级和社区复兴发展之路。随着社会的进步，原来大拆大建的方式在城市核心区已经不再适用。而微循环、有机更新的模式得到了更多的重视和运用。北京华融金盈投资发展有限公司为“白塔寺再生计划”项目的实施主体，按照北京首都功能定位，通过政府主导、企业示范、社会力量参与、本地居民共建的新模式，制定出人口持续疏解、物质空间更新、基础能源提升、公共环境再造、培育文化触媒和区域整体复兴的实施路径。在保持独具一格的胡同肌理和老北京传统的四合院居住片区原有居住功能属性不变的情况下，通过植入设计、文创和展览展示等新的元素，全面营造融合传统、创意、时尚的新文化街区。</p>
          </div>
        </div>

        <div class="row group-section-sel">
          <div class="col-xs-12 col-sm-3">
            <button class="btn-section-sel" :class="{'active': showFigureIdx === 1}" @click="showFigureIdx = 1">
              <h4>
                <span class="impact-s" v-if="lang === 'en'">Continuous movement of residents to areas of low residential densities</span>
                <span v-else>人口持续疏解</span>
              </h4>
            </button>
          </div>
          <div class="col-xs-12 col-sm-3">
            <button class="btn-section-sel" :class="{'active': showFigureIdx === 2}" @click="showFigureIdx = 2">
              <h4>
                <span class="impact-s" v-if="lang === 'en'">Improvement of public environment</span>
                <span v-else>街区环境改善</span>
              </h4>
            </button>
          </div>
          <div class="col-xs-12 col-sm-3">
            <button class="btn-section-sel" :class="{'active': showFigureIdx === 3}" @click="showFigureIdx = 3">
              <h4>
                <span class="impact-s" v-if="lang === 'en'">Introduction of cultural catalysts</span>
                <span v-else>文化触媒引入</span>
              </h4>
            </button>
          </div>
          <div class="col-xs-12 col-sm-3">
            <button class="btn-section-sel" :class="{'active': showFigureIdx === 4}" @click="showFigureIdx = 4">
              <h4>
                <span class="impact-s" v-if="lang === 'en'">Design and creation of communities</span>
                <span v-else>社区设计营造</span>
              </h4>
            </button>
          </div>
        </div>

        <div class="row figure figure-1" v-if="showFigureIdx === 1">
          <div class="col-xs-12">
            <img class="img-responsive content-img" src="/index_s2_f1_01.jpg">
            <p class="p2" v-if="lang === 'en'">The scope of the movement of residents from Baitasi area starts from Zhaodengyu Road in the east, Fuchengmennei Street in the south, and the planned road at Shoubi Street in the north. In 2013, the plan to fulfill the agreement on vacating and returning buildings for Baitasi project had gone through examination and been kept on file. It invokes the principle of governmental leadership, voluntary residents, justice and fairness, and vacating and returning buildings as a whole, sticks to the vital role of human beings, leads residents to move out, and is implemented in three different ways, housing-, money-, and equivalent-based settlements. A model of agreed vacating and returning of buildings has been gradually developed, acquiring the ability to start the movement in the community, and the demonstrative effect of vacating and returning buildings has initially existed, lowering the density of residents within the area, and improving residential and living standards.</p>
            <p class="p2" v-else>白塔寺地区人口疏解范围东起赵登禹路，西至西二环东辅路，南起阜成门内大街，北至受壁街规划路，采取政府主导、居民自愿、公平公正、整院腾退的原则，以房屋安置、货币安置及平移置换安置三种不同的方式进行，坚持以人为本，引导人口外迁，降低区域内人口密度，改善居民的住房及生活条件。</p>
          </div>
          <div class="col-xs-12"></div>
        </div>

        <div class="row figure figure-2" v-if="showFigureIdx === 2">
          <div class="col-xs-12 col-sm-6">
            <div class="row inner-section">
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-offset-0">
                <h4>
                  <span class="impact-m" v-if="lang === 'en'">Improvement of public environment</span>
                  <span v-else>公共环境提升</span>
                </h4>
                <p class="p2" v-if="lang === 'en'">For “Baitasi Remade Plan”, the mission to improve “lines”, the three main municipal lines of Shoubi Street, Funei Street, and Funei North Street, has been launched now, so that, by carrying out the transformations in many aspects such as street conditions remediation, landscape improvement, road planning, and buildings renovation, the style and features of ancient streets can be recovered at last, and they can be transformed into those that are not only suitable for urban lives and serve commercial and residential functions, but also embody the space with high-quality streets to the glory of old streets history and culture.</p>
                <p class="p2" v-else>“白塔寺再生计划”现已启动受壁街、阜内大街、阜内北街三大市政主干道——“线”的提升工作，通过街道环境整治、景观提升、公共基础设施改造、道路规划、建筑更新等多方面进行改造实施，最终还原古街道风貌，将其改造成适合当代城市生活要求并符合商业与居住功能，且彰显老街历史文化光辉的优质街道空间。</p>
              </div>
            </div>
            <div class="row inner-section">
              <div class="col-xs-12 col-sm-10">
                <img class="img-responsive content-img" src="/index_s2_f2_01.jpg">
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-offset-0 inner-section-s">
                <template v-if="lang === 'en'">
                  <h5><span>Shoubi Street Project</span></h5>
                  <p class="p3">The Shoubi Street Project includes road, traffic, architecture, structure, water supply and drainage, lighting, greening and utility tunnel engineering, and lay 8 municipal pipelines for rainwater, sewage, supply water, reclaimed water, power, telecommunication, fuel gas and heat distribution underground respectively. In the meanwhile, it introduces mechanical underground parking available for about 500 vehicles, which relieves the parking pressure of Baita Temple historical protection zone; also. It is the first to put forward the innovative measures of building mechanical parking garage under the newly-built municipal roads, which improves and promotes the production and life quality of residents living along the area.</p>
                </template>
                <template v-else>
                  <h5><span>受壁街项目</span></h5>
                  <p class="p3">受壁街项目包含道路、交通、建筑、结构、给水、排水、照明、绿化及综合管廊工程，在道路路面下集约敷设雨水、污水、给水、再生水、电力、电信、燃气、热力8条市政管线。同时，引入机械地下车库，可提供地下停车位约500辆，缓解白塔寺历史风貌保护区内停车压力，这也是国内率先提出在新建市政道路下建设机械式停车库的创新举措，改善和提高沿线居民的生产和生活品质。</p>
                </template>
              </div>
              <div class="col-xs-12 col-sm-10 inner-section-s">
                <img class="img-responsive content-img" src="/index_s2_f2_02.jpg">
              </div>
            </div>
          </div>
          <div class="xol-xs-12 col-sm-6">
            <div class="row inner-section">
              <div class="col-xs-12">
                <img class="img-responsive content-img" src="/index_s2_f2_03.jpg">
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-offset-2">
                <template v-if="lang === 'en'">
                  <h5><span>North Fuchengmen Street project</span></h5>
                  <p class="p3">North Fuchengmen Street, as the traffic trunk of the Baita Temple cultural protection zone connecting the south and north areas as well as the main passage accessing Lu Xun Museum, has various traditional architectures in complete shape and structure, and the high and bushy locust trees along both sides of the passage add unique artistic tincture to the space. The reconstruction project of street environmental landscape of the North Fuchengmen Street and the building façade has perfected the landscape environment of the street and repaired the worn and damaged facades, enabling the commercial and settlement functions of the contemporary era and manifesting a high-quality street space with historic culture.</p>
                </template>
                <template v-else>
                  <h5><span>阜内北街项目</span></h5>
                  <p class="p3">阜内北街是白塔寺文化保护片区内联系南北区域的交通干路，同时也是进出鲁迅博物馆的主要通路，内有多个形制完好的传统建筑，道路两侧高大浓密的行道槐树为该空间增添了独特的意境。阜内北街街道环境景观与立面改造项目已完成街道的景观环境改善，对破旧劳损的建筑立面进行修补并，使其符合当代商业与居住功能，且彰显老街历史文化光辉的优质街道空间。</p>
                </template>
              </div>
            </div>
            <div class="row inner-section">
              <div class="col-xs-12">
                <img class="img-responsive content-img" src="/index_s2_f2_04.png">
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-offset-2">
                <template v-if="lang === 'en'">
                  <h5><span>Inner Fuchengmen Street project</span></h5>
                  <p class="p3">Inner Fuchengmen Street renovation and revitalization plan aims at remodeling a constant and safe old living street full of cultural atmosphere, covering the construction of municipal belt, wire & pole undergrounding and overall combination, promotion of road traffic organization, repaving of pedestrian way, functional zone optimization, perfection of urban furniture, supplement of block greening, building of landscape at main nodes, comprehensive treatment of wall demolition and burrowing along the street, repair of building façade and other overall transforming and upgrading work in multiple aspects. And the Inner Fuchengmen Street, when rebuilt, will demonstrate the praise of “most beautiful street” by Lao She from eight aspects, i.e. “four-optimization”: optimization of safe and smooth motion line, optimization of row upon row of buildings, optimization of convenient and fresh facilities, optimization of supporting functions; “four-beauties”: “walking view”, “magnificent pavement”, “fine details” and “simple and unique lighting”.</p>
                </template>
                <template v-else>
                  <h5><span>阜内大街项目</span></h5>
                  <p class="p3">阜内大街整治复兴计划旨在重塑一条连续的、安全的、充满人文气息的生活老街。涵盖了市政带建设、线杆入地及统筹合并、道路交通组织提升、人行步道重铺、功能分区优化、城市家具的完善、街区绿化增补及重要节点的景观打造、沿街拆墙打洞的综合整治及建筑立面的修缮等多方面、全方位整体改造提升工作。建成后的阜内大街重点从“四优”： ‘安全顺畅的动线优化’‘鳞次栉比的建筑优化’、‘便捷清新的设施优化’‘完善的配套功能优化’，“四美”：‘移步成景的视野’、‘沉稳大气的铺装’、‘精雕细琢的细节’、‘简约独特的照明’八个方面映证老舍先生“最美大街”的赞誉。</p>
                </template>
              </div>
            </div>
          </div>
          
          <div class="col-xs-12">
            <hr>
          </div>

          <div class="col-xs-12">
            <div class="row inner-section">
              <div class="col-xs-12">
                <h4>
                  <span class="impact-m" v-if="lang === 'en'">Demonstration of renewed courtyards</span>
                  <span v-else>院落更新示范</span>
                </h4>
                <p class="p2" v-if="lang === 'en'">Located in the old street area where Beijing’s traditional quadrangles cluster together, Batasi area is also one of the last few low-building residential areas that have been preserved in this ancient capital. Such persons in architectural industry as Zhang Ke, an architect for creating standards, Hua Li, founder and chief architect of TAO (Trace Architecture Office), Dong Gong, founding partner of Vector Architects, and Xu Tiantian, chief architect of DNA_design and Architecture, have launched a series of case study and discussion activities as well as the mission to carry out the pilot project of “renewing and transforming small courtyards”. Meanwhile, in “Batasi Remade Plan”, transformation plans have been widely collected through the competition from international participants for the plans to renew courtyards, with some of transformed and renewed small courtyards being demonstrated, improving the living standards for ordinary people, leading residents to adapt themselves to modern lifestyles, injecting new energy into communities, and driving regional renewal and revival. </p>
                <p class="p2" v-else>白塔寺区域地处北京传统四合院聚集的老街区，也是这个古都保留的最后几个低建筑群居民区之一。标准营造建筑师张轲、TAO迹建筑事务所创始人及主持建筑师华黎、直向建筑创始合伙人董功、DNA_design and Architecture建筑设计事务所主持建筑师徐甜甜等建筑界人士，启动一系列建筑案例研讨活动及“小院儿更新改造”试点项目实施工作，同时，“白塔寺再生计划”通过院落更新国际方案征集大赛广泛征集改造方案，以部分小院的改造更新示范，改善百姓生活品质，引领居民应变现代生活方式，为社区注入新的活力，带动区域的更新和再生。</p>
              </div>
            </div>
            <div class="row inner-section">
              <div class="col-xs-12 col-sm-3 inner-section-s">
                <div class="row">
                  <div class="col-xs-12">
                    <img class="img-responsive" src="/index_s2_f2_05.jpg">
                  <!-- </div> -->
                  <!-- <div class="col-xs-12 col-sm-6"> -->
                    <template v-if="lang === 'en'">
                      <h5><span>Courtyard house</span></h5>
                      <p class="p3 p-address">No. 32 courtyard, Gongmenkousitiao</p>
                      <p class="p3">This design constructs the original dwelling-based courtyard into an artistic space integrating artist living, workshop and public exhibition hall, etc. While reserving the main structure of the original architecture, it adds two outdoor courtyards according to the field texture and environment to bear the natural shadow. The main wall indoors, stretching upwards to the roof, becomes the ridge of the roof garden. Moreover, the arc language and white texture used in the design extends the image of Baita Temple into the Hutong, and the vegetable shed frame of the roof garden echoes the living atmosphere of the Hutong.</p>
                    </template>
                    <template v-else>
                      <h5><span>盒院</span></h5>
                      <p class="p3 p-address">宫门口四条32号院</p>
                      <p class="p3">该设计将原来以居住为功能的院落改造成一个包括艺术家起居、工作室、公共展厅等场所的艺术空间，在保留原建筑主要结构基础上，根据场地肌理和环境，植入两个室外院落，承载自然光影。室内主要墙体向上延伸至屋顶，成为屋顶花园的田埂。设计中使用的弧形语言和白色纹理，向胡同中延伸了白塔寺的印象，屋顶花园的植物棚架呼应了胡同里的生活气息。</p>
                    </template>
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-3 inner-section-s">
                <div class="row">
                  <div class="col-xs-12">
                    <img class="img-responsive" src="/index_s2_f2_06.jpg">
                  <!-- </div> -->
                  <!-- <div class="col-xs-12 col-sm-6"> -->
                    <template v-if="lang === 'en'">
                      <h5><span>Quadrangle parted courtyard</span></h5>
                      <p class="p3 p-address">No. 24 courtyard, Gongmenkousitiao</p>
                      <p class="p3">All the rooms of the traditional quadrangle courtyards are towards the center, for which spatial arrangement is corresponding to the traditional family life. However, a quadrangle parted courtyard, with room towards different directions, is for young people and mutually forms a windmill-shape layout at the end. The change from “integrated” to “parted” reveals the conversion of social structure and life mode in residence.</p>
                    </template>
                    <template v-else>
                      <h5><span>四分院</span></h5>
                      <p class="p3 p-address">宫门口四条24号院</p>
                      <p class="p3">传统四合院所有的房间都朝向中心，这种空间布局对应着传统的家庭生活，不再契合今天青年人的个人生活模式。为保证私密性，该设计将场地分为四组空间，每组包含一个房间和一个私人小院，它们各自朝向不同的方向，最终共同构成一个风车状布局。从“合”到“分”的变化揭示出社会结构和生活模式在住宅中的转变。</p>
                    </template>
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-3 inner-section-s">
                <div class="row">
                  <div class="col-xs-12">
                    <img class="img-responsive" src="/index_s2_f2_07.jpg">
                  <!-- </div> -->
                  <!-- <div class="col-xs-12 col-sm-6"> -->
                    <template v-if="lang === 'en'">
                      <h5><span>Mutualistic courtyard</span></h5>
                      <p class="p3 p-address">No. 36 courtyard, Gongmenkousitiao</p>
                      <p class="p3">Through extending connection of timber roof truss and wall integration, replacing reconstruction with renovation, it creates three spaces: “inserted dwelling unit” (8m2), public exhibition space (84m2) and all-in-one functional module (4.5m2, with functions of kitchen, laundry, washroom, storage, etc.). Mutualistic private dwelling and public exhibition surrounding the courtyard furthest improves the pressing infrastructure problem influencing on living in Hutong.</p>
                    </template>
                    <template v-else>
                      <h5><span>共生院</span></h5>
                      <p class="p3 p-address">宫门口四条36号院</p>
                      <p class="p3">设计通过木屋架延伸连接，墙体整合强化等，翻修取代重建，创造三个空间：“插入式居住单元”（8㎡）、公共展览空间（84㎡）、一体化功能模块（4.5㎡，设置厨房、洗衣、卫生间、储物等多项功能）。私人居住于公共展览环绕院子共生，最大程度地改善影响胡同生活最迫切的基础设施问题。</p>
                    </template>
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-3 inner-section-s">
                <!-- <div class="row"> -->
                  <!-- <div class="col-xs-12 col-sm-6"> -->
                    <img class="img-responsive" src="/index_s2_f2_08.jpg">
                  <!-- </div> -->
                  <!-- <div class="col-xs-12 col-sm-6"> -->
                    <template v-if="lang === 'en'">
                      <h5><span>Mixed courtyard</span></h5>
                      <p class="p3 p-address">No. 22 courtyard, Gongmenkousitiao</p>
                      <p class="p3">Through partition of the courtyard space, its functions of exhibition, cultural activities, academic activities, little theatre, office, etc. are able to be mixed and mutualistic. In addition, it has sufficient outdoor courtyard space. Based on the traditional construction mode, it adds glass brick, bamboo steel and other new building materials and mode of construction, which not only reserves the quiet atmosphere of the traditional quadrangle courtyard, but also meets the demand of contemporary life.</p>
                    </template>
                    <template v-else>
                      <h5><span>混合院</span></h5>
                      <p class="p3 p-address">宫门口四条22号院</p>
                      <p class="p3">通过对院子空间的划分，使展览、文化活动、学术聚会、小剧场、办公等多种功能得以混合共生，且拥有充分的户外院落空间，在传统建造方式的基础上，加入了玻璃砖、竹钢等新型建筑材料和构造方式，既保留了传统四合院的安静气质，又适应了当代生活的需求。</p>
                    </template>
                  <!-- </div> -->
                <!-- </div> -->
              </div>
            </div>
          </div>

          <div class="col-xs-12">
            <hr>
          </div>

          <div class="col-xs-12 col-sm-6">
            <h4>
              <span class="impact-m" v-if="lang === 'en'">A pilot project for “administrative coalition and spatial integration”</span>
              <span v-else>联合连片试点</span>
            </h4>
            <template v-if="lang === 'en'">
              <p class="p2">In the pilot project for renewal through “administrative coalition and spatial integration”, Qingta and Gongmenkoutoutiao areas are taken as the scope of the pilot project. In accordance with the requirement of the municipal Party committee and authorities for the task of “jointly managing with concerted efforts and speeding up the construction of a world first-class harmonious and livable capital city”, by means of repositioning the functions not specific to a capital city and comprehensively governing the city by law, and through continuous relocation of residents, the residential density and structure are adjusted, and through the introduction of fundamental energy, as well as local improvement based on administrative coalition and spatial integration, the residential conditions in the areas are improved, the quality of public environment is enhanced, the types of local business are adjusted and optimized,  and the upgrading of local functions and the revival of the areas as a whole are realized.</p>
              <p class="p2">Under the challenge of current situation where residential conditions in the old city area of Beijing are characterized by fragmentation and high residential density, the model of highly detailed planning, designing and managing based on such micro-operational units as “courtyard” and “room width” is proposed in the pilot project for renewal through “administrative coalition and spatial integration”. It fully respects the boundaries of existing property rights and relevant conditions for planning and management, presupposing that new construction area is as less as possible, dimensional features are not changed, and no public spaced is invaded. Through “coalition” of communities and “integration” of spaces, and oriented towards the type of full property rights, it leads residents to participate in the renewal of old city involving courtyards, as well as local improvement. Aiming to improve the overall image of locality and residential quality, and sticking to the general principle that the layout of local courtyards remains unchanged, it improves the style and features of the old city as a whole. </p>
            </template>
            <template v-else>
              <p class="p2">“联合连片”更新试点项目以青塔片区及宫门口头条片区作为试点范围，按照市委市政府关于“齐抓共管，加快建设国际一流和谐宜居之都”的工作要求，以非首都功能疏解、城市依法综合治理为手段，通过持续疏解，调整区域人口密度和结构；通过引入基础能源，联合连片就地改善，改善区域居住条件，提升公共环境品质；调整提升区域业态，实现区域功能更新和区域整体复兴。</p>
              <p class="p2">“联合连片”更新试点项目是在北京旧城人居环境碎片化和高密度的现状挑战下，提出基于“院落”和“开间”等微观操作单元的精细化规划、设计和管理模式。充分尊重现有产权边界和相关规划管控条件，以尽可能不新增建筑面积，不改变体量风貌，不侵占公共空间为前提。从社区上“联合”、从空间上“连片”，面向全产权类型，带动居民和院落参与旧城更新，就地改善，以实现片区的整体形象和居住品质提升为目标，总体原则是保持片区院落格局不变，提升旧城整体风貌。</p>
            </template>
          </div>

          <div class="col-xs-12 col-sm-5 col-sm-offset-1">
            <img class="img-responsive" src="/index_s2_f2_09.jpg">
          </div>
        </div>

        <div class="row figure figure-3" v-if="showFigureIdx === 3">
          <div class="col-xs-12 col-sm-5">
            <p class="p2" v-if="lang === 'en'">The industries of design, cultural creation, and art have the features such as relatively high cultural content, environmental friendliness and sustainable development, able to better incorporate original local culture, maximally mitigating the effect of commerce on local residents. On condition that Baitasi area’s original quality of having residential functions remains unchanged, the utilization efficiencies of various resources are enhanced, and a platform for demonstration, communication, and release is set up for “cultural industry”, to boost the energy for local development. Its main functions are focused on the gathering of architects and artists; its core lies in the establishment of the system for a public service platform in the community; its highlight is its role as an incubator for creative projects; and a new cultural street area integrating design, creation and art is finally formed.</p>
            <p class="p2" v-else>设计、文创、艺术产业具备较高的文化内涵、环保以及可持续发展等特点，可以与原有的属地文化进行较好的融合，最大化的淡化商业对与地居民的冲突，白塔寺区域将在保持原有居住功能属性不变的情况下，提升各项资源的利用效率，为“文化产业”搭建起一个展示，交流，发布的平台，激发本地区的发展活力。主要职能将以设计师与艺术家集聚为重点；以建立社区公共服务平台体系为核心；以创意项目孵化为亮点；最终形成设计、创意和艺术创作为一体的新文化街区。</p>
          </div>
          <div class="col-xs-12 col-sm-6 col-sm-offset-1 inner-section">
            <div class="row">
              <div class="col-xs-12 inner-section-s">
                <template v-if="lang === 'en'">
                  <h5><span>New commercial clients plan</span></h5>
                  <p class="p3">Popular and high quality brands are introduced to the shops through “new commercial clients plan”, creating a good commercial environment for the community and surrounding areas, so as to attract new cultural creation industry and business entities.</p>
                </template>
                <template v-else>
                  <h5><span>新商客计划</span></h5>
                  <p class="p3">通过“新商客计划”引进聚集人气的高品质品牌店，为社区和周边营造良好的商业环境，从而吸引新的文创产业及从业主进驻。</p>
                </template>
              </div>
              <div class="col-xs-12 inner-section-s">
                <template v-if="lang === 'en'">
                  <h5><span>New literati plan</span></h5>
                  <p class="p3">International cultural and art exchange organizations as well as practitioners of cultural creation and young creators are introduced through “new literati plan”, and cultural salons and creative ideas-exchanging activities are held on irregular basis, bringing fresh energy and industrial elements to the community.</p>
                </template>
                <template v-else>
                  <h5><span>新雅客计划</span></h5>
                  <p class="p3">通过“新雅客计划”引入国际文化、艺术交流机构、文创工作者和青年创客，不定期举办文化沙龙和创意交流活动，为社区注入新鲜活力和产业基因。</p>
                </template>
              </div>
              <div class="col-xs-12 inner-section-s">
                <template v-if="lang === 'en'">
                  <h5><span>New residents plan</span></h5>
                  <p class="p3">With perfect complementary commercial facilities in surrounding areas and general cultural atmosphere across the whole area, new groups of people are attracted and move in. The enterprises of “new residents plan” set up platforms, interfacing local resources with social resources, so as to optimize the structure of residents, and enhance local consuming ability.</p>
                </template>
                <template v-else>
                  <h5><span>新居客计划</span></h5>
                  <p class="p3">凭借周边完善的商业配套和整院的文化氛围，吸引新兴人群入住。“新居客计划”企业搭建平台，实现本地资源和社会资源的对接，从而优化居住人口的结构，提升区域消费能力。</p>
                </template>
              </div>
            </div>
          </div>
          <div class="col-xs-12 inner-section">
            <img class="img-responsive" src="/map.png">
          </div>
        </div>

        <div class="row figure figure-4" v-if="showFigureIdx === 4">
          <div class="col-xs-12 inner-section">
            <p class="p2" v-if="lang === 'en'">The way to carry out the task of creating communities in Baitasi area is to study and find the historical cultural contents within the area where Batasi’s historical style and features have been preserved, lead local residents to take part in collective activities and projects, seek social contributions to the transformation of the one-story houses in the old city area, think new thoughts about brand promotion, enable residents to convey locally common ideas and values in their capacity as a host and actively participate in the protection and renewal of the old city, finally achieve the self-organized governing from lower to upper levels, and strike a balance between the governing in descending order and the self-organized one.</p>
            <p class="p2" v-else>白塔寺地区社区营造工作的开展，是通过研究挖掘白塔寺历史风貌保护区内的历史文化内涵，带动地区内居民参与的集体活动及项目，吸纳关注旧城平房区改造的社会力量融入，开拓品牌推广思路，使居民能够以主人翁的身份传递地区共同理念和价值，主动参与到旧城保护更新，最终实现自下而上的自组织治理，并寻求自上而下的层级治理和自组织治理的平衡。</p>
          </div>
          <div class="col-xs-12">
            <hr>
            <div class="row">
              <div class="col-xs-12 col-md-8 col-md-offset-1 col-md-push-3">
                <img class="img-responsive content-img-s" src="/index_s2_f4_01.jpg">
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-3 col-md-offset-0 col-md-pull-9 flex-bottom">
                <template v-if="lang === 'en'">
                  <h5><span>Featuring the enhancement of brand making</span></h5>
                  <p class="p3">During the task of creating communities, brand making and promotion enable the residents in the community to have a sense of self-identity and destination, and a sense of locality reputation enhancement, while increasing the cohesion of local culture, enhancing residents’ awareness of community culture, and encouraging residents to participate in community management in a spontaneous, conscious and independent manner</p>
                </template>
                <template v-else>
                  <h5><span>品牌建设提升</span></h5>
                  <p class="p3">社区营造工作中，品牌建设及推广，使社区居民产生社区认同感和归属感，提升地区荣誉感，同时凝聚区域文化力，增强居民社区文化意识，促动居民自发、自觉、自主的参与到社区管理。</p>
                </template>
              </div>
            </div>
          </div>

          <div class="col-xs-12">
            <hr>
            <div class="row">
              <div class="col-xs-12 col-sm-6 col-md-4">
                <img class="img-responsive content-img-s" src="/index_s2_f4_02.jpg">
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4">
                <img class="img-responsive content-img-s" src="/index_s2_f4_03.jpg">
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-3 col-md-offset-1 flex-bottom">
                <template v-if="lang === 'en'">
                  <h5><span>Featuring socal organization</span></h5>
                  <p class="p3">The possibility of cooperation with social organizations and agencies has been actively explored for the task of creating communities in Baitasi area, and the power of social organizations has been put into community activities. By leading the way for residents to participate, the social connection between residents and culture, history, and environment has been established.</p>
                </template>
                <template v-else>
                  <h5><span>社会组织引导</span></h5>
                  <p class="p3">白塔寺地区社区营造工作积极拓展社会组织机构合作可能性，将社会组织力量注入到社区活动当中，通过引导居民参与的方式，建立起居民与该地区人文、历史、环境的社会联系。</p>
                </template>
              </div>
            </div>
          </div>

          <div class="col-xs-12">
            <hr>
            <div class="row">
              <div class="col-xs-12 col-md-8 col-md-offset-1 col-md-push-3">
                <div class="row">
                  <div class="col-xs-12 col-sm-6">
                    <img class="img-responsive content-img-s" src="/index_s2_f4_04.jpg">
                  </div>
                  <div class="col-xs-12 col-sm-6">
                    <img class="img-responsive content-img-s" src="/index_s2_f4_05.jpg">
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-3 col-md-offset-0 col-md-pull-9 flex-bottom">
                <template v-if="lang === 'en'">
                  <h5><span>Featuring the dominance of residents’ will</span></h5>
                  <p class="p3">The procedures for collecting public opinions precede the community-creating activities in the street area of Batasi, accurately reflecting the will of people. The creating activities directed according to residents’ will are gradually recovering the cultural features of Beijing’s hutongs, fostering and building the awareness and ability of community among residents.</p>
                </template>
                <template v-else>
                  <h5><span>居民意愿主导</span></h5>
                  <p class="p3">社区营造工作中，品牌建设及推广，使社区居民产生社区认同感和归属感，提升地区荣誉感，同时凝聚区域文化力，增强居民社区文化意识，促动居民自发、自觉、自主的参与到社区管理。</p>
                </template>
              </div>
            </div>
          </div>

          <div class="col-xs-12 inner-section">
            <hr>
            <div class="row">
              <div class="col-xs-12 col-sm-6 col-md-4">
                <img class="img-responsive content-img-s" src="/index_s2_f4_06.jpg">
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4">
                <img class="img-responsive content-img-s" src="/index_s2_f4_07.jpg">
              </div>
              <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-3 col-md-offset-1 flex-bottom">
                <template v-if="lang === 'en'">
                  <h5><span>Featuring the demonstration of implementing subject</span></h5>
                  <p class="p3">For the implementing subject of Baitasi Remade Plan, community-creating activities are carried out with such methods as joining hands with local cultural agencies and international cooperation, and in the form of demonstration, to explore the ways of transforming old cities and improving living environment.</p>
                </template>
                <template v-else>
                  <h5><span>实施主体示范</span></h5>
                  <p class="p3">白塔寺再生计划实施主体通过联合地区文化机构、开展国际合作等方式，以示范形式开展社区营造活动，探索旧城更新改造、提升居住环境的途径。</p>
                </template>
              </div>
            </div>
          </div>
        </div>
      </article>
    </section>
  </div>
</template>

<script>
import SectionHeader from '~/components/SectionHeader.vue'

export default {
  components: { SectionHeader },
  data () {
    return {
      showFigureIdx: 1
    }
  },
  computed: {
    lang () {
      return this.$route.params.lang || 'zh'
    }
  }
}
</script>