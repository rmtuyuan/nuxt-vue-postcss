<template></template>
<script>
export default {
  asyncData ({redirect}) {
    redirect('/baita-event#baitasi-international-design-competition')
  }
}
</script>