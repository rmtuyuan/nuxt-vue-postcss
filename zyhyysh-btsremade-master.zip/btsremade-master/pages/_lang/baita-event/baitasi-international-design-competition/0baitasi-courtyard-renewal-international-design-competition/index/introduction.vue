<style lang="less" scoped>
.page-intro {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }
}
</style>

<template>
  <article>
    <!-- <h2>{{article.title}}</h2> -->

    <section class="article-container" v-html="article.htmlContent">
    </section>
  </article>
</template>

<script>
import querystring from 'querystring'
import { findCurrentSection, readContent } from '~/assets/js/utils'
// import { json2html } from 'html2json'

// const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  async asyncData ({ store, app, route }) {
    // const sections = store.getters.btevent.sub

    // let currentSection = sections.filter(s => s.name === 'baitasi-international-design-competition').pop().sub.filter(s => s.name === section).pop().sub.filter(s => s.name === 'introduction').pop()

    // const id = currentSection.article

    // let res = await app.$axios.$post('articleinfo', querystring.stringify({
    //   login_uid: 'glabcms',
    //   article_id: id,
    //   status: '0'
    // }))

    // if (String(res.code) === '100200') {
    //   console.log(res)
    //   res.data['id'] = id
    //   res.data['section'] = section
    //   store.commit('updateArticle', res.data)
    // }

    // return {
    //   currentSection,
    //   // newarticle,
    //   article: store.state.articles[id]
    // }
    let currentSection = findCurrentSection(store.state.nav, route.fullPath).nav

    let { code, data: list } = await app.$axios.$post('article_list', querystring.stringify({
      login_uid: 'glabcms',
      id: currentSection.id
    }))

    if (String(code) === '100200' && list.length > 0) {
      const articleid = list.pop().id
      let { code, data: article } = await app.$axios.$post('articleinfo', querystring.stringify({
        login_uid: 'glabcms',
        article_id: articleid,
        status: '0'
      }))

      if (String(code) === '100200') {
        article['htmlContent'] = readContent(article.content)

        return {
          article: article
        }
      }
    }

    // console.log(res, article, readContent(''))

    return {
      article: '<p>no data</p>'
    }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    },
    currentSection () {
      return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    articles () {
      return this.currentSection.articles.map(id => {
        return this.$store.state.articles[id]
      }).filter(article => {
        if (article) {
          return article
        }
      }).slice(0, 4)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path}/${article.id}`
    // },
    // readPageData (n) {
    //   function delHtmlTag (str) {
    //     return str.replace(/(<p[^>]*>)|(<\/p>)/gi, '') // 去掉所有的html标记
    //   }
    //   var Node = document.querySelector('.article-container')
    //   let read = function () {
    //     n.child.forEach(function (val) {
    //       if (val.child) {
    //         val.child.forEach(function (value) {
    //           if (value.tag === 'img') {
    //             let Img = document.createElement('img')
    //             Img.src = value.attr.src
    //             Node.appendChild(Img)
    //           } else if (value.tag === 'p') {
    //             if (value.child[0].text === '请输入文本') { } else {
    //               var P = document.createElement('p')
    //               // let html = transfer.json2html(value)
    //               let html = json2html(value)
    //               // console.log(delHtmlTag(html))
    //               P.innerHTML = delHtmlTag(html)
    //               Node.appendChild(P)
    //             }
    //           }
    //         })
    //       }
    //     })
    //   }
    //   read()
    }
  },
  mounted () {
    // console.log(json2html(this.article.content))
    // this.readPageData(window.JSON.parse(this.article.content))
  }
}
</script>
