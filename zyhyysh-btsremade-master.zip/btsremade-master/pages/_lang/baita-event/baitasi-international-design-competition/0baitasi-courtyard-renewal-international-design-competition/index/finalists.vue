<template>
  <div>finalists</div>
</template>

<script>
export default {}
</script>
