<style lang="less" scoped>
article {
  section {
    font-size: .875rem;

    img {
      margin-bottom: 2rem;
    }

    h3 {
      text-align: center;
      margin-top: 4rem;
      margin-bottom: 2rem;

      span {
        display: inline-block;
        background: black;
        color: white;
        padding: .25em 2em;
      }
    }

    h4 {
      text-decoration: underline;
      margin-top: 2rem;
      margin-bottom: 1rem;
    }

    ul, ol {
      padding-left: 1rem;
    }

    p.weak, .weak p {
      opacity: .6;
      font-size: .75rem;
    }

    h4.weak {
      opacity: .6;
      margin: 0;
      text-decoration: none;
    }
  }
}
</style>

<template>
  <article>
    <!-- <h2>{{article.title}}</h2> -->
    <section>
      <img class="img-responsive" src="/task2016banner.jpg">

      <h2>白塔寺院落更新大赛任务书</h2>
      <h4 class="weak">“北京小院儿的重生”</h4>
    </section>

    <section class="article-container">
      <p>白塔寺是北京中心城区的重要历史街区之一，其历史可以追溯到元代，至今已接近800年，较好地保留了胡同当年的肌理和风貌格局。妙应寺白塔不仅是当时元大都的城市标志，如今也是二环内的标志性建筑，这一地区已成为北京最具特色的风貌街区，被列为北京旧城33片历史文化保护区之一，具有深厚的历史底蕴和文化内涵。</p>
      <p>白塔寺项目试图通过对院落空间的修缮整治，重新让“小院儿”再现空间功能复合多样的可能性，让空间重生，让多种功能共存。在居住功能的基础上，在“小院儿”中叠加富于活力的设计、文创相关功能，挖掘并引入文化触媒，复兴区域内胡同文化，在胡同和院落中，重新找回东方的居住理想，从传统中寻找古老的建筑智慧，试图重新激发旧城空间的活力，探索此类区域与城市发展结合的途径。</p>
      <p>此次公开的国际竞赛为位于白塔寺的3个组团内的12个院落征集更新方案。<br>符合设计导则及具有报建可能的入围作品将由主办方另行委托，实地实施，<br>为白塔寺区域、北京更广泛的旧城区域甚至中国众多城市中旧城区域的更新发展提供参考。</p>
    </section>

    <section>
      <h3><span>目标</span></h3>
      <h4>1.空间形态目标</h4>
      <p>维护北京旧城肌理<br>维护白塔寺片区主要街区肌理<br>塑造白塔寺片区院落风貌</p>
      <h4>2.经济活力目标</h4>
      <p>调整旧城产业结构，激发经济活性<br>重新焕发社区活力</p>
      <h4>3.功能复合目标</h4>
      <p>确保院落满足居住需求<br>附加其他功能，为文创发展提供多种可能邻里环境适宜与社会公平目标<br>改善邻里生活环境，增强居民安全、舒适、自豪感<br>增强社区自主及发展机会</p>
    </section>

    <section>
      <h3><span>设计要求</span></h3>
      <p>在理解白塔寺社区背景、基础设施条件与实际生活需求的基础上，为3个组团12个院落中的1个院落进行更新方案设计。<br>参赛方案需遵循设计导则要求，与此同时，本次竞赛鼓励参赛者进行深入细致的调研，提出具有创造性、想象力的设计方案。</p>
    </section>

    <section>
      <h3><span>设计通则</span></h3>
      <p>本部分适用于所有院落</p>
      <p class="weak">设计范围包括建筑、室内、景观（含夜景照明）<br>设计方案应附初步概算，造价指标上线为10，000元/m2（含精装修）</p>
      <h4>1.地段用途与控制</h4>
      <ul>
        <li>
          <p>建筑功能业态定位参照功能定位表</p>
        </li>
        <li>
          <p>各院落更新方案边界要求围合，并要保证原有用地红线的完整</p>
        </li>
      </ul>
      <h4>2.历史保护与传承</h4>
      <ul>
        <li>
          <p>结合院落特点，宜在可能情况下保留院落部分有价值的历史痕迹及历史特征</p>
        </li>
        <li>
          <p>院落装饰特色如有历史价值，应考虑保留或利用</p>
        </li>
      </ul>
      <h4>3.空间形态与格局</h4>
      <ul>
        <li>
          <p>不得遮挡标志性建筑（妙应寺白塔）相关的视觉通廊</p>
        </li>
        <li>
          <p>不得影响公共空间使用</p>
        </li>
        <li>
          <p>不得破坏原有胡同肌理及胡同界面的统一性与完整性</p>
        </li>
      </ul>
      <h4>4.交通控制与梳理</h4>
      <ul>
        <li>
          <p>应注意院落内外流线衔接</p>
        </li>
        <li>
          <p>应注意尽可能结合无障碍设计</p>
        </li>
        <li>
          <p>应注意人员疏散的功能需求</p>
        </li>
      </ul>
      <h4>5.建筑风貌</h4>
      <ul>
        <li>
          <p>空间最高点及檐口高度禁止突破每处院落的具体限制条件</p>
        </li>
        <li>
          <p>建筑外墙、屋面材料、色彩、风格与院落入口处理应与街巷有效衔接</p>
        </li>
        <li>
          <p>建筑沿街界面屋顶形式不得采用坡顶以外的其他屋顶形式</p>
        </li>
      </ul>
      <h4>6.建筑景观</h4>
      <ul>
        <li>
          <p>应延续原有街区标志性景观特征</p>
        </li>
        <li>
          <p>应选用本地植物，植株应考虑北京特点及四合院传统</p>
        </li>
      </ul>
      <h4>7.建筑设计</h4>
      <ul>
        <li>
          <p>结合不同组团功能设定，应合理配置院落功能需求</p>
        </li>
        <li>
          <p>建筑面积指标不得超过原有建筑面积</p>
        </li>
        <li>
          <p>室内净高超过单层计算标准时，按二层计算建筑面积</p>
        </li>
        <li>
          <p>可考虑红线范围内地坪以下0.6m的空间利用</p>
        </li>
        <li>
          <p>宜结合生产、生活需要，添加必要设施空间</p>
        </li>
        <li>
          <p>宜考虑舒适度与节能性</p>
        </li>
        <li>
          <p>应避免自遮挡，以及遮挡相邻建筑采光</p>
        </li>
        <li>
          <p>不得影响相邻院落房屋门窗的开启</p>
        </li>
      </ul>
      <h4>8.市政设施</h4>
      <ul>
        <li>
          <p>现状无市政热力、燃气接入</p>
        </li>
        <li>
          <p>现状交流220V电源接入、市政自来水接入</p>
        </li>
        <li>
          <p>应合理考虑雨水、污水有组织排放</p>
        </li>
        <li>
          <p>应注意线杆和电箱等市政设施对建筑设计的影响</p>
        </li>
      </ul>
    </section>

    <section>
      <h3><span>设计原则</span></h3>
      <h4>1.针对性</h4>
      <p>结合组团功能需求，实际赋予院落文化功能</p>
      <h4>2.可实施性</h4>
      <p>方案具有可操作、实施的可能性</p>
      <h4>3.可持续发展</h4>
      <p>考虑实际使用中的相关因素，确保可有效使用，并具有后续利用与改造的可能</p>
    </section>

    <section>
      <h3><span>作品提交</span></h3>
      <ul>
        <li>
          <p>请以电子文件在线提交图纸和相关文件。</p>
        </li>
        <li>
          <p>语言：竞赛官方语言为中文与英文，标题和主要设计说明必须包含英文。</p>
        </li>
        <li>
          <p>文件资料：根据所获得的报名编码提交可辨认的身份证明扫描件、设计团队署名确认书及原创声明及授权书。</p>
        </li>
        <li>
          <p>概念方案作品规格及要求</p>
          <ol class="weak">
            <li>
              <p>规格：请以420mm × 297mm 图纸版面横向排版，每项作品须由4幅图纸组成，上传文件格式为JPG（用于网站展示，单张不超3MB）及PDF（用于文件存档，文件不超过20MB）。</p>
            </li>
            <li>
              <p>内容及表现形式：中英文设计说明，黑白线条绘制平面、立面、剖面及轴测图，必要的分析图，必要的建筑经济指数及造价估算；可选增透视图、渲染图、墙身剖面详图、构造节点详图、实物模型照片等。</p>
            </li>
          </ol>
        </li>
        <li>
          <p>入围方案作品规格及要求</p>
          <ol class="weak">
            <li>
              <p>规格：请以841mm × 594mm 图纸版面横向排版，每项作品须由3幅图纸组成，文件格式为PDF，文件不超过20MB。</p>
            </li>
            <li>
              <p>内容及表现形式：中英文设计说明，平面、立面、剖面、透视图，必要的分析图，建筑经济指数及造价估算；可选增墙身剖面详图、构造节点详图、实物模型照片等。</p>
            </li>
            <li>
              <p>不多于3分钟的设计介绍视频，文件格式为MP4，文件大小不超过400MB。</p>
            </li>
          </ol>
        </li>
      </ul>
    </section>

    <section>
      <h3><span>参赛规则</span></h3>
      <ol>
        <li>
          <p>报名参加本次竞赛的个人或小组视为同意并遵守本竞赛通知的内容及竞赛规则；竞赛组委会对竞赛规则拥有最终解释权；</p>
        </li>
        <li>
          <p>电子图纸中不得出现任何有关设计者姓名、所在院校或工作单位的文字或图案，不符合规定者将被取消参赛资格；</p>
        </li>
        <li>
          <p>参赛作品不得一稿两投，参加过其他竞赛的作品或使用他人曾经在公开场合发表过的创意的作品不得参加本次竞赛；</p>
        </li>
        <li>
          <p>参赛作品涉及的图纸、图片不得侵害他人著作权，如引起争议，参赛者负全责，并将被取消参赛资格；</p>
        </li>
        <li>
          <p>参赛者拥有参赛作品的署名权，但竞赛组织者与出资单位有权行使参赛作品署名权以外的其他版权权利。</p>
        </li>
      </ol>
    </section>

    <section>
      <h3><span>竞赛流程</span></h3>
      <ul>
        <li>
          <p>本竞赛采取自由报名、公开竞赛的方式。参赛者可以个人或小组形式参赛，每组成员不超过4人，指导教师不超过2名。</p>
        </li>
        <li>
          <p>每组设立一位联络人，由联络人注册参赛账号即可，在线填写注册。</p>
        </li>
        <li>
          <p>报名费为每组300元人民币，报名费无特殊情况不予退还。报名通过银行渠道按竞赛官网提供的账号汇款，汇款不支持支付宝、微信等第三方支付，竞赛网站上所填写的银行卡信息仅用于核对汇款。</p>
        </li>
        <li>
          <p>报名分第一阶段、第二阶段，报名时间以报名费成功汇出时间为准</p>
          <p class="weak">2016年6月1-30日，报名第一阶段，凡在本阶段报名成功的参赛者可自选院落参赛<br>2016年7月1-31日，报名第二阶段，凡在本阶段报名成功的参赛者将由官方网站自动分配院落</p>
        </li>
        <li>
          <p>主办方确认报名费收到后会发送确认邮件提供下载院落资料的链接。</p>
        </li>
        <li>
          <p>报名者获得院落资料后即可按照上述报名阶段选择院落或由网站予以分配。</p>
        </li>
        <li>
          <p>院落选定后会得到报名编码，根据报名编码填写设计团队署名确认书及原创声明及授权书。</p>
        </li>
        <li>
          <p>参赛者一律提交电子版作品，提交截止日期为2016年7月31日。竞赛组委会不接收纸质版作品。</p>
        </li>
        <li>
          <p>在竞赛组委会的协助下，评审团对参赛方案进行评审，并确定获奖作品。</p>
        </li>
        <li>
          <p>竞赛组委会将于2016年9月5日前公布入围作品名单。</p>
        </li>
        <li>
          <p>最终获奖名单将于最终评审会上公布。</p>
        </li>
        <li>
          <p>有关竞赛的疑问请在线提问，组委会会尽快给予回复。</p>
        </li>
      </ul>
    </section>

    <section>
      <img class="img-responsive" src="/taskmap.jpg">
      <ul class="weak">
        <li>
          <p>建筑改造设计方案需符合组团功能定位、设计导则及院落详表中的要求，其他功能布局分布及面积自拟；</p>
        </li>
        <li>
          <p>语言及量度单位：标题、设计说明及图注需中英文对照；度量单位为公制。</p>
        </li>
      </ul>
    </section>
  </article>
</template>

<script>
import querystring from 'querystring'
import { json2html } from 'html2json'

const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  layout: 'default',
  async asyncData ({ store, app }) {
    const sections = store.getters.btevent.sub

    let currentSection = sections.filter(s => s.name === 'baitasi-international-design-competition').pop().sub.filter(s => s.name === section).pop().sub.filter(s => s.name === 'tasks').pop()

    const id = currentSection.article

    let res = await app.$axios.$post('articleinfo', querystring.stringify({
      login_uid: 'glabcms',
      article_id: id,
      status: '0'
    }))

    if (String(res.code) === '100200') {
      console.log(res)
      res.data['id'] = id
      res.data['section'] = section
      store.commit('updateArticle', res.data)
    }

    return {
      currentSection,
      // newarticle,
      article: store.state.articles[id]
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    articles () {
      return this.currentSection.articles.map(id => {
        return this.$store.state.articles[id]
      }).filter(article => {
        if (article) {
          return article
        }
      }).slice(0, 4)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path}/${article.id}`
    },
    readPageData (n) {
      function delHtmlTag (str) {
        return str.replace(/(<p[^>]*>)|(<\/p>)/gi, '') // 去掉所有的html标记
      }
      var Node = document.querySelector('.article-container')
      let read = function () {
        n.child.forEach(function (val) {
          if (val.child) {
            val.child.forEach(function (value) {
              if (value.tag === 'img') {
                let Img = document.createElement('img')
                Img.src = value.attr.src
                Node.appendChild(Img)
              } else if (value.tag === 'p') {
                if (value.child[0].text === '请输入文本') { } else {
                  var P = document.createElement('p')
                  // let html = transfer.json2html(value)
                  let html = json2html(value)
                  // console.log(delHtmlTag(html))
                  P.innerHTML = delHtmlTag(html)
                  Node.appendChild(P)
                }
              }
            })
          }
        })
      }
      read()
    }
  },
  mounted () {
    // console.log(json2html(this.article.content))
    // this.readPageData(window.JSON.parse(this.article.content))
  }
}
</script>
