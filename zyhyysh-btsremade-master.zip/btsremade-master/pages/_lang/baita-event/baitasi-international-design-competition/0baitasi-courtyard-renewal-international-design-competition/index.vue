<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-article row">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <nav-aside category="白塔事件" :sub="sections"></nav-aside>
    </div>

    <div class="col-xs-12 col-md-10">
      <nuxt/>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'

// const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  async asyncData ({ store, route, app }) {
    // let currentSection = findCurrentSection(store.state.nav, route.fullPath).nav

    // let res = await app.$axios.$post('article_list', querystring.stringify({
    //   login_uid: 'glabcms',
    //   id: currentSection.id
    // }))
    // return {
    //   articleList: (String(res.code) === '100200') ? res.data : []
    // }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    // },
    // currentSection () {
    //   return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    }
  }
}
</script>