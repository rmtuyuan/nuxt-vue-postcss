<style lang="less">
.page-work-detail {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .carousel-placeholder {
    display: none;
  }

  .carousel-container {
    position: relative;
    height: 0;
    padding-bottom: 50%;
    overflow: hidden;
    margin-bottom: 2rem;

    .simple-carousel {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }

    &:hover {
      .slider-control-prev,
      .slider-control-next {
        display: block;
      }
    }

    .slider-control-prev,
    .slider-control-next {
      display: none;
      position: absolute;
      top: 0;
      bottom: 0;
      width: 40px;
      z-index: 1;
      background: none;
      border: none;
      outline: none;
      background-color: rgba(0, 0, 0, .4);
    }
    .slider-control-prev {
      left: 0;
    }
    .slider-control-next {
      right: 0;
    }

    &.fullscreen {
      .simple-carousel {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100vw;
        height: 100vh;
        margin: 0;
        padding: 0;
        z-index: 2000;
        background-color: rgba(0, 0, 0, 0.9);
      }

      .slider-control-next,
      .slider-control-prev {
        position: fixed;
        z-index: 2001;
        background-color: transparent;
      }
    }
  }

  .article-container {
    img {
      display: none;
    }
  }
}

</style>

<template>
  <div class="page-work-detail container">
    <div class="row">
      <div class="col-xs-2 hidden-xs hidden-sm">
        <nav-aside category="白塔事件" :sub="sections"></nav-aside>
      </div>

      <div class="col-xs-12 col-md-10">
        <div class="carousel-placeholder" ref="carousel-placeholder" v-html="article.imgContent"></div>
        <div class="carousel-container" :class="{'fullscreen': showFullScreen}">
          <!-- <div class="carousel" ref="carousel">
            <template v-for="(img, index) in sortedList">
              <div class="carousel-item"
                   :class="{'active': index === cIdx, 'next': (index === cIdx + 1 || (cIdx === cChildren.length - 1 && index === 0)), 'prev': (index === cIdx - 1 || (cIdx === 0 && index === cChildren.length - 1))}"
                   :style="`background-image: url(${img})`" 
                   :key="img"></div>
              <div class="carousel-item"
                   :class="{'active': index === 1, 'next': index === 2, 'prev': index === 0}"
                   :style="`background-image: url(${img})`"
                   :key="img"></div>
            </template>
          </div> -->
          <simple-carousel ref="carousel" 
                           :images="cChildren"
                           autoplay 
                           loop
                           @click.native="showFullScreen = !showFullScreen"></simple-carousel>

          <button class="slider-control-prev" @click="cPrev">
            <svg width="15px" height="44px" viewBox="0 0 15 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
              <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="Artboard" transform="translate(-82.000000, -18.000000)" fill="rgba(255,255,255,.7)">
                  <polygon id="Mask-Copy-2" points="97 62 93.0105594 62 82 40 93.0105594 18 97 18 85.9894406 40"></polygon>
                </g>
              </g>
            </svg>
          </button>
          <button class="slider-control-next" @click="cNext">

          <svg width="15px" height="44px" viewBox="0 0 15 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
              <g id="Artboard" transform="translate(-102.000000, -18.000000)" fill="rgba(255,255,255,.7)">
                <polygon id="Mask-Copy-3" points="102 62 105.989441 62 117 40 105.989441 18 102 18 113.010559 40"></polygon>
              </g>
            </g>
          </svg>
          </button>
        </div>

        <article>
          <h2>{{article.title}} <span>{{article.keywords}}</span></h2>
          <h5 class="author">{{article.description}}</h5>
          <hr>
          <section class="article-container">
            <h3>设计理念</h3>
            <div v-html="article.textContent"></div>
          </section>
        </article>
      </div>
    </div>
  </div>
</template>

<script>
import SimpleCarousel from '~/components/SimpleCarousel.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
// import querystring from 'querystring'
// import { json2html } from 'html2json'
import { findCurrentSection, readContent } from '~/assets/js/utils'

// const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  layout: 'default',
  components: {
    SimpleCarousel, NavAside, ArticleItem
  },
  async asyncData ({ route, store, app }) {
    const id = route.params.id

    console.log('work id: ', id)
    // const sections = store.getters.btevent.sub

    // let currentSection = sections.filter(s => s.name === 'baitasi-international-design-competition').pop().sub.filter(s => s.name === section).pop().sub.filter(s => s.name === 'all-candidates').pop()

    // if (!(id in store.state.articles)) {
    //   await Promise.all(currentSection.articles.filter(id => {
    //     return !Object.keys(store.state.articles).includes(id)
    //   }).map(async id => {
    //     let res = await app.$axios.$post('articleinfo', querystring.stringify({
    //       login_uid: 'glabcms',
    //       article_id: id,
    //       status: '0'
    //     }))

    //     if (String(res.code) === '100200' && res.data.content) {
    //       res.data['id'] = id
    //       res.data['section'] = section
    //       store.commit('updateArticle', res.data)
    //       return res.data
    //     } else {
    //       return null
    //     }
    //   }))
    // }

    // return {
    //   sections,
    //   currentSection,
    //   article: store.state.articles[id]
    // }

    // let { code, data } = await app.$axios.$post('articleinfo', querystring.stringify({
    //   login_uid: 'glabcms',
    //   article_id: id,
    //   status: '0'
    // }))

    // console.log(code, data)
    let article = await store.dispatch('fetchArticleContent', { id })

    if (article) {
      article['htmlContent'] = readContent(article.content)
      article['textContent'] = readContent(article.content, ['p'])
      article['imgContent'] = readContent(article.content, ['img'])
      return {
        article
      }
    }
  },
  data () {
    return {
      cIdx: 0,
      cChildren: [],
      showFullScreen: false
    }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    },
    currentSection () {
      return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    },
    sortedList () {
      if (this.cIdx === 0) {
        return [this.cChildren[this.cChildren.length - 1]].concat(this.cChildren.slice(0, 2))
      } else if (this.cIdx === this.cChildren.length - 1) {
        return this.cChildren.slice(this.cChildren.length - 2).concat(this.cChildren[0])
      } else {
        return this.cChildren.slice(this.cIdx - 1, this.cIdx + 2)
      }
    }
  },
  methods: {
    // readPageData (n, parent, renderTags) {
    //   renderTags = renderTags || ['img', 'p']
    //   function delHtmlTag (str) {
    //     return str.replace(/(<p[^>]*>)|(<\/p>)/gi, '') // 去掉所有的html标记
    //   }
    //   var Node = document.querySelector(parent)
    //   let read = function () {
    //     n.child.forEach(function (val) {
    //       if (val.child) {
    //         val.child.forEach(function (value) {
    //           if (renderTags.includes(value.tag)) {
    //             if (value.tag === 'img') {
    //               let Img = document.createElement('img')
    //               Img.src = value.attr.src
    //               Node.appendChild(Img)
    //             } else if (value.tag === 'p') {
    //               if (value.child[0].text === '请输入文本') { } else {
    //                 var P = document.createElement('p')
    //                 // let html = transfer.json2html(value)
    //                 let html = json2html(value)
    //                 // console.log(delHtmlTag(html))
    //                 P.innerHTML = delHtmlTag(html)
    //                 Node.appendChild(P)
    //               }
    //             }
    //           }
    //         })
    //       }
    //     })
    //   }
    //   read()
    // },
    cSetup () {
      this.cChildren = Array.prototype.slice.call(this.$refs['carousel-placeholder'].querySelectorAll('img')).map(img => img.src)
    },
    cNext () {
      // this.cIdx += 1
      // if (this.cIdx >= this.cChildren.length) {
      //   this.cIdx = 0
      // }
      this.$refs.carousel.next()
    },
    cPrev () {
      // this.cIdx -= 1
      // if (this.cIdx < 0) {
      //   this.cIdx = this.cChildren.length - 1
      // }
      this.$refs.carousel.prev()
    }
  },
  mounted () {
    // this.readPageData(window.JSON.parse(this.article.content), '.carousel-placeholder', ['img'])
    // this.readPageData(window.JSON.parse(this.article.content), '.article-container', ['p'])
    this.cSetup()
  }
}
</script>