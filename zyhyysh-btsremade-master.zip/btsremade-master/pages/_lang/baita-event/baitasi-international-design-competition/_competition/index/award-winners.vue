<template>
  <div>awaid winners</div>
</template>

<script>
export default {}
</script>
