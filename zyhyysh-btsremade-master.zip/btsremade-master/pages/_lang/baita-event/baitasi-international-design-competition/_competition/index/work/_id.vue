<style lang="less">
.page-work-detail {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .carousel-placeholder {
    display: none;
  }

  .carousel-container {
    position: relative;
    height: 0;
    padding-bottom: 50%;
    overflow: hidden;
    margin-bottom: 2rem;

    .simple-carousel {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }

    &:hover {
      .slider-control-prev,
      .slider-control-next {
        display: block;
      }
    }

    .slider-control-prev,
    .slider-control-next {
      display: none;
      position: absolute;
      top: 0;
      bottom: 0;
      width: 40px;
      z-index: 1;
      background: none;
      border: none;
      outline: none;
      background-color: rgba(0, 0, 0, .4);
    }
    .slider-control-prev {
      left: 0;
    }
    .slider-control-next {
      right: 0;
    }

    &.fullscreen {
      .simple-carousel {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100vw;
        height: 100vh;
        margin: 0;
        padding: 0;
        z-index: 2000;
        background-color: rgba(0, 0, 0, 0.9);
      }

      .slider-control-next,
      .slider-control-prev {
        position: fixed;
        z-index: 2001;
        background-color: transparent;
      }
    }
  }

  .article-container {
    img {
      display: none;
    }
  }
}

</style>

<template>
  <div class="page-work-detail">
    <div class="carousel-placeholder" ref="carousel-placeholder" v-html="article.imgContent"></div>
    <div class="carousel-container" :class="{'fullscreen': showFullScreen}">
      <simple-carousel ref="carousel" 
                       :images="cChildren"
                       autoplay 
                       loop
                       @click.native="showFullScreen = !showFullScreen"></simple-carousel>

      <button class="slider-control-prev" @click="cPrev">
        <svg width="15px" height="44px" viewBox="0 0 15 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="Artboard" transform="translate(-82.000000, -18.000000)" fill="rgba(255,255,255,.7)">
              <polygon id="Mask-Copy-2" points="97 62 93.0105594 62 82 40 93.0105594 18 97 18 85.9894406 40"></polygon>
            </g>
          </g>
        </svg>
      </button>
      <button class="slider-control-next" @click="cNext">

      <svg width="15px" height="44px" viewBox="0 0 15 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="Artboard" transform="translate(-102.000000, -18.000000)" fill="rgba(255,255,255,.7)">
            <polygon id="Mask-Copy-3" points="102 62 105.989441 62 117 40 105.989441 18 102 18 113.010559 40"></polygon>
          </g>
        </g>
      </svg>
      </button>
    </div>

    <article>
      <h2>{{article.title}} <span>{{article.keywords}}</span></h2>
      <h5 class="author">{{article.description}}</h5>
      <hr>
      <section class="article-container">
        <h3>设计理念</h3>
        <div v-html="article.textContent"></div>
      </section>
    </article>
  </div>
</template>

<script>
import SimpleCarousel from '~/components/SimpleCarousel.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
// import querystring from 'querystring'
// import { json2html } from 'html2json'
import { findCurrentSection, readContent } from '~/assets/js/utils'

// const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  layout: 'default',
  components: {
    SimpleCarousel, NavAside, ArticleItem
  },
  async asyncData ({ route, store, app }) {
    const id = route.params.id

    // let { code, data } = await app.$axios.$post('articleinfo', querystring.stringify({
    //   login_uid: 'glabcms',
    //   article_id: id,
    //   status: '0'
    // }))

    // console.log(code, data)
    let article = await store.dispatch('fetchArticleContent', { id })

    if (article) {
      article['htmlContent'] = readContent(article.content)
      article['textContent'] = readContent(article.content, ['p'])
      article['imgContent'] = readContent(article.content, ['img'])
      return {
        article
      }
    }
  },
  data () {
    return {
      cIdx: 0,
      cChildren: [],
      showFullScreen: false
    }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    },
    currentSection () {
      return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    },
    sortedList () {
      if (this.cIdx === 0) {
        return [this.cChildren[this.cChildren.length - 1]].concat(this.cChildren.slice(0, 2))
      } else if (this.cIdx === this.cChildren.length - 1) {
        return this.cChildren.slice(this.cChildren.length - 2).concat(this.cChildren[0])
      } else {
        return this.cChildren.slice(this.cIdx - 1, this.cIdx + 2)
      }
    }
  },
  methods: {
    cSetup () {
      this.cChildren = Array.prototype.slice.call(this.$refs['carousel-placeholder'].querySelectorAll('img')).map(img => img.src)
    },
    cNext () {
      this.$refs.carousel.next()
    },
    cPrev () {
      this.$refs.carousel.prev()
    }
  },
  mounted () {
    this.cSetup()
  }
}
</script>