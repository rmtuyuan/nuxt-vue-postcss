<template>
  <div>
    <article>
      <section v-html="article.htmlContent"></section>
    </article>
    <!-- <g-article :content="article.content"></g-article> -->
  </div>
</template>

<script>
// import querystring from 'querystring'
import GArticle from '~/components/GArticle.vue'
import { findCurrentSection, readContent } from '~/assets/js/utils'
export default {
  components: { GArticle },
  async asyncData ({ store, app, route }) {
    if (route.params.article) {
      let currentSection = findCurrentSection(store.state.nav, route.fullPath).nav

      const list = await store.dispatch('fetchArticleListOfCategory', {
        id: currentSection.id, lang: route.params.lang
      })

      if (list && list.length > 0) {
        const articleid = list[list.length - 1].id

        let article = await store.dispatch('fetchArticleContent', {
          id: articleid
        })

        if (article) {
          article['htmlContent'] = readContent(article.content)
          const json = JSON || window.JSON

          try {
            article['obj'] = json.parse(article.content)
          } catch (e) {
            console.error('parse json error', e)
          }

          return {
            test: '123',
            article: article
          }
        }
      }
    }

    return {
      article: {
        htmlContent: '<p>No Content</p>',
        content: {}
      }
    }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    },
    currentSection () {
      return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    articles () {
      return this.currentSection.articles.map(id => {
        return this.$store.state.articles[id]
      }).filter(article => {
        if (article) {
          return article
        }
      }).slice(0, 4)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path}/${article.id}`
    }
  }
}
</script>
