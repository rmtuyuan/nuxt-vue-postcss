<style lang="less" scoped>
.page-candidates {
  .filter {
    z-index: 2;
  }

  .work-list {
    // margin-top: 2rem;
    margin-bottom: 5rem;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    z-index: 1;
  }


  .work-item {
    transition: all 1s;
  }
  .work-list-enter {
    position: absolute;
    opacity: 0;
    transform: translateY(30px);
  }

  .work-list-enter-active {
    transition: all 1s 1s;
  }

  .work-list-leave-to {
    opacity: 0;
    transform: translateY(30px);
  }
  .work-list-leave-active {
    // position: absolute;
  }
}
</style>

<template>
  <div class="page-candidates">
    <!-- <div class="row filter">
      <div class="col-xs-6 col-sm-4 col-md-3" v-for="(group, index) in currentFilterGroup">
        <selector :options="group" v-model="selectedFilter[index]" @input="_filterChange($event, index)"></selector>
      </div>
    </div> -->

    <transition-group name="work-list" tag="div" class="row work-list">
      <template v-for="work in articleList">
        <work-item class="col-xs-12 col-sm-6 col-md-4"
                   :img="work.cover"
                   :title="work.title"
                   :descp="work.description"
                   :wid="work.keywords"
                   :link="`${$route.fullPath.split('/').slice(0, -1).join('/')}/work/${work.id}`"
                   :key="`${work.keywords}${work.title}`"></work-item>
      </template>
    </transition-group>
  </div>
</template>

<script>
import WorkItem from '~/components/WorkItem.vue'
import Selector from '~/components/Selector.vue'
// import querystring from 'querystring'
import { findCurrentSection } from '~/assets/js/utils'

export default {
  components: { WorkItem, Selector },
  async asyncData ({ store, app, route }) {
    let currentSection = findCurrentSection(store.state.nav, route.fullPath).nav

    // let res = await app.$axios.$post('article_list', querystring.stringify({
    //   login_uid: 'glabcms',
    //   id: currentSection.id
    // }))

    const list = await store.dispatch('fetchArticleListOfCategory', {
      id: currentSection.id, lang: route.params.lang
    })

    return {
      articleList: list
    }
  },
  data () {
    return {
      filterGroup: [
        {
          title: '全部',
          sub: [
            {
              title: '全部',
              filterRE: /./
            }
          ]
        },
        {
          title: 'A组',
          sub: [
            {
              title: '全部',
              filterRE: /^A-/
            },
            {
              title: 'A-1',
              filterRE: /^A-1-/
            },
            {
              title: 'A-2',
              filterRE: /^A-2-/
            },
            {
              title: 'A-3',
              filterRE: /^A-3-/
            },
            {
              title: 'A-4',
              filterRE: /^A-4-/
            }
          ]
        },
        {
          title: 'B组',
          sub: [
            {
              title: '全部',
              filterRE: /^B-/
            },
            {
              title: 'B-1',
              filterRE: /^B-1-/
            },
            {
              title: 'B-2',
              filterRE: /^B-2-/
            },
            {
              title: 'B-3',
              filterRE: /^B-3-/
            },
            {
              title: 'B-4',
              filterRE: /^B-4-/
            }
          ]
        },
        {
          title: 'C组',
          sub: [
            {
              title: '全部',
              filterRE: /^C-/
            },
            {
              title: 'C-1',
              filterRE: /^C-1-/
            },
            {
              title: 'C-2',
              filterRE: /^C-2-/
            },
            {
              title: 'C-3',
              filterRE: /^C-3-/
            },
            {
              title: 'C-4',
              filterRE: /^C-4-/
            }
          ]
        }
      ],
      selectedFilter: [0, 0]
    }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    },
    currentSection () {
      return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    },
    currentFilterGroup () {
      return [
        this.filterGroup.map(f => f.title),
        this.filterGroup[this.selectedFilter[0]].sub.map(f => f.title)
      ]
    },
    currentFilterRE () {
      return this.filterGroup[this.selectedFilter[0]].sub[this.selectedFilter[1]].filterRE
    },
    articles () {
      return this.articleList
    },
    filteredArticles () {
      return this.articles.filter(a => {
        return a.keywords.match(this.currentFilterRE)
      })
    }
  },
  methods: {
    _filterChange (ev, idx) {
      // this.$set(this.selectedFilter, idx, ev)
      if (idx === 0) {
        this.$set(this.selectedFilter, 1, 0)
      }
    }
  }
}
</script>
