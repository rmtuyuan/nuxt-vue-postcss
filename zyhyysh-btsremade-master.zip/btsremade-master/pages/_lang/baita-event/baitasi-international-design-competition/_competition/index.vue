<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-article row">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <!-- <nav-aside category="白塔事件" :sub="sections"></nav-aside> -->
        <nav-aside :category="$route.params.lang === 'en' ? 'Baita Event' : '白塔事件'" :sub="sections" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <!-- <h1>test</h1> -->
      <nuxt/>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'

// const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  layout: 'default',
  components: {
    FixedContainer, NavAside, ArticleItem
  },
  asyncData ({ route, redirect }) {
    if (route.params.article === undefined && !route.fullPath.match(/(all-candidates|finalists|award-winners)/g)) {
      redirect(`/${route.params.lang}/baita-event/baitasi-international-design-competition/${route.params.competition}/introduction`)
    }
  },
  computed: {
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    }
  }
}
</script>