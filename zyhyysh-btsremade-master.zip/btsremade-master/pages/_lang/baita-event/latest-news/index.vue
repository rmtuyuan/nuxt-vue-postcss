<template></template>
<script>
export default {
  asyncData ({redirect}) {
    redirect('/baita-event#latest-news')
  }
}
</script>