<style lang="less">
.page-section {
  .content-placeholder {
    // padding: 2rem 0;
    // background: #f0f0f0;
    div {
      border-top: 2px solid black;
    }
  }

  .no-content {
    // text-align: center;
    padding-top: 4rem;
    padding-bottom: 4rem;
  }
}
</style>
<template>
  <div class="row page-section">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <!-- <nav-aside :category="currentCategory.name_zh" :sub="subNav"></nav-aside> -->
        <nav-aside :category="$route.params.lang === 'en' ? 'Baita Event' : '白塔事件'" :sub="subNav" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>
    <div class="col-xs-12 col-md-10">

      <section-header :section="currentSection"></section-header>

      <div class="row article-list">
        <!-- <h5 class="col-xs-12" v-if="articleList.length === 0">暂无内容</h5> -->
        <template v-for="article in articleList">
          <article-item class="col-xs-12 col-sm-6 col-md-4"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="getLink(article)"
                        :img="article.cover"></article-item>
        </template>

        <template v-if="articleList.length < 3">
          <div class="col-xs-12 col-sm-6 col-md-4 content-placeholder" v-for="i in 3 - articleList.length" :class="{'hidden-xs': i > 1, 'hidden-sm': i > 2}">
            <div>
            </div>
          </div>

          <h4 class="col-xs-12 no-content" v-if="articleList.length === 0">暂无内容</h4>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import SectionHeader from '~/components/SectionHeader.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { findCurrentCategory, findCurrentSection } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    FixedContainer, SectionHeader, NavAside, ArticleItem
  },
  async asyncData ({ store, route, app, redirect }) {
    const currentSection = findCurrentSection(store.state.nav, route.fullPath).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id, lang: route.params.lang })

    if (articleList.length === 1) {
      redirect(`${route.fullPath}/${articleList[0].id}`)
    }

    return {
      currentSection,
      articleList
    }
  },
  computed: {
    currentCategory () {
      return findCurrentCategory(this.$store.state.nav, this.$route.fullPath)
    },
    subNav () {
      console.log()
      return this.currentCategory.children_nav || []
    },
    extendInfo () {
      return this.$store.state.tempNavInfo[this.currentSection.id]
    },
    descp () {
      return this.extendInfo['descp_zh'] || []
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.fullPath}/${article.id}`
    },
    getExtendInro (id) {
      return this.$store.state.tempNavInfo[id]
    }
  }
}
</script>