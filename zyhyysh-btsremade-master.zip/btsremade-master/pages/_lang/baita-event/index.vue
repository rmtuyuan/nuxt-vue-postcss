<style lang="less">
.page-category.baita-event {
  .category-section {
    position: relative;

    & + .category-section {
      // margin-top: 60px;
    }

    .category-anchor {
      position: absolute;
      top: -100px;
    }

    .section-header {
      height: auto;
      padding-bottom: 0;

      .section-header-inner {
        position: relative;
        padding-top: 6rem;
        padding-bottom: 3rem;
      }

      @media only screen and (min-width: 720px) {
      //   height: 0;
      //   padding-bottom: 37%;
        .section-header-inner {
          // position: absolute;
          padding-top: 4rem;
          padding-bottom: 0;
        }
      }
    }

    .section-item {
      hr {
        // margin-bottom: 0;
      }
    }
  }
}
</style>

<template>
  <div class="row page-category baita-event">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="$route.params.lang === 'en' ? 'Baita Event' : '白塔事件'" :sub="sections" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <template v-for="section in sections">
        <section class="row category-section">
          <div class="category-anchor" :id="section.link.split('#').pop()"></div>
          <div class="col-xs-12">
            <header class="section-header" :class="{'noimg': !getExtendInfo(section.id).cover || getExtendInfo(section.id).cover.length === 0}">
              <div class="section-header-inner">
                <div class="row">
                  <div class="col-xs-10 col-xs-offset-1">
                    <h3 class="impact"  v-if="$route.params.lang === 'en'">{{section.name_en}}</h3>
                    <h3 v-else>{{section.name_zh}}</h3>
                    <hr>
                  </div>
                </div>
              </div>
            </header>
          </div>

          <template v-for="item in section.children_nav">
            <div :class="itemClass(section.children_nav.length)">
              <div class="section-item">
                <nuxt-link :to="`/${$route.params.lang}${item.link}`">
                  <header :style="`background-image: url(${getExtendInfo(item.id).imgs})`">
                    <div v-if="item.article && item.article.length" class="section-item-header-label">{{item.articles.length}}</div>
                  </header>
                  <h3>
                    <span>{{item[`name_${$route.params.lang}`]}}</span>
                  </h3>
                  <h4>{{getExtendInfo(item.id)[`sub_name_${$route.params.lang}`]}}</h4>
                  <p v-for="t in getExtendInfo(item.id)[`descp_${$route.params.lang}`]">{{t}}</p>
                </nuxt-link>
                <hr>
              </div>
            </div>
          </template>
        </section>
      </template>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import Velocity from 'velocity-animate-server'
// import querystring from 'querystring'

export default {
  layout: 'default',
  components: {
    FixedContainer, NavAside
  },
  computed: {
    sections () {
      const category = this.$store.state.nav.filter(item => item.id === 9).pop()

      return category.children_nav
    }
  },
  methods: {
    itemClass (n) {
      if (n >= 3) {
        return 'col-xs-12 col-sm-6 col-md-4'
      } else {
        return 'col-xs-12 col-sm-6'
      }
    },
    getExtendInfo (id) {
      return this.$store.state.tempNavInfo[id]
    },
    reorderItems (arr) {
      return arr.sort((a, b) => {
        return a.id < b.id
      })
    }
  },
  mounted () {
    if ('hash' in this.$route && this.$route.hash.length) {
      Velocity(this.$el.querySelector(this.$route.hash), 'scroll', { duration: 1 })
    }
  }
}
</script>