<style lang="less">
.page-list {
  // .section-header {
  //   background-color: #e1e1e1;
  //   height: 0;
  //   padding-bottom: 42.5%;
  //   position: relative;
  //   margin-bottom: 40px;
  //   background-size: cover;
  //   background-position: 50% 0;


  //   .section-header-inner {
  //     position: absolute;
  //     left: 0;
  //     right: 0;
  //     bottom: 60px;
  //     // text-align: right;
  //     // padding-top: 6rem;
  //     // padding-bottom: 3rem;
  //     // display: flex;
  //     // flex-direction: column;
  //     // align-items: flex-end;
  //     // justify-content: space-around;

  //     h3 {
  //       width: 100%;
  //       margin: 0;
  //       font-weight: bold;
  //       letter-spacing: .02em;
  //       font-size: 26px;
  //     }

  //     h4 {
  //       font-size: 20px;
  //       margin-top: 16px;
  //       margin-bottom: 24px;
  //     }

  //     p {
  //       font-size: .875rem;
  //       line-height: 1.6em;
  //     }

  //     hr {
  //       border-color: black;
  //       border-width: 2px;
  //       margin-bottom: 24px;
  //     }
  //   }
  // }

  .section-item {
    header {
      height: 0;
      padding-bottom: 66.67%;
      background-color: #e1e1e1;
      position: relative;

      .section-item-header-label {
        position: absolute;
        right: 15px;
        bottom: 10px;
        padding: 0px 10px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
      }
    }

    a {
      display: block;
      text-decoration: none;
      letter-spacing: .05em;

      h3 {
        color: black;
      }

      h4 {
        color: #959595;
        margin-top: 12px;
        margin-bottom: 28px;
        line-height: 20px;
        height: 20px;
      }

      p {
        color: #959595;
        font-size: .75rem;
        line-height: 18px;
        height: 72px;
      }

      &:hover {
        span {
          background-color: black;
          color: white;
        }
      }
    }

    hr {
      margin-top: 50px;
      margin-bottom: 60px;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    margin-top: 30px;
  }
}
</style>

<template>
  <div class="page-list row">
    <div class="col-md-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="$route.params.lang === 'en' ? 'Baita Event' : '白塔事件'" :sub="sections" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <section-header :section="currentSection"></section-header>

      <div class="row article-list">
        <template v-for="article in displayList">
          <article-item class="col-xs-12 col-sm-6 col-md-4"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="getLink(article)"
                        :img="article.cover"></article-item>
        </template>
      </div>

      <footer>
        <pager v-model="currentPage" :max="pageCount" v-if="pageCount > 1"></pager>
      </footer>
    </div>
  </div>
</template>

<script>
import SectionHeader from '~/components/SectionHeader.vue'
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import Pager from '~/components/Pager.vue'
import { mapGetters } from 'vuex'
// import querystring from 'querystring'
import { findCurrentSection } from '~/assets/js/utils'

// const section = 'beijing-design-week'

export default {
  layout: 'default',
  components: {
    SectionHeader, FixedContainer, NavAside, ArticleItem, Pager
  },
  async asyncData ({ route, store, app, redirect }) {
    const currentSection = findCurrentSection(store.state.nav, route.fullPath).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id, lang: route.params.lang })

    return {
      articleList,
      currentPage: Number(route.query.page) || 1
    }
  },
  data () {
    return {
      articlePerPage: 24
      // currentPage: 1,
    }
  },
  watch: {
    currentPage (v) {
      window.scroll(0, 0)
    }
  },
  computed: {
    ...mapGetters(['event']),
    sections () {
      return this.$store.state.nav.filter(n => n.id === 9).pop().children_nav
    },
    currentSection () {
      return findCurrentSection(this.$store.state.nav, this.$route.fullPath).nav
    },
    displayList () {
      const startIdx = (this.currentPage - 1) * this.articlePerPage
      const endIdx = Math.min(this.currentPage * this.articlePerPage, this.articleList.length)

      return this.articleList.slice(startIdx, endIdx)
    },
    pageCount () {
      return Math.ceil(this.articleList.length / this.articlePerPage)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.fullPath}/${article.id}`
    },
    getExtendInfo (id) {
      return this.$store.state.tempNavInfo[id]
    }
  }
}
</script>