<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-article row">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="$route.params.lang === 'en' ? 'Baita Event' : '白塔事件'" :sub="sections" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-7">
      <article>
        <h2>{{article.title}}</h2>
        <!-- <h3 class="time">{{time}}</h3> -->

        <section class="article-container" v-html="articleContent">
        </section>
      </article>
    </div>

    <div class="col-xs-12 col-md-3">
      <div class="row article-list">
        <template v-for="article in articleList">
          <article-item class="col-xs-12 col-sm-6 col-md-12 in-aside"
                        in-parent="aside"
                        :category="2"
                        :title="article.title"
                        :time="getTime(article.add_time)"
                        :link="getLink(article)"
                        :img="article.cover"></article-item>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
// import querystring from 'querystring'
// import { json2htm .l } from 'html2json'
import { findCurrentSection, readContent } from '~/assets/js/utils'
// const section = 'beijing-design-week'

export default {
  layout: 'default',
  components: {
    FixedContainer, NavAside, ArticleItem
  },
  async asyncData ({ route, store, app }) {
    const id = route.params.article
    let sections = store.state.nav.filter(n => n.id === 9).pop().children_nav
    let currentSection = findCurrentSection(sections, `${route.fullPath.split('/').slice(0, route.fullPath.split('/').length - 1).join('/')}`).nav

    // let res = await app.$axios.$post('article_list', querystring.stringify({
    //   login_uid: 'glabcms',
    //   id: currentSection.id
    // }))

    // let article = await app.$axios.$post('articleinfo', querystring.stringify({
    //   login_uid: 'glabcms',
    //   article_id: id,
    //   status: '0'
    // }))

    const articleList = await store.dispatch('fetchArticleListOfCategory', {
      id: currentSection.id
    })

    const article = await store.dispatch('fetchArticleContent', { id })

    // console.log(readContent(article.data.content))

    return {
      sections,
      currentSection,
      articleList: articleList.slice(0, 6),
      article: article,
      articleContent: readContent(article.content)
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path.split('/').slice(0, -1).join('/')}/${article.id}`
    }
  }
}
</script>