<template></template>
<script>
export default {
  asyncData ({redirect}) {
    redirect('/baita-event#beijing-design-week')
  }
}
</script>