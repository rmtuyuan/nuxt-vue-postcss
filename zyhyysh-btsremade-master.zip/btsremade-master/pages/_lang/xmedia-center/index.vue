<style lang="less">
.page-media-center-index {
  
}
</style>

<template>
  <div class="row page-media-center-index">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <fixed-container :offset="100">
        <nav-aside :category="currentCategory[`name_${$route.params.lang}`]" :sub="subNav" :lang="$route.params.lang"></nav-aside>
      </fixed-container>
    </div>

    <div class="col-xs-12 col-md-10">
      <!-- <section-header :section="currentSection"></section-header> -->

      <div class="row article-list">
        <div class="col-xs-12 col-sm-6 col-md-4" v-for="article in articleList">
          <nuxt-link :to="`/${$route.params.lang}${currentCategory.link}/media-report/${article.id}`">
            <media-article-item :cover="article.cover"
                                :title="article.title"
                                :media="article.keywords"
                                :date="article.description"></media-article-item>
          </nuxt-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FixedContainer from '~/components/FixedContainer.vue'
import SectionHeader from '~/components/SectionHeader.vue'
import NavAside from '~/components/NavAside.vue'
import MediaArticleItem from '~/components/MediaArticleItem.vue'
import { findCurrentCategory, findCurrentSection } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    FixedContainer, SectionHeader, NavAside, MediaArticleItem
  },
  async asyncData ({ store, route, app, redirect }) {
    const currentCategory = findCurrentCategory(store.state.nav, route.fullPath)
    const subNav = currentCategory.children_nav
    const currentSection = findCurrentSection(subNav, route.fullPath).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentCategory.id, lang: route.params.lang })
    // const articleList = [
    //   {
    //     addTime: 12918723981,
    //     cover: 'http://static.glabcms.stoyard.com/glabcms_tm/20170915/jmOPrXTYt6UEtEu9.jpeg',
    //     description: '2012/09/01',
    //     keywords: 'The Beijinger',
    //     title: 'Beijing Design Week 2015: Creative Director Beatrice Leanza Gives us the…'
    //   },
    //   {
    //     addTime: 12918723981,
    //     cover: 'http://static.glabcms.stoyard.com/glabcms_tm/20170915/jmOPrXTYt6UEtEu9.jpeg',
    //     description: '2012/09/01',
    //     keywords: '新浪地产',
    //     title: '北京国际设计周 微展开展及开题沙龙活动取得圆满成功 '
    //   },
    //   {
    //     addTime: 12918723981,
    //     cover: 'http://static.glabcms.stoyard.com/glabcms_tm/20170915/jmOPrXTYt6UEtEu9.jpeg',
    //     description: '2012/09/01',
    //     keywords: 'The Beijinger',
    //     title: 'Beijing Design Week 2015: Creative Director Beatrice Leanza Gives us the…'
    //   },
    //   {
    //     addTime: 12918723981,
    //     cover: 'http://static.glabcms.stoyard.com/glabcms_tm/20170915/jmOPrXTYt6UEtEu9.jpeg',
    //     description: '2012/09/01',
    //     keywords: 'The Beijinger',
    //     title: 'Beijing Design Week 2015: Creative Director Beatrice Leanza Gives us the…'
    //   },
    //   {
    //     addTime: 12918723981,
    //     cover: 'http://static.glabcms.stoyard.com/glabcms_tm/20170915/jmOPrXTYt6UEtEu9.jpeg',
    //     description: '2012/09/01',
    //     keywords: 'The Beijinger',
    //     title: 'Beijing Design Week 2015: Creative Director Beatrice Leanza Gives us the…'
    //   }
    // ]

    // if (articleList.length === 1) {
    //   redirect(`${route.fullPath}/${articleList[0].id}`)
    // }

    return {
      currentCategory,
      subNav,
      currentSection,
      articleList
    }
  // },
  // computed: {
  //   subNav () {
  //     return this.currentCategory.children_nav || []
  //   }
  }
}
</script>