<template></template>
<script type="text/javascript">
  export default {
    asyncData ({ route, redirect }) {
      if (route.fullPath.match(/\/(en|zh)\/home/)) {
        redirect(`/${route.params.lang}`)
      }
    }
  }
</script>
