<style lang="less" scoped>
article {
  section {
    font-size: .875rem;

    img {
      // margin-bottom: 2rem;
    }

    h3 {
      text-align: center;
      // margin-top: 4rem;
      // margin-bottom: 2rem;

      span {
        display: inline-block;
        background: black;
        color: white;
        padding: .25em 2em;
      }
    }

    h4 {
      text-decoration: underline;
      margin-top: 2rem;
      margin-bottom: 1rem;
    }

    ul, ol {
      padding-left: 1rem;
    }

    p.weak, .weak p {
      opacity: .6;
      font-size: .75rem;
    }

    h4.weak {
      opacity: .6;
      margin: 0;
      text-decoration: none;
    }
  }
}
</style>

<template>
  <div class="page-about container">
    <article class="row">
      <section class="col-xs-12">
        <img class="img-responsive" src="/aboutbts.png">
      </section>

      <section class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
        <h3>关于白塔寺</h3>
        <p>妙应寺，俗称白塔寺，位于北京市西城区阜成门内大街上。它始建于元代，原名「大圣寿万安寺」，寺内的白塔是中国现存年代最早、规模最大的喇嘛塔。1961年，妙应寺白塔被中华人民共和国国务院公布为第一批全国重点文物保护单位之一。</p>
      </section>

      <section class="col-xs-12">
        <img class="img-responsive" src="/btsremade.jpg">
      </section>

      <section class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
        <h3>白塔寺再生计划</h3>
        <p>随着现代化城市建设步伐的加快,北京旧城合院空间逐渐破碎化，白塔寺历史文化保护区传统的胡同文化失去了载体，原住民开始迁离,街区传统文化严重流失,井然有序和舒适恬静不在,取而代之的是日渐混乱和衰落,随着社会的进步，原来大拆大建的方式在城市核心区已经不在适用，而微循环、有机更新的模式得到了更多重视和运用。</p>
        <p>按照北京首都功能定位，制定出人口持续疏解、物质空间更新、基础能源提升、公共环境再造、培育文化触媒和区域整体复兴的实施路径，在保持独具一格的胡同肌理和老北京传统的四合院居住片区原有居住功能属性不变的情况下，通过植入设计，文创和展览展示等新的元素，全面营造传统、创意、时尚相融合的新文化街区。</p>
        <p><strong>人口持续疏解：</strong>2013年起，在西城区政府主导下，在地企业与街区百姓以双方自愿签订协议的方式腾退院落，并定向安置房屋，给予货币补偿，实现人口疏解。坚持“以人为本、坚持民意”的原则，进行人口疏解，降低旧城居住密度。</p>
        <p><strong>物质空间更新：</strong>街区院落空间已从传统的合院演变为大杂院，建筑老旧亟待维护。首先由企业主导对已腾退的院落通过翻建、改建、修缮等方式，改善建筑和居住空间的质量，为新功能的植入铺垫空间基础。同时带动街区未腾退居民共同参与改造。</p>
        <p><strong>基础能源提升：</strong>由于历史原因，白塔寺地区断头路、窄胡同较多，不利于城市基础设施的铺设。通过公共部门协同，以及市政设施新技术新能源的运用，在保护传统胡同肌理的前提下，提升街区基础设施水平，改善居民上下水以及供电供热等条件，提供生活便利。</p>
        <p><strong>公共环境再造：</strong>胡同的公共空间是街坊邻里交流活动的场所。通过政府自上而下的项目统筹规划，进行环境整治；同时鼓励居民参与，制定居民公约，健全自下而上的自治监督管理机制，将精细化的城市管理与社区居民自治相结合，保障街区公共环境提升。</p>
        <p><strong>培育文化触媒：</strong>在街区整体发展定位的指导下，策略性地引进新元素，吸引有文化认同的活力人群，引入能够激活街区再生的功能业态，利用互联网技术、传媒资源等技术手段，影响和带动其它元素发生改变。</p>
        <p><strong>区域整体复兴：</strong>通过物质空间改善，实现街区居住环境提升，通过文化触媒的培育，引发触媒效应，实现街区功能更新，使其能够成为具有一定文化价值且能够广泛容纳现代与未来城市功能的传承载体和生活空间。</p>
      </section>
    </article>
  </div>
</template>

<script>
import querystring from 'querystring'
import { json2html } from 'html2json'

const section = 'baitasi-courtyard-renewal-international-design-competition'

export default {
  layout: 'default',
  async asyncData ({ store, app }) {
    const sections = store.getters.btevent.sub

    let currentSection = sections.filter(s => s.name === 'baitasi-international-design-competition').pop().sub.filter(s => s.name === section).pop().sub.filter(s => s.name === 'tasks').pop()

    const id = currentSection.article

    let res = await app.$axios.$post('articleinfo', querystring.stringify({
      login_uid: 'glabcms',
      article_id: id,
      status: '0'
    }))

    if (String(res.code) === '100200') {
      console.log(res)
      res.data['id'] = id
      res.data['section'] = section
      store.commit('updateArticle', res.data)
    }

    return {
      currentSection,
      // newarticle,
      article: store.state.articles[id]
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    articles () {
      return this.currentSection.articles.map(id => {
        return this.$store.state.articles[id]
      }).filter(article => {
        if (article) {
          return article
        }
      }).slice(0, 4)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path}/${article.id}`
    },
    readPageData (n) {
      function delHtmlTag (str) {
        return str.replace(/(<p[^>]*>)|(<\/p>)/gi, '') // 去掉所有的html标记
      }
      var Node = document.querySelector('.article-container')
      let read = function () {
        n.child.forEach(function (val) {
          if (val.child) {
            val.child.forEach(function (value) {
              if (value.tag === 'img') {
                let Img = document.createElement('img')
                Img.src = value.attr.src
                Node.appendChild(Img)
              } else if (value.tag === 'p') {
                if (value.child[0].text === '请输入文本') { } else {
                  var P = document.createElement('p')
                  // let html = transfer.json2html(value)
                  let html = json2html(value)
                  // console.log(delHtmlTag(html))
                  P.innerHTML = delHtmlTag(html)
                  Node.appendChild(P)
                }
              }
            })
          }
        })
      }
      read()
    }
  },
  mounted () {
    // console.log(json2html(this.article.content))
    // this.readPageData(window.JSON.parse(this.article.content))
  }
}
</script>
