<style lang="less" scoped>
.page-work-detail {
  .work-list {
    margin-top: 2rem;
  }

  header {
    margin-top: 10px;
    display: flex;
    align-items: center;

    h1 {
      span {
        font-size: 1.25rem;
        opacity: .5;
      }
    }

    button {
      width: 100%;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-around;
      background: none;
      border: 1px solid black;
      outline: none;
      height: 40px;
      font-weight: bold;

      &:hover {
        background-color: black;
        span {
          color: white;
        }
        svg #gfill {
          fill: white;
        }
      }
    }
  }

  hr {
    margin-top: 0;
  }

  a.pdf-link {
    display: block;
    position: relative;

    img {
      width: 100%;
      height: auto;
    }

    .a-hover {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background-color: rgba(0, 0, 0, 0.5);
      color: white;
      opacity: 0;
      transition: opacity .2s;
    }

    &:hover {
      .a-hover {
        opacity: 1;
      }
    }
  }
}
</style>

<template>
  <div class="page-work-detail container">
    <div class="row">
      <div class="col-xs-2">
        <nav-aside :category="2" title="白塔事件" :sections="sections" :active="2"></nav-aside>
      </div>

      <div class="col-xs-10">
        <<!-- slider-show :ratio="1/2" autoplay :duration="1000">
          <slider-item>
            <img class="slider-item-bg" src="img02.jpg">
          </slider-item>
          <slider-item>
            <img class="slider-item-bg" src="img03.jpg">
          </slider-item>
        </slider-show> -->

        <header class="row">
          <div class="col-xs-9">
            <h1>
              奁（lian）院
              <span>A-1-847</span>
            </h1>
            <p>参与人员：周兆前、刘奕秋、唐尧峰、沈旸</p>
          </div>

          <div class="col-xs-3">
            <button>
              <span>查看完整设计文档</span>
              <svg width="5px" height="11px" viewBox="0 0 5 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g id="gfill" transform="translate(-3.000000, -37.000000)" fill="#000000">
                    <polygon id="Mask-Copy-4" points="3 37 5.24736014 37 8 42.5 5.24736014 48 3 48 5.75263986 42.5"></polygon>
                  </g>
                </g>
              </svg>
            </button>
          </div>
        </header>

        <hr>

        <div class="row">
          <article class="col-xs-6">
            <h3>设计理念</h3>
            <section>
              <p>“奁”“liǎn”，是古代汉族女子存放梳妆用品的镜箱。形小而用足。本方案以“奁院”为概念，在院宅中置入屉式空间，如此便可灵活增减室内空间，且便于整体组织“院”与“宅”，在局促用地中，也能满足不同的使用需求。</p>
              <p>“Lian“ is a kind of drawer  with mirror which was used by ancient Chinese woman, it is small but quite useful. The concept of this project is “Lian courtyard”, by inserting space like draw in the building, the user could increase and decrease the interior space flexibly ,  even in a narrow space like the  courtyard, this project could achieve the goal of  diversified used</p>
            </section>
          </article>
          <div class="col-xs-6">
            <a class="pdf-link" href="#">
              <img src="img01.jpg">
              <div class="a-hover">
                <svg width="34px" height="23px" viewBox="0 0 34 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="作品详情-带视频" transform="translate(-1048.000000, -892.000000)" stroke="#FFFFFF" stroke-width="2">
                      <path d="M1050,903.441435 C1052.25511,897.345455 1058.12009,893 1065,893 C1071.87991,893 1077.74489,897.345455 1080,903.441435 C1077.74489,909.537415 1071.87991,913.88287 1065,913.88287 C1058.12009,913.88287 1052.25511,909.537415 1050,903.441435 Z M1064.5,909 C1067.53757,909 1070,906.537566 1070,903.5 C1070,900.462434 1067.53757,898 1064.5,898 C1061.46243,898 1059,900.462434 1059,903.5 C1059,906.537566 1061.46243,909 1064.5,909 Z" id="Combined-Shape"></path>
                    </g>
                  </g>
                </svg>
                <h3>查看设计文档</h3>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
// import SliderShow from '~/components/SliderShow.vue'
// import SliderItem from '~/components/SliderItem.vue'

export default {
  layout: 'default',
  components: {
    NavAside
  },
  asyncData () {
    return {
      sections: [
        {
          title: '北京国际设计周',
          title_en: 'BEIJINGDESIGNWEEK',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            },
            {
              title: '2015年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔寺国际方案征集',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '设计市集',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '院落更新国际方案征集',
              sub_title: '北京小院儿的重生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔新事',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '威尼斯双年展',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '上海设计之变',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        }
      ],
      works: [
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847'
        }
      ]
    }
  }
}
</script>
