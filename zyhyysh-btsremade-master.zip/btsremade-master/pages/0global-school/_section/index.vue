<style lang="less">
.page-list {
  .section-header {
    background-color: #e1e1e1;
    // height: 0;
    // padding-bottom: 42.5%;
    min-height: 400px;
    position: relative;
    margin-bottom: 40px;

    .section-header-inner {
      position: relative;
      left: 0;
      right: 0;
      padding-top: 120px;
      padding-bottom: 60px;
      // text-align: right;

      h3 {
        // margin: 0;
        font-weight: bold;
        // letter-spacing: .02em;
        font-size: 1.5rem;
        margin-bottom: 1em;
      }

      h4 {
        font-size: 20px;
        margin-top: 16px;
        margin-bottom: 24px;
      }

      p {
        font-size: .875rem;
        line-height: 1.6em;
      }

      hr {
        border-color: black;
        border-width: 2px;
        margin-bottom: 24px;
      }
    }
  }

  .section-item {
    header {
      height: 0;
      padding-bottom: 66.67%;
      background-color: #e1e1e1;
      position: relative;

      .section-item-header-label {
        position: absolute;
        right: 15px;
        bottom: 10px;
        padding: 0px 10px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
      }
    }

    a {
      display: block;
      text-decoration: none;
      letter-spacing: .05em;

      h3 {
        color: black;
      }

      h4 {
        color: #959595;
        margin-top: 12px;
        margin-bottom: 28px;
        line-height: 20px;
        height: 20px;
      }

      p {
        color: #959595;
        font-size: .75rem;
        line-height: 18px;
        height: 72px;
      }

      &:hover {
        span {
          background-color: black;
          color: white;
        }
      }
    }

    hr {
      margin-top: 50px;
      margin-bottom: 60px;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    margin-top: 30px;
  }
}
</style>

<template>
  <div class="page-list container">
    <div class="row">
      <div class="col-xs-12">
        <header class="section-header">
          <div class="section-header-inner">
            <div class="row">
              <div class="col-xs-4 col-xs-offset-7">
                <hr>
                <h3>
                  <span class="impact">{{currentSection.name_en}}</span><br>
                  <span>{{currentSection.name_zh}}</span>
                </h3>
                <p v-for="t in getExtendInfo(currentSection.id).descp_zh">{{t}}</p>
              </div>
            </div>
          </div>
        </header>

        <div class="row article-list">
          <template v-for="article in articleList">
            <article-item class="col-xs-12 col-sm-6 col-md-4"
                          :title="article.title"
                          :time="getTime(article.add_time)"
                          :link="getLink(article)"
                          :img="article.cover"></article-item>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { mapGetters } from 'vuex'
import { findCurrentSection } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  async asyncData ({store, route, app, redirect}) {
    const currentSection = findCurrentSection(store.state.nav, route.fullPath).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id })

    if (articleList.length === 1) {
      redirect(`${route.fullPath}/${articleList[0].id}`)
    }

    return {
      currentSection,
      articleList
    }
  },

  computed: {
    ...mapGetters(['neighborhood'])
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.fullPath}/${article.id}`
    },
    getExtendInfo (id) {
      return this.$store.state.tempNavInfo[id]
    }
  }
}
</script>