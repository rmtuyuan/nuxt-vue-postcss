<style lang="less">
.page-category {
  .category-section {
    .section-header {
      background-color: #2B2B2B;
      height: 0;
      padding-bottom: 37%;
      position: relative;
      margin-bottom: 40px;

      .section-header-inner {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        text-align: right;

        h3 {
          margin: 0;
          font-weight: bold;
          color: white;
        }

        hr {
          border-color: white;
          border-width: 2px;
          margin-bottom: 40px;
        }
      }
    }
  }

  .section-item {
    header {
      height: 0;
      padding-bottom: 66.67%;
      background-color: #e1e1e1;
      position: relative;

      .section-item-header-label {
        position: absolute;
        right: 15px;
        bottom: 10px;
        padding: 0px 10px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
      }
    }

    a {
      display: block;
      text-decoration: none;
      letter-spacing: .05em;

      h3 {
        color: black;
      }

      h4 {
        color: #959595;
        margin-top: 12px;
        margin-bottom: 28px;
        line-height: 20px;
        height: 20px;
      }

      p {
        color: #959595;
        font-size: .75rem;
        line-height: 18px;
        height: 72px;
      }

      &:hover {
        span {
          background-color: black;
          color: white;
        }
      }
    }

    hr {
      margin-top: 50px;
      margin-bottom: 60px;
    }
  }
}
</style>

<template>
  <div class="page-category container">
    <div class="row">
      <div class="col-xs-2">
        <nav-aside :category="2" title="白塔事件" :sections="sections"></nav-aside>
      </div>

      <div class="col-xs-10">
        <template v-for="section in sections">
          <section class="row category-section">
            <div class="col-xs-12">
              <header class="section-header">
                <div class="section-header-inner">
                  <div class="row">
                    <div class="col-xs-10 col-xs-offset-1">
                      <h3 class="impact">{{section.title_en}}</h3>
                      <h3>{{section.title}}</h3>
                      <hr>
                    </div>
                  </div>
                </div>
              </header>
            </div>

            <template v-for="item in section.sub">
              <div class="col-xs-4">
                <div class="section-item">
                  <a :href="item.link">
                    <header>
                      <div class="section-item-header-label">{{item.sub_count}}</div>
                    </header>
                    <h3>
                      <span>{{item.title}}</span>
                    </h3>
                    <h4>{{item.sub_title}}</h4>
                    <p>{{item.descp}}</p>
                  </a>
                  <hr>
                </div>
              </div>
            </template>
          </section>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
export default {
  layout: 'default',
  components: {
    NavAside
  },
  asyncData () {
    return {
      sections: [
        {
          title: '北京国际设计周',
          title_en: 'BEIJINGDESIGNWEEK',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: '',
              link: '/list'
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: '',
              link: '/list'
            }
          ]
        },
        {
          title: '白塔新事',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: '',
              link: '/list'
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: '',
              link: '/list'
            }
          ]
        }
      ]
    }
  }
}
</script>