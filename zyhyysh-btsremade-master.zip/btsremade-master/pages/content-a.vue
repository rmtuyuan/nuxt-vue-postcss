<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-article container">
    <div class="row">
      <div class="col-xs-2">
        <nav-aside :category="2" title="白塔事件" :sections="sections" :active="1"></nav-aside>
      </div>

      <div class="col-xs-7">
        <article>
          <h2>北京国际设计周</h2>
          <h3 class="time">2017.01.01</h3>

          <section>
            <img src="img01.jpg">
            <p>2015年北京国际设计周——“白塔寺再生计划”以“连接与共生”为主题，通过40余项设计展览展示活动、论坛，以及强化的可视化项目和线上线下一体化平台，将成为领略和重新发现该区域丰富文化、独一无二城市结构和历史的出发点。</p>
            <p>2015年北京国际设计周——“白塔寺再生计划”开幕式于鲁迅博物馆序厅隆重举行。西城区副区长陈宁、北京工业设计促进中心/组委会办公室主任陈冬亮、北京金融街投资（集团）有限公司副总经理杨杨，以及西城区部分委办局领导、知名设计师、媒体单位共计百余人出席了开幕仪式。</p>
            <p>作为北京国际设计周中白塔寺核心区三个建筑项目之一，四分院改造项目向不再契合当下青年人生活模式的中国传统家庭生活发起挑战，通过将老式四合院分成四组空间，每组包含一个房间和一个私人小院，最终共同构成一个风车状布局，以来体现绝佳私密性。如此设计的分离性公寓旨在凭藉从「合」至「分」的变化揭示出社会结构和生活模式在住宅中的转变，并借助创维理念创造现代化智能生活。</p>
            <p>白塔寺 22 号杂院建筑改造项目通过对「生活方式新旧延续」以及「建造方式新旧并置」的探索，缔造都市背景下「Hybrid Living」的生活模式。作为具有时代意义的院落，其所承载的历史痕迹与价值应该在旧城更新中得到适度尊重，但它杂乱不堪的生活状态仍需要被梳理和改善。除了居住功能外，所具备的公共活动空间功能性拥有巨大开发潜力。北京国际设计周期间，院落空间被划分为居住、办公、咖啡厅三种功能，且拥有各自户外院落空间，为使用者提供更好的生活质量。此外，极简的设计风格与古朴、极富历史韵味的周边环境相得益彰，可谓传承历史、与时俱进的设计佳作.</p>
            <p>2015年北京国际设计周——“白塔寺再生计划”以“连接与共生”为主题，通过40余项设计展览展示活动、论坛，以及强化的可视化项目和线上线下一体化平台，将成为领略和重新发现该区域丰富文化、独一无二城市结构和历史的出发点。</p>
            <p>2015年北京国际设计周——“白塔寺再生计划”开幕式于鲁迅博物馆序厅隆重举行。西城区副区长陈宁、北京工业设计促进中心/组委会办公室主任陈冬亮、北京金融街投资（集团）有限公司副总经理杨杨，以及西城区部分委办局领导、知名设计师、媒体单位共计百余人出席了开幕仪式。</p>
            <p>作为北京国际设计周中白塔寺核心区三个建筑项目之一，四分院改造项目向不再契合当下青年人生活模式的中国传统家庭生活发起挑战，通过将老式四合院分成四组空间，每组包含一个房间和一个私人小院，最终共同构成一个风车状布局，以来体现绝佳私密性。如此设计的分离性公寓旨在凭藉从「合」至「分」的变化揭示出社会结构和生活模式在住宅中的转变，并借助创维理念创造现代化智能生活。</p>
            <p>白塔寺 22 号杂院建筑改造项目通过对「生活方式新旧延续」以及「建造方式新旧并置」的探索，缔造都市背景下「Hybrid Living」的生活模式。作为具有时代意义的院落，其所承载的历史痕迹与价值应该在旧城更新中得到适度尊重，但它杂乱不堪的生活状态仍需要被梳理和改善。除了居住功能外，所具备的公共活动空间功能性拥有巨大开发潜力。北京国际设计周期间，院落空间被划分为居住、办公、咖啡厅三种功能，且拥有各自户外院落空间，为使用者提供更好的生活质量。此外，极简的设计风格与古朴、极富历史韵味的周边环境相得益彰，可谓传承历史、与时俱进的设计佳作.</p>
          </section>
        </article>
      </div>

      <div class="col-xs-3">
        <div class="row article-list">
          <template v-for="article in articles">
            <article-item class="col-xs-12 in-aside"
                          in-parent="aside"
                          :title="article.title"
                          :time="article.time"
                          :link="article.link"
                          :img="article.img"></article-item>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  asyncData () {
    return {
      sections: [
        {
          title: '北京国际设计周',
          title_en: 'BEIJINGDESIGNWEEK',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            },
            {
              title: '2015年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔寺国际方案征集',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '设计市集',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '院落更新国际方案征集',
              sub_title: '北京小院儿的重生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔新事',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '威尼斯双年展',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '上海设计之变',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        }
      ],
      articles: [
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img01.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img02.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img03.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img04.jpg'
        }
      ]
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    }
  }
}
</script>