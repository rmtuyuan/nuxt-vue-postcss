<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-article container">
    <div class="row">

      <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
        <article>
          <h2>{{article.title}}</h2>
          <h3 class="time">{{time}}</h3>

          <section class="article-container">
          </section>
        </article>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import querystring from 'querystring'
import { json2html } from 'html2json'

const section = 'baita-reception'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  async asyncData ({ store, route, app }) {
    let currentSection = store.getters.neighborhood.sub.filter(s => s.name === section).pop()

    const id = currentSection.article

    let res = await app.$axios.$post('articleinfo', querystring.stringify({
      login_uid: 'glabcms',
      article_id: id,
      status: '0'
    }))

    if (String(res.code) === '100200') {
      res.data['id'] = id
      res.data['section'] = section
      store.commit('updateArticle', res.data)
    }

    return {
      currentSection,
      // newarticle,
      article: store.state.articles[id]
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    articles () {
      return this.currentSection.articles.map(id => {
        return this.$store.state.articles[id]
      }).filter(article => {
        if (article) {
          return article
        }
      }).slice(0, 4)
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path}/${article.id}`
    },
    readPageData (n) {
      function delHtmlTag (str) {
        return str.replace(/(<p[^>]*>)|(<\/p>)/gi, '') // 去掉所有的html标记
      }
      var Node = document.querySelector('.article-container')
      let read = function () {
        n.child.forEach(function (val) {
          if (val.child) {
            val.child.forEach(function (value) {
              if (value.tag === 'img') {
                let Img = document.createElement('img')
                Img.src = value.attr.src
                Node.appendChild(Img)
              } else if (value.tag === 'p') {
                if (value.child[0].text === '请输入文本') { } else {
                  var P = document.createElement('p')
                  // let html = transfer.json2html(value)
                  let html = json2html(value)
                  // console.log(delHtmlTag(html))
                  P.innerHTML = delHtmlTag(html)
                  Node.appendChild(P)
                }
              }
            })
          }
        })
      }
      read()
    }
  },
  mounted () {
    // console.log(json2html(this.article.content))
    this.readPageData(window.JSON.parse(this.article.content))
  }
}
</script>