<style lang="less" scoped>
.page-article {
  article {
    h3.time {
      opacity: .2;
      font-weight: 400;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-article container">
    <div class="row">
      <div :class="contentClass">
        <article>
          <h2>{{article.title}}</h2>
          <h3 class="time">{{time}}</h3>

          <section v-html="articleContent">
          </section>
        </article>
      </div>

      <div class="col-xs-12 col-md-6" v-if="hasList">
        <div class="row article-list">
          <template v-for="article in articleList">
            <article-item class="col-xs-6 in-aside"
                          in-parent="aside"
                          :title="article.title"
                          :time="getTime(article.add_time)"
                          :link="getLink(article)"
                          :img="article.cover"></article-item>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import { findCurrentSection, readContent } from '~/assets/js/utils'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  async asyncData ({ store, route, app }) {
    const id = route.params.article
    const currentSection = findCurrentSection(store.state.nav, route.fullPath, -1).nav
    const articleList = await store.dispatch('fetchArticleListOfCategory', { id: currentSection.id })
    const article = await store.dispatch('fetchArticleContent', { id })

    const json = JSON || window.JSON

    return {
      currentSection,
      articleList: articleList.slice(0, 6),
      hasList: articleList.length > 1,
      article,
      articleObj: json.parse(article.content),
      articleContent: readContent(article.content)
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    },
    time () {
      return (new Date(this.article.update_time * 1000)).toLocaleDateString()
    },
    contentClass () {
      if (this.hasList) {
        return 'col-xs-12 col-md-6'
      } else {
        return 'col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2'
      }
    }
  },
  methods: {
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `${this.$route.path.split('/').slice(0, -1).join('/')}/${article.id}`
    }
  }
}
</script>