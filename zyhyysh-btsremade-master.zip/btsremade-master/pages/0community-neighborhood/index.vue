<style lang="less">
.baita_event {}
</style>

<template>
  <div class="container page-category baita_event">
    <template v-for="section in sections">
      <header class="row list-header">
        <div class="col-xs-11">
          <h3>
            <span class="impact">{{section.title_en}}</span><br>
            <span>{{section.title_zh}}</span>
          </h3>
        </div>
        <div class="col-xs-1">
          <nuxt-link :to="section.link" class="more">
            <svg width="17px" height="44px" viewBox="0 0 17 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
                <desc>Created with Sketch.</desc>
                <defs>
                    <path d="M1.62792073,0.609197438 L6.1193937,0.609197438 L16.6393712,21.2075965 L5.28293382,43.4438064 L0.791460852,43.4438064 L12.1478982,21.2075965 L1.62792073,0.609197438 Z" id="path-1"></path>
                </defs>
                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="白塔寺首页" transform="translate(-1284.000000, -869.000000)">
                        <g id="Group-9" transform="translate(140.000000, 855.000000)">
                            <g id="Path-11" transform="translate(1144.000000, 14.000000)">
                                <mask id="mask-2" fill="white">
                                    <use xlink:href="#path-1"></use>
                                </mask>
                                <use id="Combined-Shape" fill="#000000" xlink:href="#path-1"></use>
                            </g>
                        </g>
                    </g>
                </g>
            </svg>
          </nuxt-link>
        </div>
      </header>

      <div class="row">
        <div class="article-list">
          <template v-for="(article, index) in section.articles">
            <article-item class="col-xs-4"
                          in-parent="index"
                          :key="article.title+index"
                          :title="article.title"
                          :time="article.time"
                          :link="article.link"
                          :img="article.img"></article-item>
          </template>
        </div>
      </div>
    </template>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
// import querystring from 'querystring'

export default {
  layout: 'default',
  components: {
    NavAside
  },
  async asyncData ({ app, store }) {
    const category = store.getters.mainNav.filter(item => item.name === 'community-neighborhood').pop()

    return {
      sections: category.sub
    }
  }
}
</script>