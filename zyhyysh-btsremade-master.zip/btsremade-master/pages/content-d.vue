<style lang="less" scoped>
@import '../node_modules/bootstrap/less/mixins/grid.less';
@grid-columns: 12px;
.page-article {
  article {
    h1, h2, h3, h4, h5, h6 {
      text-align: center;
      margin-top: 1.5em;
      margin-bottom: 1em;
    }

    & > * {
      .make-xs-column(8, 20px);
      .make-xs-column-offset(2);
    }

    & > img:first-child {
      .make-xs-column(12, 20px);
      .make-xs-column-offset(0);
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }

  .breadcumb {
    margin-bottom: 1.6rem;

    a {
      color: black;
      font-weight: bold;
      text-decoration: none;

      &:hover {
        background-color: black;
        color: white;
      }
    }
  }

  .list-title {
    margin-bottom: 1.6rem;
    font-weight: bold;
  }
}
</style>

<template>
  <div class="page-article container">
    <div class="row">
      <g-article :content="article.content"></g-article>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'
import GArticle from '~/components/GArticle'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem, GArticle
  },
  async asyncData ({ store }) {
    const article = await store.dispatch('fetchArticleContent', {id: '689'})

    return {
      article
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    }
  }
}
</script>