<style lang="less">
.page-index {
  height: 100vh;
  background-size: cover;
  background-position: 70% 30%;
  display: flex;
  flex-direction: column;

  // @media only screen and (min-width: 768px) {
  //   background-position: 70% 50%;
  // }

  @media only screen and (min-width: 960px) {
    background-position: center;
  }

  .main-header .header-right {
    ul {
      display: none;
    }

    .sel-lang {
      border: none;

      span {
        display: none;
      }
    }
  }

  .index-inner {
    flex: 1;
    // position: absolute;
    // top: 0;
    // left: 0;
    // right: 0;
    // bottom: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    // &:before {
    //   position: absolute;
    //   z-index: 0;
    //   top: 45%;
    //   left: 50%;
    //   display: block;
    //   content: '';
    //   width: 360px;
    //   height: 200px;
    //   margin-top: -100px;
    //   margin-left: -180px;
    //   border-radius: 50%;
    //   background: rgba(255, 255, 255, 0.5);
    //   filter: blur(100px);
    // }

    .space-2 {
      @media only screen and (min-width: 960px) {
        flex: 1;
      }
      // height: 143px;
    }

    .space-1 {
      flex: 2;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      height: 100vh;
      justify-content: flex-end;
      // align-content: space-between;

      @media only screen and (min-width: 960px) {
        align-items: center;
        // justify-content: center;
      }
    }

    .logo {
      position: relative;
      z-index: 1;
      margin-top: 2rem;
      margin-left: 2rem;

      @media only screen and (min-width: 960px) {
        margin-top: 1rem;
        margin-left: 0;
        margin-bottom: 3rem;
      }
    }

    .lang {
      position: relative;
      // margin-top: 2rem;
      // margin-bottom: 3rem;
      // margin-bottom: 50px;
      margin: 0;
      // width: 320px;
      // display: flex;
      // flex-direction: row;
      padding: 0;
      width: 100vw;
      // background-color: #e9e9e8;
      background-color: rgba(255, 255, 255, 0.2);
      border-radius: 50%;
      // border: 2px solid black;
      box-shadow: 0 0px 300px rgba(255, 255, 255, 0.55);

      @media only screen and (min-width: 960px) {
        // padding: 30px 0px;
        // padding: 40px 60px;
        padding-top: 40px;
        width: auto;
      }

      h5 {
        margin: 0;
        display: flex;
        flex-direction: row;
        min-width: 200px;

        @media only screen and (min-width: 960px) {
          // padding: 0 20px;
        }
      }

      a {
        flex: 1;
        text-align: center;
        display: block;
        color: #252324;
        background-color: #e9e9e8;
        @media only screen and (min-width: 960px) {
          padding: .5rem 1rem;
          background-color: transparent;
          border: 1px solid #252324;
        }
        // background-color: rgba(255, 255, 255, 0.2);

        span {
          display: block;
        }

        @media only screen and (max-width: 767px) {
          display: block;
          min-height: 3rem;
          line-height: 3rem;
          text-align: center;
        }

        &:hover {
          background-color: #252324;

          span {
            color: white;
          }
        }

        &.disabled {
          // opacity: .5;
          // background-color: rgba(255, 255, 255, 0.2);

          span {
            opacity: .5;
          }

          &:hover {
            cursor: not-allowed;
            background-color: transparent;

            span {
              color: #252324;
            }
          }
        }
      }

      a + a {
        border-left: none;
        @media only screen and (min-width: 768px) {
          // margin-left: 10px;
        }
      }
    }
  }
}
</style>

<template>
  <div class="page-index" :style="'background-image: url(index_bg.jpg)'">
    <!-- <div class="index-inner">
      <logo class="hidden-xs" tint="dark" :scale="1.5"></logo>
      <logo class="hidden-sm hidden-md hidden-lg" tint="dark"></logo>
      <div class="lang">
        <h4>
          <nuxt-link to="/home"><span>中文</span></nuxt-link>
          <a class="disabled"><span>En</span></a>
        </h4>
      </div>
    </div> -->
    <!-- <div class="index-header">
      <img src="~assets/index_bg.jpg">
      <page-header></page-header>

      <div class="container main-container">
        <div class="row">
          <div class="col-xs-12 col-sm-4 lang">
            <h4>
              <nuxt-link to="/home"><span>中文</span></nuxt-link>
              <a class="disabled"><span>En</span></a>
            </h4>
          </div>
        </div>
        <div class="index-info">
          <p>白塔寺历史文化保护区是北京最悠久的文脉传承区域，白塔寺是元建都北京保留的唯一大型城市景观，文化内涵博大精深，浓缩了地域文化和时代特征。然而在北京旧城更新的过程中，传统的院落空间破碎，房屋老旧，基础设施难以铺设，人居环境亟待改善提升。</p>
          <p>为了推进人口疏解、改善民生、风貌恢复、环境提升，“白塔寺再生计划”应运而生。</p>
          <h4>
            <a href="/home">了解白塔寺再生计划 ></a> 
          </h4>
        </div>
      </div>

      <a href="/home">了解白塔寺再生计划 ></a>

      <div class="navbar-outer">
        <navbar></navbar>
      </div>
    </div> -->

    <page-header></page-header>

    <div class="index-inner hidden-sm hidden-md hidden-lg">
      <div class="space-1">
        <!-- <logo :scale="0.75" class="hidden-sm hidden-md hidden-lg" /> -->
        <div class="lang">
          <logo class="hidden-xs" />
          <h5>
            <nuxt-link to="/zh"><span>中文</span></nuxt-link>
            <nuxt-link to="/en"><span>EN</span></nuxt-link>
          </h5>
        </div>
      </div>
      <!-- <div class="space-1"></div> -->
    </div>
    
  </div>
</template>

<script>
import Logo from '../components/Logo'
import PageHeader from '~/components/PageHeader'
// import Navbar from '~/components/Navbar'

export default {
  layout: 'index',
  components: {
    PageHeader,
    Logo
  },
  data () {
    return {
      articles: [
        {
          title: '博览群艺居民艺术展国际社区周特别策划',
          time: '2017.08.08',
          link: '/article',
          img: 'img01.jpg'
        },
        {
          title: '白塔寺旁的“新居民们”',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img02.jpg'
        },
        {
          title: '瑞典建筑设计工作室',
          time: '2017.08.08',
          link: '/article',
          img: 'img03.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img04.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article',
          img: 'img05.jpg'
        }
      ],
      events: [
        {
          title: '黑白印象白塔寺',
          category: '邂逅白塔 | 展览',
          year: '2017',
          period: ['08.08', '9.04'],
          link: '/article',
          img: 'img01.jpg'
        },
        {
          title: 'ECAL平面设计展',
          category: '邂逅白塔 | 展览',
          year: '2017',
          period: ['08.08', '9.04'],
          link: 'article-nosidebar',
          img: 'img02.jpg'
        },
        {
          title: '案头——文人书房',
          category: '邂逅白塔 | 展览',
          year: '2017',
          period: ['08.08', '9.04'],
          link: '/article',
          img: 'img03.jpg'
        },
        {
          title: 'ECAL平面设计展',
          category: '邂逅白塔 | 展览',
          year: '2017',
          period: ['08.08', '9.04'],
          link: 'article-nosidebar',
          img: 'img04.jpg'
        },
        {
          title: '案头——文人书房',
          category: '邂逅白塔 | 展览',
          year: '2017',
          period: ['08.08', '9.04'],
          link: '/article',
          img: 'img05.jpg'
        }
      ]
    }
  }
}
</script>

