<style lang="less">
.page-home {
  @media only screen and (max-width: 720px) {
    width: 100vw;
    overflow-x: hidden;
  }

  section {
    width: 100%;
    margin-bottom: 50px;

    header.section-header {
      hr {
        border-width: 2px;
        border-color: black;
      }

      margin-bottom: 30px;
    }

    .article-list {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
    }

    &.events {
      position: relative;
      padding: 50px 0;
      // overflow: hidden;

      &:before {
        display: block;
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        transform: scaleX(2);
        background-color: #F9F9F9;
      }

      .event-list {
        display: flex;

        .btn-out {
          position: relative;
          z-index: 2;
          display: flex;
          justify-content: space-around;

          button {
            flex: 1;
            background: none;
            // margin-top: 150px;
            border: none;
            padding: 0;
            outline: none;
            display: flex;
            align-items: center;
            justify-content: space-around;
            cursor: pointer;

            div {
              display: flex;
              background: black;
              border-radius: 50%;
              width: 2rem;
              height: 2rem;
              align-items: center;
              justify-content: space-around;
            }

            &:hover,
            &:focus {
              opacity: .8;
            }

            &:disabled {
              opacity: .2;
            }
          }
        }
      }

      .event-outer {
        position: relative;
        z-index: 1;
        display: flex;
        flex-direction: row;
        margin-left: -10px;
        margin-right: -10px;
      }

      .event-item {
        // display: inline-block;
        flex: initial;
        width: 20%;
        padding-left: 10px;
        padding-right: 10px;

        a {
          color: black;

          header {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            opacity: .3;

            h2 {
              font-weight: 400;
              font-family: 'DIN Alternate';
              margin-bottom: 0;
            }
          }

          h4 {
            opacity: .2;
            font-family: 'DIN Alternate';
            font-weight: 400;
            margin-top: 0;
            margin-bottom: 1.5rem;
          }

          img {
            margin-bottom: 1.5rem;
          }

          p {
            color: #696969;
          }

          &:hover,
          &:focus {
            text-decoration: none;

            header {
              opacity: .6;
            }

            h4 {
              opacity: .4;
            }

            p {
              color: #252423;
            }

            span {
              color: white;
              background-color: black;
            }
          }
        }
      }
    }

    &.explore-more {
      margin-bottom: 100px;

      .btn-out {
        display: flex;
        align-items: center;
        justify-content: space-around;

        button {
          background: black;
          border-radius: 50%;
          color: white;
          font-weight: bolder;
          border: none;
          padding: 0;
          width: 3rem;
          height: 3rem;
          font-size: 2rem;
          outline: none;
          display: flex;
          align-items: center;
          justify-content: space-around;
          cursor: pointer;
        }
      }
    }
  }
}

.event-item {
  transition: transform 300ms ease-in-out;
}
.list-enter-active {
  transition: none;
}
.list-leave-active {
  transition: none;
}

.article-list-enter-active, .article-list-leave-active {
  transition: all .5s;
}
.article-list-enter, .article-list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}

@keyframes inout {
  0% {
    transform: rotate(0);
  }
  8.333333% {
    transform: rotate(30deg);
  }
  16.66667% {
    transform: rotate(60deg);
  }
  25% {
    transform: rotate(90deg);
  }
  33.333333% {
    transform: rotate(120deg);
  }
  41.66667% {
    transform: rotate(150deg);
  }
  50% {
    transform: rotate(180deg);
  }
  58.333333% {
    transform: rotate(210deg);
  }
  66.666667% {
    transform: rotate(240deg);
  }
  75% {
    transform: rotate(270deg);
  }
  83.333333% {
    transform: rotate(300deg);
  }
  91.666667% {
    transform: rotate(330deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

#loadingIndicator {
    animation: inout 480ms step-start infinite;
}

</style>

<template>
  <div class="page-home row">
    <section class="most-popular">
      <div class="col-xs-12">
        <header class="row section-header">
          <div class="col-xs-11">
            <h3>
              <span class="impact">MOST POPULAR</span><br>
              <span>热点追踪</span>
            </h3>
          </div>
        </header>

        <div class="row article-list">
          <template v-for="(article, index) in hotList">
            <article-item :class="{'col-xs-12 col-sm-6 col-md-4': index >= 2, 'col-xs-12 col-md-6': index < 2}"
                          in-parent="index"
                          :category="article.category"
                          :title="article.title"
                          :time="getTime(article.add_time)"
                          :link="article.link"
                          :img="article.cover"></article-item>
          </template>
        </div>
      </div>
    </section>

    <!-- <section class="events" v-if="events.length">
      <div class="col-xs-12">
        <header class="row section-header">
          <div class="col-xs-11">
            <h3>
              <span class="impact">EVENTS</span><br>
              <span>活动日历</span>
            </h3>
          </div>
          <div class="col-xs-12">
            <hr>
          </div>
        </header>

        <div class="row event-list">
          <div class="col-xs-1 btn-out">
            <button @click="eventShowPrev"
                    :disabled="currentEvent === 0">
              <div>
                <svg width="8px" height="14px" viewBox="0 0 8 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
                    <g id="白塔寺首页" transform="translate(-176.000000, -2463.000000)" stroke="#FFFFFF">
                      <g id="Group-2-Copy" transform="translate(180.500000, 2470.439169) scale(-1, 1) translate(-180.500000, -2470.439169) translate(165.000000, 2454.939169)">
                        <g id="Group" transform="translate(12.000000, 9.000000)">
                          <path d="M0.5,0.5 L7.5,6.5" id="Line"></path>
                          <path d="M7.5,6.5 L0.5,12.5" id="Line"></path>
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </div>
            </button>
          </div>
          <div class="col-xs-10">
            <transition-group name="list"
                              tag="div"
                              class="event-outer"
                              @before-enter="eventItemBeforeEnter"
                              @enter="eventItemEnter"
                              @before-leave="eventItemBeforeLeave"
                              @leave="eventItemLeave">
              <template v-for="event in displayEvents">
                <div class="event-item" :key="event.title">
                  <a href="#">
                    <header>
                      <h2>{{getTime(event.add_time)}}</h2>
                    </header>
                    <h4>{{event.year || 2017}}</h4>
                    <img class="img-responsive" :src="event.cover">
                    <h5>
                      <span>{{event.title}}</span>
                    </h5>
                    <p>{{getCategory(event.category)}}</p>
                  </a>
                </div>
              </template>
            </transition-group>
          </div>
          <div class="col-xs-1 btn-out">
            <button @click="eventShowNext" 
                    :disabled="currentEvent + currentEventCount === events.length">
              <div>
                <svg width="8px" height="14px" viewBox="0 0 8 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="square">
                    <g id="白塔寺首页" transform="translate(-1252.000000, -2463.000000)" stroke="#FFFFFF">
                      <g id="Group-2-Copy-6" transform="translate(1240.000000, 2454.939169)">
                        <g id="Group" transform="translate(12.000000, 9.000000)">
                          <path d="M0.5,0.5 L7.5,6.5" id="Line"></path>
                          <path d="M7.5,6.5 L0.5,12.5" id="Line"></path>
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </div>
            </button>
          </div>
        </div>
      </div>
    </section> -->

    <section class="explore-more">
      <div class="col-xs-12">
        <header class="row section-header">
          <div class="col-xs-11">
            <h3>
              <span class="impact">EXPLORE MORE</span><br>
              <span>发现更多</span>
            </h3>
          </div>
        </header>

        <!-- <div class="row"> -->
        <transition-group name="row"
                          tag="div"
                          class="article-list">
          <template v-for="(article, index) in allList">
            <article-item class="col-xs-12 col-sm-6 col-md-4"
                          in-parent="index"
                          :category="article.category"
                          :key="article.title+index"
                          :title="article.title"
                          :time="getTime(article.add_time)"
                          :link="article.link"
                          :img="article.cover"></article-item>
          </template>
        </transition-group>
        <div class="row">
          <footer class="col-xs-12 btn-out">
            <button @click="loadMore" v-if="couldLoadMore">
              
            <svg v-if="loadingArticles" id="loadingIndicator" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                      <g id="白塔寺首页" transform="translate(-748.000000, -3951.000000)" fill="#FFFFFF">
                          <g id="Group-31" transform="translate(748.000000, 3951.000000)">
                              <circle id="11" cx="7" cy="3.33974596" r="2"></circle>
                              <circle id="10-copy" opacity="0.949999988" cx="3.28545068" cy="6.91551659" r="1.89999998"></circle>
                              <circle id="9-copy" opacity="0.899999976" cx="1.79999995" cy="11.9999511" r="1.79999995"></circle>
                              <circle id="8-copy" opacity="0.849999964" cx="3.08225302" cy="17.1523214" r="1.70000005"></circle>
                              <circle id="7-copy" opacity="0.799999952" cx="6.79562603" cy="20.9956993" r="1.60000002"></circle>
                              <circle id="6-copy" opacity="0.75" cx="12" cy="22.5" r="1.5"></circle>
                              <circle id="5-copy" opacity="0.699999988" cx="17.3024502" cy="21.1824551" r="1.39999998"></circle>
                              <circle id="3-copy" opacity="0.599999964" cx="22.7999756" cy="12.0000489" r="1.20000005"></circle>
                              <circle id="4-copy" opacity="0.649999976" cx="21.2558134" cy="17.3459013" r="1.29999995"></circle>
                              <circle id="2-copy" opacity="0.550000012" cx="21.4426304" cy="6.5526768" r="1.10000002"></circle>
                              <circle id="1-copy" opacity="0.5" cx="17.4960303" cy="2.47613283" r="1"></circle>
                              <circle id="0-copy" opacity="0.449999988" cx="11.9999756" cy="0.899999976" r="1"></circle>
                          </g>
                      </g>
                  </g>
              </svg>
              <svg v-else width="18px" height="19px" viewBox="0 0 18 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g id="白塔寺首页" transform="translate(-690.000000, -3951.000000)" fill="#FFFFFF">
                    <g id="Group-15" transform="translate(690.000000, 3951.939169)">
                      <rect id="Rectangle-4" x="8" y="0" width="2" height="18"></rect>
                      <rect id="Rectangle-4" transform="translate(9.000000, 9.000000) rotate(90.000000) translate(-9.000000, -9.000000) " x="8" y="0" width="2" height="18"></rect>
                    </g>
                  </g>
                </g>
              </svg>
            </button>
          </footer>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import Velocity from 'velocity-animate-server'
import PageHeader from '../components/PageHeader'
import Navbar from '~/components/Navbar'
import ArticleItem from '~/components/ArticleItem'
// import querystring from 'querystring'

export default {
  layout: 'default',
  components: {
    PageHeader, Navbar, ArticleItem
  },
  async asyncData ({app, store}) {
    const initList = await store.dispatch('fetchArticleListByPage', { n: 11 })
    return {
      axios: app.axios,
      hotList: initList.slice(0, 5),
      allList: initList.slice(5)
    }
  },
  data () {
    return {
      hotArticles: [],
      events: [],
      articles: [],
      currentEvent: 0,
      currentEventCount: 5,
      currentEventDirection: 1,
      eventListTransition: false,
      loadingArticles: false,
      loadedIdx: 0,
      couldLoadMore: true
    }
  },
  computed: {
    displayEvents () {
      return this.events.slice(this.currentEvent, this.currentEvent + this.currentEventCount)
    },
    allArticleIds () {
      return this.$store.state.allArticleIds
    },
    lastId () {
      return this.allList[this.allList.length - 1].id
    },
    canLoadArticle () {
      return true
    }
  },
  methods: {
    eventShowPrev () {
      if (!this.eventListTransition) {
        this.eventListTransition = true
        this.currentEventDirection = -1
        this.currentEvent = Math.max(0, this.currentEvent + this.currentEventDirection)
      }
    },
    eventShowNext () {
      if (!this.eventListTransition) {
        this.eventListTransition = true
        this.currentEventDirection = 1
        this.currentEvent = Math.min(this.currentEvent + this.currentEventDirection, this.events.length - this.currentEventCount)
      }
    },
    eventItemBeforeEnter (el) {
      el.style.translateX = `${this.currentEventDirection * 120}%`
    },
    eventItemEnter (el, done) {
      const self = this
      Velocity(el, {
        translateX: ['0%', `${this.currentEventDirection * 120}%`],
        opacity: [1, 0]
      }, {
        duration: 300,
        easing: 'easeInOut',
        complete () {
          self.eventListTransition = false
          done()
        }
      })
    },
    eventItemBeforeLeave (el) {
      el.style.position = 'absolute'
      if (this.currentEventDirection < 0) {
        el.style.left = `${(1 - 1 / this.currentEventCount) * 100}%`
      }
    },
    eventItemLeave (el, done) {
      const self = this
      Velocity(el, {
        translateX: `${this.currentEventDirection * -120}%`,
        opacity: 0
      }, {
        duration: 300,
        easing: 'easeInOut',
        complete () {
          self.eventListTransition = false
          done()
        }
      })
    },
    getTime (ts) {
      return (new Date(ts * 1000)).toLocaleDateString()
    },
    getLink (article) {
      return `/baita-event/beijing-design-week/${article.year}/${article.id}`
    },
    getCategory (id) {
      return [8, 9, 10, 11].indexOf(id) + 1
    },
    loadArticles (count) {
      const list = this.list.slice(this.loadedIdx, this.loadedIdx + count)
      this.loadedIdx += count
      return list
    },
    async loadMore () {
      // this.articles = this.articles.concat(this.loadArticles(6))
      // this.articles.push(this.loadArticles(6))
      const newArticles = await this.loadArticleByPage(this.lastId, 6)

      if (newArticles) {
        this.allList = this.allList.concat(newArticles)
      }

      if (!newArticles || newArticles < 6) {
        this.couldLoadMore = false
      }
    },
    async loadArticleByPage (id, n) {
      const list = await this.$store.dispatch('fetchArticleListByPage', {id, n})

      return list
    }
  }
}
</script>

