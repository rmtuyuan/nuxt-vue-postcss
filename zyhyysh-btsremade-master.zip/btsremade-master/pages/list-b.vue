<style lang="less">
.page-list {
  .section-header {
    background-color: #e1e1e1;
    height: 0;
    padding-bottom: 42.5%;
    position: relative;
    margin-bottom: 40px;

    .section-header-inner {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 60px;
      // text-align: right;

      h3 {
        margin: 0;
        font-weight: bold;
        letter-spacing: .02em;
        font-size: 26px;
      }

      h4 {
        font-size: 20px;
        margin-top: 16px;
        margin-bottom: 24px;
      }

      p {
        font-size: .875rem;
        line-height: 1.6em;
      }

      hr {
        border-color: black;
        border-width: 2px;
        margin-bottom: 24px;
      }
    }
  }

  .section-item {
    header {
      height: 0;
      padding-bottom: 66.67%;
      background-color: #e1e1e1;
      position: relative;

      .section-item-header-label {
        position: absolute;
        right: 15px;
        bottom: 10px;
        padding: 0px 10px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
      }
    }

    a {
      display: block;
      text-decoration: none;
      letter-spacing: .05em;

      h3 {
        color: black;
      }

      h4 {
        color: #959595;
        margin-top: 12px;
        margin-bottom: 28px;
        line-height: 20px;
        height: 20px;
      }

      p {
        color: #959595;
        font-size: .75rem;
        line-height: 18px;
        height: 72px;
      }

      &:hover {
        span {
          background-color: black;
          color: white;
        }
      }
    }

    hr {
      margin-top: 50px;
      margin-bottom: 60px;
    }
  }

  .article-list {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    margin-top: 30px;
  }
}
</style>

<template>
  <div class="page-list container">
    <div class="row">
      <div class="col-xs-2">
        <nav-aside :category="2" title="白塔事件" :sections="sections" :active="1"></nav-aside>
      </div>

      <div class="col-xs-10">
        <header class="section-header">
          <div class="section-header-inner">
            <div class="row">
              <div class="col-xs-4 col-xs-offset-7">
                <hr>
                <h3>2015年北京国际设计周</h3>
                <h4>连接与共生</h4>
                <p>2015年北京国际设计周——“白塔寺再生计划”以“连接与共生”为主题，通过40余项设计展览展示活动、论坛，以及强化的可视化项目和线上线下一体化平台，将成为领略和重新发现该区域丰富文化、独一无二城市结构和历史的出发点。</p>
              </div>
            </div>
          </div>
        </header>

        <h3>
          <span class="impact">BEIJINGDESIGNWEEK</span><br>
          <span>北京国际设计周</span>
        </h3>

        <div class="row article-list">
          <template v-for="article in articles">
            <article-item class="col-xs-4"
                          :title="article.title"
                          :time="article.time"
                          :link="article.link"
                          :img="article.img"></article-item>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import ArticleItem from '~/components/ArticleItem.vue'

export default {
  layout: 'default',
  components: {
    NavAside, ArticleItem
  },
  asyncData () {
    return {
      sections: [
        {
          title: '北京国际设计周',
          title_en: 'BEIJINGDESIGNWEEK',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔新事',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        }
      ],
      articles: [
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article',
          img: 'img01.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img02.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article',
          img: 'img03.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article-nosidebar',
          img: 'img04.jpg'
        },
        {
          title: '城市博物馆',
          time: '2017.08.08',
          link: '/article',
          img: 'img05.jpg'
        }
      ]
    }
  },
  computed: {
    currentSectionIdx () {
      return 1
    }
  }
}
</script>