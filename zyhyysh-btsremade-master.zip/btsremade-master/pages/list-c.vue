<style lang="less" scoped>
.page-works {
  .work-list {
    margin-top: 2rem;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>

<template>
  <div class="page-works container">
    <div class="row">
      <div class="col-xs-2">
        <nav-aside :category="2" title="白塔事件" :sections="sections" :active="2"></nav-aside>
      </div>

      <div class="col-xs-10">
        <div class="row">
          <div class="col-xs-3">
            <selector :options="['A组', 'B组', 'C组', 'D组']"></selector>
          </div>
          <div class="col-xs-3">
            <selector :options="['A-1', 'A-2', 'A-3', 'A-4']"></selector>
          </div>
        </div>
        <div class='row work-list'>
          <template v-for="work in works">
            <work-item class="col-xs-4" 
                       :img="work.img" 
                       :title="work.title" 
                       :descp="work.descp" 
                       :wid="work.id"
                       :link="work.link"></work-item>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'
import WorkItem from '~/components/WorkItem.vue'
import Selector from '~/components/Selector.vue'

export default {
  layout: 'default',
  components: {
    NavAside, Selector, WorkItem
  },
  asyncData () {
    return {
      sections: [
        {
          title: '北京国际设计周',
          title_en: 'BEIJINGDESIGNWEEK',
          cover: '',
          sub: [
            {
              title: '2017年北京国际设计周',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '2016年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            },
            {
              title: '2015年北京国际设计周',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔寺国际方案征集',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '设计市集',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '院落更新国际方案征集',
              sub_title: '北京小院儿的重生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        },
        {
          title: '白塔新事',
          title_en: 'TRANS-DESIGN 2016',
          cover: '',
          sub: [
            {
              title: '威尼斯双年展',
              sub_title: '连接与共生',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 43,
              img: ''
            },
            {
              title: '上海设计之变',
              sub_title: '',
              descp: '“共享.再生”平行展是第十五届威尼斯国际建筑双年展官方授权的重要平行展项目之一，整个展览融合来自建筑、设计、 艺术、新媒体、舞蹈、声音、科技等不同领域的跨学科协作',
              sub_count: 23,
              img: ''
            }
          ]
        }
      ],
      works: [
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        },
        {
          img: 'img01.jpg',
          title: '晴耕雨读',
          descp: '周兆前，刘奕秋，唐尧峰，沈旸',
          id: 'A-1-847',
          link: '/work-detail'
        }
      ]
    }
  }
}
</script>
