<template>
  <div>
    <nuxt/>
    <!-- <page-footer></page-footer> -->
  </div>
</template>

<style>
html {
  font-family: "Source Sans Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  font-size: 16px;
  word-spacing: 1px;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: border-box;
  margin: 0;
}

.page-content {
  min-height: 100vh;
  /*margin-top: 50px;*/
}
</style>

<script>
import PageHeader from '../components/PageHeader'
import PageFooter from '../components/PageFooter'
import Navbar from '~/components/Navbar'

export default {
  components: { PageHeader, Navbar, PageFooter }
}
</script>
