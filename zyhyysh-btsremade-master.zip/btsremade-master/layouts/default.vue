<style lang="less">
html {
  font-family: "Source Sans Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  font-size: 16px;
  word-spacing: 1px;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: border-box;
  margin: 0;
}

.layout-container {
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  width: 100vw;
  min-height: 100vh;
  overflow-x: hidden;
  background-size: 2880px 2880px;
  background-position: center;
  background-repeat: repeat-y;
  padding-top: 3rem;

  @media only screen and (min-width: 768px) {
    background-image: url(/layout_bg.png);
    padding-top: 0;
  }
}

.page-content {
  flex: 1;
  padding-top: 50px;
  padding-bottom: 100px;
  // min-height: calc(100vh - 476px);
  // margin-top: 50px;

  .row {
    display: flex;
    flex-wrap: wrap;
  }

  @media only screen and (max-width: 719px) {
    width: 100%;
    padding-top: 50px;
  }
}
</style>

<template>
  <div class="layout-container" :style="layoutStyle">
    <page-header class="hidden-xs"></page-header>
    <navbar class="hidden-xs" ref="navbar"></navbar>
    <!-- <nav-mobile class="hidden-sm hidden-md hidden-lg" ref="navmobile"></nav-mobile> -->
    <div class="page-content container">
      <nuxt/>
    </div>
    <page-footer></page-footer>
    <div class="fixed-top">
      <navbar class="hidden-xs topnav" v-if="showTopbar"></navbar>
      <nav-mobile class="hidden-sm hidden-md hidden-lg"></nav-mobile>
      <hr>
    </div>
  </div>
</template>

<script>
import PageHeader from '../components/PageHeader'
import PageFooter from '../components/PageFooter'
import Navbar from '~/components/Navbar'
import NavMobile from '~/components/NavMobile'

export default {
  components: {
    PageHeader, Navbar, PageFooter, NavMobile
  },
  data () {
    return {
      scrollTop: 0,
      $navbar: null
    }
  },
  computed: {
    showTopbar () {
      if (this.scrollTop > 0 && this.$refs.navbar) {
        return this.scrollTop >= this.$refs.navbar.$el.offsetTop - 4
      }
    },
    showTopMobile () {
      if (this.scrollTop > 0 && this.$refs.navmobile) {
        return this.scrollTop >= this.$refs.navmobile.$el.offsetTop - 4
      }
    },
    layoutStyle () {
      return {
        backgroundPosition: `50% ${this.scrollTop * -0.1}px`
      }
    }
  },
  mounted () {
    let tick = false
    window.addEventListener('scroll', () => {
      if (!tick) {
        tick = true
        window.requestAnimationFrame(() => {
          this.scrollTop = window.scrollY
          tick = false
        })
      }
    })
  }
}
</script>
