<style lang="less">
.page-with-nav {

}
</style>

<template>
  <div class="page-with-nav row">
    <div class="col-xs-2 hidden-xs hidden-sm">
      <nav-aside></nav-aside>
    </div>

    <div class="col-xs-12 col-md-10">
      <nuxt/>
    </div>
  </div>
</template>

<script>
import NavAside from '~/components/NavAside.vue'

export default {
  layout: 'default',
  components: { NavAside }
}
</script>