<style lang="less">
.page-without-nav {

}
</style>

<template>
  <div class="page-without-nav row">
    <div class="col-xs-12">
      <nuxt/>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'default'
}
</script>