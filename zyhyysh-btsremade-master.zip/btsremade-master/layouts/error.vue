<style scoped>
html {
  font-family: "Source Sans Pro", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  font-size: 16px;
  word-spacing: 1px;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: border-box;
  margin: 0;
}

.page-content {
  min-height: calc(100vh - 476px);
  margin-top: 50px;
}
</style>

<template>
  <div>
    <page-header></page-header>
    <navbar ref="navbar"></navbar>
    <div class="page-content">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
            <h3>网络错误...</h3>
            <p>请刷新页面，给您带来不便，请谅解</p>
            <!-- <p>{{error}}</p> -->
            <a href="/home">回首页</a>
          </div>
        </div>
      </div>
    </div>
    <page-footer></page-footer>
    <div class="fixed-top">
      <navbar class="topnav" v-if="showTopbar"></navbar>
      <hr>
    </div>
  </div>
</template>

<script>
import PageHeader from '../components/PageHeader'
import PageFooter from '../components/PageFooter'
import Navbar from '~/components/Navbar'

export default {
  components: { PageHeader, Navbar, PageFooter },
  props: {
    error: Error
  },
  data () {
    return {
      scrollTop: 0,
      $navbar: null
    }
  },
  computed: {
    showTopbar () {
      if (this.scrollTop > 0 && this.$refs.navbar) {
        return this.scrollTop >= this.$refs.navbar.$el.offsetTop
      }
    }
  },
  mounted () {
    console.dir(this.error)
    let tick = false
    window.addEventListener('scroll', () => {
      if (!tick) {
        tick = true
        window.requestAnimationFrame(() => {
          this.scrollTop = window.scrollY
          tick = false
        })
      }
    })
  }
}
</script>
