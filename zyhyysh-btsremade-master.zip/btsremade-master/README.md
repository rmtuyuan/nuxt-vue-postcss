# btsremade

> 白塔寺再生计划

## Build Setup

``` bash
# install dependencies
$ npm install # Or yarn install

# serve with hot reload at localhost:3000
$ npm run dev

# build for production and launch server
$ npm run build
$ npm start

# generate static project
$ npm run generate
```

For detailed explanation on how things work, checkout the [Nuxt.js docs](https://github.com/nuxt/nuxt.js).

## Dockerize

# build image
$ docker build -t nuxt.btsremade.com .

# serve at localhost:3001
$ docker run -dt -p 3001:3000 nuxt.btsremade.com
