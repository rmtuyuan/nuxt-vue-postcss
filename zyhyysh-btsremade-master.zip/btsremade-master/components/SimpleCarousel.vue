<style lang="less">
.simple-carousel {
  position: relative;

  .sc-inner {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;

    .sc-item {
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;
      width: 100%;
      height: 100%;

      transition: all ease-in-out 1s;
      z-index: 1;

      &.next {
        opacity: 0;
        transform: translateX(100%);
      }

      &.prev {
        opacity: 0;
        transform: translateX(-100%);
      }

      .sc-img {

      }
    }
  }
}
</style>

<template>
  <div class="simple-carousel">
    <div class="sc-inner">
      <div v-for="(img, index) in displayImages"
           class="sc-item"
           :class="{'active': index === 1, 'next': index === 2, 'prev': index === 0}"
           :key="img">
        <img class="sc-img"
             :src="img"
             :style="imgStyle(img)"
             @load="imgLoaded($event, img)">
        <!-- <div class="sc-item"
             :class="{'active': index === 1, 'next': index === 2, 'prev': index === 0}"
             :style="bgStyle(img)"
             :key="img"></div> -->
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    images: {
      type: Array,
      required: true
    },
    autoplay: Boolean,
    interval: {
      type: Number,
      default: 5000
    },
    loop: Boolean,
    /* cover | contain | auto */
    imageSize: {
      type: String,
      default: 'contain',
      validator (val) {
        return val.match(/cover|contain|auto/)
      }
    }
  },
  data () {
    return {
      index: 0,
      timer: null,
      selfWidth: 0,
      selfHeight: 0,
      selfRatio: 0,
      loadedImageSizes: {}
    }
  },
  computed: {
    displayImages () {
      if (this.index === 0) {
        return [this.images[this.images.length - 1]].concat(this.images.slice(0, 2))
      } else if (this.index === this.images.length - 1) {
        return this.images.slice(this.images.length - 2).concat(this.images[0])
      } else {
        return this.images.slice(this.index - 1, this.index + 2)
      }
    }
  },
  methods: {
    imgLoaded (ev, img) {
      console.log(img, ev.target.naturalWidth)
      this.$set(this.loadedImageSizes, img, {
        width: ev.target.naturalWidth,
        height: ev.target.naturalHeight
      })
    },
    imgStyle (img) {
      let width = 'auto'
      let height = 'auto'

      if (img in this.loadedImageSizes) {
        let ratio = this.loadedImageSizes[img].width / this.loadedImageSizes[img].height

        if (ratio >= this.selfRatio) {
          height = `${this.selfHeight}px`
          width = `${this.selfHeight * ratio}px`
        } else {
          width = `${this.selfWidth}px`
          height = `${this.selfWidth / ratio}px`
        }
      }

      return {
        width,
        height
      }
    },
    bgStyle (img) {
      return `background-image: url(${img}); background-size: ${this.imageSize}`
    },
    next () {
      this.pause()

      this.index += 1
      if (this.index > this.images.length - 1) {
        this.index = this.loop ? 0 : this.images.length - 1
      }

      this.$emit('carousel:run', {
        index: this.index,
        direction: 1
      })

      if (this.autoplay) {
        this.play()
      }
    },
    prev () {
      this.pause()

      this.index -= 1
      if (this.index < 0) {
        this.index = this.loop ? this.images.length - 1 : 0
      }

      this.$emit('carousel:run', {
        index: this.index,
        direction: -1
      })

      if (this.autoplay) {
        this.play()
      }
    },
    play () {
      this.timer = window.setTimeout(() => {
        this.next()
      }, this.interval)
    },
    pause () {
      window.clearTimeout(this.timer)
    }
  },
  mounted () {
    this.selfWidth = this.$el.offsetWidth
    this.selfHeight = this.$el.offsetHeight
    this.selfRatio = this.selfWidth / this.selfHeight

    if (this.autoplay) {
      this.play()
    }
  }
}
</script>