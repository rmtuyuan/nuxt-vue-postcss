<style lang="less">
.article-item {
  margin-bottom: 60px;
  display: flex;
  flex-direction: column;

  hr {
    margin-top: 0;
    border-width: 2px;
    border-color: black;
  }

  a {
    flex: 1;
    display: flex;
    flex-direction: column;
    color: black;
    text-decoration: none;

    span {
      // background-color: white;
    }

    h2 {
      flex: initial;
      margin-top: 0;
      font-size: 1.5rem;
      line-height: 1.5em;
      min-height: 3em;
    }

    h3 {
      flex: initial;
      margin: 0;
      // margin-bottom: 20px;
      color: #929292;
      font-weight: 400;
      font-family: DIN Alternate;

      &.time-in-header {
        text-align: right;
      }
    }

    &:hover,
    &:focus {
      span {
        color: white;
        background-color: black;
      }
    }
  }

  .category {
    display: flex;
    flex-direction: row;
    align-items: center;

    .category-icon {
      margin-right: 0.5em;
    }

    h4 {
      font-size: 1rem;
      color: black;
      font-weight: bold;
      margin: 0;
    }
  }

  .info {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1.5rem;

    .category, .time {
      margin-top: 10px;
    }
  }

  .img {
    flex: 1;
    width: 100%;
    height: 0;
    padding-bottom: 100%;
    background-size: cover;
    background-position: center;
    // display: flex;
    // flex-direction: column;
    // justify-content: flex-end;

    // img {
    //   max-width: 100%;
    //   flex: initial;
    // }
  }

  &.in-aside {
    margin-bottom: 40px;

    h2 {
      font-size: 20px;
    }
  }
}
</style>

<template>
  <div class="article-item" :class="{'in-aside': inParent === 'aside'}">
    <hr>
    <nuxt-link :to="link">
      <header>
        <h2>
          <span>{{title}}</span>
        </h2>
      </header>
      <div class="info">
        <div class="category" v-if="inParent === 'index'">
          <category-icon :category="category"></category-icon>
          <h4>{{categoryName}}</h4>
        </div>

        <!-- <h3 class="time" v-if="inParent === 'list' || inParent === 'index'">{{time}}</h3> -->
      </div>
      <div class="img" ref="imgout" :style="`background-image: url('${imgSrc}')`">
        <!-- <img :src="imgSrc" :style="imgStyle" @load="_imgLoad"> -->
      </div>
    </nuxt-link>
  </div>
</template>

<script>
import CategoryIcon from '~/components/CategoryIcon'

export default {
  components: {
    CategoryIcon
  },
  props: {
    category: {
      type: [String, Number],
      default: 1
    },
    title: String,
    time: String,
    img: String,
    link: String,
    /* list | index | aside */
    inParent: {
      type: String,
      default: 'list'
    }
  },
  data () {
    return {
      isMounted: false,
      selfWidth: 0,
      imgSize: {
        width: 0,
        height: 0
      }
    }
  },
  computed: {
    imgSrc () {
      // if (this.isMounted) {
      if (typeof this.img === 'string' && this.img.length > 10) {
        return `${this.img}?x-oss-process=image/resize,w_600`
      } else {
        return '/itemplaceholder.jpg'
      }
      // }
    },
    // imgStyle () {
    //   if (this.imgSize.width > 0 && this.imgSize.height > 0) {
    //     return {
    //       height: `${this.selfWidth * this.imgSize.height / this.imgSize.width}px`
    //     }
    //   } else {
    //     return {
    //       maxHeight: '1px',
    //       opacity: 0
    //     }
    //   }
    // },
    categoryName () {
      if (typeof this.category === 'string') {
        return this.category
      } else {
        return this.$store.getters.mainNav[this.category - 1].title_zh
      }
    }
  },
  methods: {
    // _imgLoad (ev) {
    //   this.selfWidth = this.$refs.imgout.offsetWidth
    //   this.imgSize = {
    //     width: ev.target.naturalWidth,
    //     height: ev.target.naturalHeight
    //   }
    // }
  },
  mounted () {
    this.isMounted = true
    // this.selfWidth = this.$refs.imgout.offsetWidth

    // let th = null

    // window.addEventListener('resize', () => {
    //   window.clearTimeout(th)
    //   th = window.setTimeout(() => {
    //     this.selfWidth = this.$refs.imgout.offsetWidth
    //   }, 300)
    // })
  },
  updated () {
    // this.selfWidth = this.$refs.imgout.offsetWidth
  }
}
</script>
