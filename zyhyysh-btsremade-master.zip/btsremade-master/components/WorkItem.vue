<style lang="less">
.work-item {
  // display: flex;
  margin-bottom: 30px;
  
  .img {
    height: 0;
    padding-bottom: 66.67%;
    background-size: cover;
  }

  a {
    color: black;

    h5, p {
      opacity: .3;
    }

    h4 {
      font-size: 20px;
    }

    &:hover,
    &:focus {
      text-decoration: none;

      span {
        background-color: black;
        color: white;
      }
    }
  }
}
</style>

<template>
  <div class="work-item">
    <nuxt-link :to="link">
      <div class="img" :style="imgBg"></div>
      <h5>{{wid}}</h5>
      <h4>
        <span>{{title}}</span>
      </h4>
      <p>{{descp}}</p>
    </nuxt-link>
  </div>
</template>

<script>
export default {
  props: {
    img: String,
    title: String,
    descp: String,
    wid: String,
    link: String
  },
  computed: {
    imgBg () {
      return {
        backgroundImage: `url(${this.img}?x-oss-process=image/resize,w_600)`
      }
    }
  }
}
</script>
