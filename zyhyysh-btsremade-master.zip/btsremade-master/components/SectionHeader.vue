<style lang="less">
.section-header {
  margin-bottom: 40px;

  .link {
    color: black;
    display: flex;
    align-items: center;
    justify-content: space-between;

    h3 {
      margin: 0;
    }
  }

  .link + p {
    margin-top: 1.5rem;
  }

  &.has-descp {
    background-color: #e1e1e1;

    .sh-inner {
      padding-top: 3rem;
      padding-bottom: 2rem;

      .link {
        align-items: flex-start;
        flex-direction: column;
      }
    }
  }


  &.has-cover {
    background-color: white;

    .sh-inner {
      @media only screen and (max-width: 767px) {
        padding-top: 0
      }

      position: relative;

      .sh-cover {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-size: cover;
        background-position: center;
      }

      .sh-cover-mobile {
        margin-bottom: 1rem;
      }

      .title-group {
        @media only screen and (min-width: 768px) {
          min-height: 240px;
        }
      }

      @media only screen and (max-width: 767px) {
        a.link {
          h4 {
            color: #959595;
            margin-top: 12px;
            margin-bottom: 28px;
            line-height: 20px;
            height: 20px;
          }
        }

        p {
          color: #959595;
          font-size: .75rem;
          line-height: 18px;
          margin-top: 0;
        }
      }
    }
  }

  hr {
    border-width: 2px;
  }
}
</style>

<template>
  <header class="section-header" :class="{'has-cover': hasCover, 'has-descp': hasDescp}">
    <div class="sh-inner had-descp" v-if="hasDescp">
      <div class="row">
        <div class="sh-cover col-xs-12 hidden-xs" :style="`background-image: url(${extendInfo.cover})`"></div>
        <div class="col-xs-12">
          <img class="sh-cover-mobile img-responsive hidden-sm hidden-md hidden-lg" :src="extendInfo.imgs[0]">
        </div>
        <div class="title-group has-cover col-xs-12 col-sm-7 col-sm-offset-4 col-md-4 col-md-offset-7" v-if="hasCover">
          <hr class="hidden-xs">
          <nuxt-link class="link" :to="section.link">
            <h3>
              <template v-if="$route.params.lang === 'en'">
                <span class="impact">{{section.name_en}}</span><br>
              </template>
              <span v-else>{{section.name_zh}}</span>
            </h3>
            <h4 v-if="extendInfo.sub_name_zh && $route.params.lang === 'zh'">{{extendInfo.sub_name_zh}}</h4>
          </nuxt-link>
          <p v-if="$route.params.lang === 'zh'" v-for="c in extendInfo.descp_zh">
            {{c}}
          </p>
          <!-- <hr> -->
        </div>

        <div class="title-group col-xs-12 col-xs-10 col-xs-offset-1" v-else>
          <nuxt-link class="link" :to="section.link">
            <h3>
              <template v-if="$route.params.lang === 'en'">
                <span class="impact">{{section.name_en}}</span><br>
              </template>
              <span v-else>{{section.name_zh}}</span>
            </h3>
            <h4 v-if="extendInfo.sub_name_zh && $route.params.lang === 'zh'">{{extendInfo.sub_name_zh}}</h4>
          </nuxt-link>
          <p v-if="$route.params.lang === 'zh'" v-for="c in extendInfo.descp_zh">
            {{c}}
          </p>
          <!-- <hr> -->
        </div>
      </div>
    </div>

    <div class="row sh-inner" v-else>
      <div class="title-group col-xs-12" :class="titleClass">
        <nuxt-link class="link" :to="section.link">
          <h3>
            <template v-if="$route.params.lang === 'en'">
              <span class="impact">{{section.name_en}}</span><br>
            </template>
            <span v-else>{{section.name_zh}}</span>
          </h3>
          <svg width="17px" height="44px" viewBox="0 0 17 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <defs>
              <path d="M1.62792073,0.609197438 L6.1193937,0.609197438 L16.6393712,21.2075965 L5.28293382,43.4438064 L0.791460852,43.4438064 L12.1478982,21.2075965 L1.62792073,0.609197438 Z" id="path-1"></path>
            </defs>
            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
              <g id="白塔寺首页" transform="translate(-1284.000000, -869.000000)">
                <g id="Group-9" transform="translate(140.000000, 855.000000)">
                  <g id="Path-11" transform="translate(1144.000000, 14.000000)">
                    <mask id="mask-2" fill="white">
                      <use xlink:href="#path-1"></use>
                    </mask>
                    <use id="Combined-Shape" fill="#000000" xlink:href="#path-1"></use>
                  </g>
                </g>
              </g>
            </g>
          </svg>
        </nuxt-link>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  props: {
    section: Object,
    index: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    extendInfo () {
      return this.$store.state.tempNavInfo[this.section.id] || {}
    },
    hasDescp () {
      return !this.index && 'descp_zh' in this.extendInfo && this.extendInfo.descp_zh.length > 0
    },
    hasCover () {
      return 'cover' in this.extendInfo && this.extendInfo.cover.length > 0
    },
    titleClass () {
      if (this.hasDescp) {
        return 'col-xs-10 col-xs-offset-1 col-sm-7 col-sm-offset-4 col-md-4 col-md-offset-7'
      } else if (this.hasCover) {
        return 'col-xs-10 col-xs-offset-1'
      }
    }
  }
}
</script>