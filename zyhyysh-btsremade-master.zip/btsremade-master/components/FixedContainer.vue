<style lang="less">
.fixed-container {
  height: 100%;
}
</style>

<template>
  <div class="fixed-container">
    <div class="fc-inner" ref="inner" :style="innerStyle">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    offset: Number
  },
  data () {
    return {
      barWidth: 0,
      barFixed: false,
      barOffset: 0
    }
  },
  computed: {
    innerStyle () {
      if (this.barFixed) {
        return {
          width: `${this.barWidth}px`,
          position: 'fixed',
          top: `${this.offset}px`,
          transform: `translateY(${this.barOffset}px)`
        }
      }
    }
  },
  mounted () {
    let selfBounding = this.$el.getBoundingClientRect()
    const barTop = selfBounding.top + window.scrollY
    this.barWidth = selfBounding.width
    const innerHeight = this.$refs.inner.getBoundingClientRect().height
    let tick = false
    // let needFixAside = innerHeight + this.offset <= window.innerHeight

    window.addEventListener('scroll', () => {
      if (!tick) {
        tick = true
        window.requestAnimationFrame(() => {
          const barHeight = this.$el.offsetHeight
          if (barHeight + barTop <= innerHeight + window.scrollY + this.offset) {
            this.barOffset = barHeight + barTop - innerHeight - window.scrollY - this.offset
          } else {
            this.barOffset = 0
          }

          if (window.scrollY >= barTop - this.offset) {
            this.barFixed = true
          } else {
            this.barFixed = false
          }

          tick = false
        })
      }
    })

    let th = null

    window.addEventListener('resize', () => {
      window.clearTimeout(th)
      th = window.setTimeout(() => {
        selfBounding = this.$el.getBoundingClientRect()
        // innerBounding = this.$refs.inner.getBoundingClientRect()
        this.barWidth = selfBounding.width
        this.barFixed = false
        // needFixAside = innerHeight + this.offset <= window.innerHeight
      }, 300)
    })
  }
}
</script>