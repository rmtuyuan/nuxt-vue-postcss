<style lang="less">
.navbar {
  position: relative;
  z-index: 1000;
  border-radius: 0;
  margin-bottom: 0;
  border: none;
  width: 100%;

  hr {
    border-color: black;
    margin: 0;
  }

  &.topnav {
    & > hr {
      display: none;
    }
  }

  .btn-menu {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    width: 44px;
  }


  &.topnav {
    .tophr {
      display: none;
    }
  }
  // @media only screen and (max-width: 720px) {
  //   .navbar-item hr {
  //     margin-left: 10px;
  //     margin-right: 10px;
  //   }
  // }

  // &.topnav {
  //   margin-top: -1px;
    
  //   .navbar-item.active {
  //     hr {
  //       display: none;
  //     }
  //   }
  // }
}
</style>

<template>
  <nav class="navbar" :class="{'en': isEn}">
    <div class="container">
      <hr class="tophr">
      <div class="row">
        <template v-for="(category, index) in navItems">
          <navbar-item class="col-xs-12 col-sm-3"
                       :showSubnav="showSubnavs[index]"
                       :category="index + 1"
                       :title="isEn ? category.name_en : category.name_zh"
                       :link="`/${$route.params.lang}${category.link}`"
                       :sub="category.children_nav"
                       @subnav:toggle="subnavToggle(index, $event)"></navbar-item>
        </template>
      </div>
    </div>
  </nav>
</template>

<script>
import Logo from './Logo.vue'
import NavbarItem from './NavbarItem.vue'
import { mapGetters } from 'vuex'
import { findCurrentCategory } from '~/assets/js/utils'

export default {
  components: {
    Logo, NavbarItem
  },
  data () {
    return {
      showSubnavs: [false, false, false, false]
    }
  },
  computed: {
    ...mapGetters(['mainNav']),
    isEn () {
      return this.$route.params.lang === 'en'
    },
    isMobile () {

    },
    navItems () {
      const nav = this.$store.state.nav
      return [8, 9, 10, 11].map((id) => {
        return nav.filter((nav) => nav.id === id).pop()
      })
    },
    currentCategory () {
      return findCurrentCategory(this.$store.state.nav, this.$route.fullPath)
    },
    isShowSubnav () {
      return this.showSubnavs.reduce((r, s) => r || s, false)
    }
  },
  methods: {
    subnavToggle (idx, ev) {
      this.showSubnavs = this.showSubnavs.map((v, index) => ev && index === idx)
    },
    closeAll () {
      this.showSubnavs = this.showSubnavs.map(() => false)
    }
  }
}
</script>