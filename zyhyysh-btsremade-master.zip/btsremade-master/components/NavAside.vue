<style lang="less">
.nav-aside {
  height: 100%;

  .na-inner {
    background-color: white;
  }

  header {
    padding: .25rem .5rem;
    display: flex;
    align-items: center;
    background: black;
    color: white;
    font-size: .875rem;
    font-weight: bold;
    letter-spacing: .2em;
    height: 48px;
    margin-bottom: 20px;

    a {
      color: white;
    }

    svg {
      margin-right: .5rem;
      transform: scale(.9);
    }
  }

  section {
    padding: 0 .5rem;

    h3 {
      opacity: .5;
      font-weight: 400;
    }

    h5 {
      font-weight: bold;
      opacity: .55;
    }

    a:hover {
      h5 {
        opacity: 1;
      }
    }

    p {
      margin: .25em 0;
    }

    li {
      margin: 0;
    }

    p, li {
      a {
        font-size: .75rem;
        color: black;
        opacity: .3;

        &:hover {
          opacity: .6;
          cursor: pointer;
          text-decoration: none;
        }

        svg #Rectangle-inner {
          opacity: 0;
        }

        &.nuxt-link-active {
          opacity: 1;

          svg #Rectangle-inner {
            opacity: 1;
          }
        }
      }
    }

    a {
      color: black;
    }

    a.nuxt-link-active {
      h3, h5 {
        opacity: 1;
      }
    }

    hr {
      margin-left: -0.5rem;
      margin-right: -0.5rem;
      
      &.no-children {
        opacity: .2;
      }
    }

    &:last-child {
      hr {
        opacity: 1;
      }
    }
  }

  article {
    p, a {
      font-size: 12px;
      opacity: .3;
      margin: 0;
      line-height: 1.5em;
    }

    a {
      color: black;
      text-decoration: underline;

      &:hover,
      &:focus {
        opacity: 1;
        
      }
    }
  }
}
</style>

<template>
  <aside class="nav-aside">
    <div class="na-inner">
      <header>
        <category-icon :category="category" tint="light"></category-icon>
        <nuxt-link :to="`/${$route.params.lang}${this.currentCategory.link}`">
          <span>{{category}}</span>
        </nuxt-link>
      </header>

      <section v-for="(section, index) in sub" :class="{'active': index+1 === active}">
        <nuxt-link :to="`/${$route.params.lang}${section.link}`">
          <!-- <h3>0{{index+1}}</h3> -->
          <h5>{{section[`name_${lang}`]}}</h5>
        </nuxt-link>
        <template v-if="'children_nav' in section" v-for="item in section.children_nav">
          <p>
            <nuxt-link :to="`/${$route.params.lang}${item.link}`">{{item[`name_${lang}`]}}</nuxt-link>
          </p>
          <ul class="list-unstyled" v-if="'children_nav' in item">
            <li v-for="subItem in item.children_nav">
              <nuxt-link :to="`/${$route.params.lang}${'link' in subItem ? subItem.link : '#'}`">
                <svg width="10px" height="10px" viewBox="0 0 10 10" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="白塔寺内容页2-copy-3" transform="translate(-142.000000, -388.000000)">
                      <g id="Group-4" transform="translate(142.000000, 388.000000)">
                        <rect id="Rectangle-outer" stroke="#000000" x="0.5" y="0.5" width="9" height="9"></rect>
                        <rect id="Rectangle-inner" fill="#000000" x="3" y="3" width="4" height="4"></rect>
                      </g>
                    </g>
                  </g>
                </svg>
                {{subItem[`name_${lang}`]}}
              </nuxt-link>
            </li>
          </ul>
        </template>
        <hr :class="{'no-children': !('children_nav' in section)}">
      </section>

      <!-- <article> -->
        <!-- <p>白塔寺再生计划媒体采访及宣传资料获取欢迎随时联系社区营造中心</p>
        <br>
        <p>联系方式：</p>
        <p>电话：</p>
        <a href="tel:010-66154269-604">010-66154269-604</a>
        <p>邮箱：</p>
        <a href="mailto:btsremade@163.com">btsremade@163.com</a> -->
      <!-- </article> -->
    </div>
  </aside>
</template>

<script>
import CategoryIcon from '~/components/CategoryIcon.vue'
import { findCurrentCategory } from '~/assets/js/utils'

export default {
  components: {
    CategoryIcon
  },
  props: {
    category: String,
    // title: String,
    sub: Array,
    active: Number,
    content: Object,
    lang: {
      type: String,
      default: 'zh'
    }
  },
  computed: {
    currentCategory () {
      return findCurrentCategory(this.$store.state.nav, this.$route.fullPath)
    }
  }
}
</script>