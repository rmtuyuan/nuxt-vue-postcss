<style lang="less">
.media-article-item {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;

  a {
    color: black;

    &:hover {
      .mai-title {
        span {
          background-color: black;
          color: white;
        }
      }
    }
  }

  .mai-cover {
    height: 0;
    padding-bottom: 55%;
    background-size: cover;
    background-position: center;
    margin-bottom: 10px;
  }

  .mai-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  hr {
    margin-top: 2rem;
    margin-bottom: 3.5rem;
  }
}
</style>

<template>
  <div class="media-article-item">
    <nuxt-link :to="link">
      <div class="mai-cover" :style="`background-image: url(${cover});`"></div>
      <div class="mai-info">
        <p class="mi-media">{{media.split(' ')[0]}}</p>
        <p class="mi-date">{{date}}</p>
      </div>
      <h3 class="mai-title"><span>{{title}}</span></h3>
    </nuxt-link>
    <hr>
  </div>
</template>

<script>
export default {
  props: {
    link: String,
    cover: String,
    title: String,
    media: String,
    date: String
  }
}
</script>