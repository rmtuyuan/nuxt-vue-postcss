<style lang="less">
.selector {
  position: relative;
  display: flex;
  flex-direction: column;

  button {
    background: none;
    border: 1px solid black;
    border-bottom: none;
    outline: none;
    height: 35px;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    color: black;
    padding: 0 1rem 0 1.5rem;

    &:hover,
    &:focus {
      text-decoration: none;
      background-color: black;
      
      span {
        color: white;
      }

      svg {
        #gfill {
          fill: white;
        }
      }
    }

    &.open {
      svg {
        transform: rotate(180deg);
      }
    }
  }

  span {
    font-size: .875rem;
    font-weight: bold;
    letter-spacing: .2em;
  }

  .option-list {
    position: absolute;
    left: 0;
    right: 0;
    width: 100%;
    overflow: hidden;
    display: flex;
    background: white;
    transform-origin: top;
    z-index: 998;

    border-left: 1px solid black;
    border-right:  1px solid black;

    ul {
      flex: 1;
      margin-bottom: 0;
    }

    button {
      border: none;
      border-top: 1px solid black;
      color: #b2b2b2;

      svg {
        transform: none;
      }
    }
  }

  .bottom-line {
    z-index: 1;
  }
  
  hr {
    position: relative;
    margin: 0;
    z-index: 999;
    border-color: black;
  }

  .mask {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(255, 255, 255, 0);
    z-index: 997;
  }
}
</style>

<template>
  <div class="selector">
    <div class="mask" v-show="showOptions" @click="_close"></div>
    <button :class="{'open': showOptions}" @click="_toggle">
      <span>{{current}}</span>
      
      <svg width="11px" height="5px" viewBox="0 0 11 5" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
          <!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
          <desc>Created with Sketch.</desc>
          <defs></defs>
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
              <g id="gfill" fill="#000000">
                  <polygon id="Mask" points="11 -6.66133815e-16 11 2.24736014 5.5 5 1.77635684e-15 2.24736014 0 1.084207e-13 5.5 2.75263986"></polygon>
              </g>
          </g>
      </svg>
    </button>
    <div class="option-list-container">
      <transition :css="false"
                  @enter="_enter"
                  @leave="_leave">
        <div class="option-list" ref="optionList" v-if="showOptions">
          <ul class="list-unstyled" ref="optionListContent">
            <li v-for="(option, index) in options">
              <button :class="{'active': index === value}" @click="_select(index)">
                <span>{{option}}</span>
                <svg v-if="index === value" width="10px" height="7px" viewBox="0 0 10 7" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <defs></defs>
                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="gfill" transform="translate(-21.000000, -35.000000)" fill="#000000">
                            <polygon id="Mask-Copy" points="22 37.9959717 21 39 24 42 31 36 30.0023193 35 24 40"></polygon>
                        </g>
                    </g>
                </svg>
              </button>
            </li>
          </ul>
        </div>
      </transition>
    </div>
    <div class="bottom-line" ref="bottomLine">
      <hr>
    </div>
  </div>
</template>

<script>
import Velocity from 'velocity-animate-server'

export default {
  props: {
    value: {
      type: Number,
      default: 0
    },
    options: Array
  },
  data () {
    return {
      showOptions: false,
      optionListHeight: 0
    }
  },
  computed: {
    current () {
      return this.options[this.value]
    }
  },
  methods: {
    _close () {
      this.showOptions = false
    },
    _toggle () {
      this.showOptions = !this.showOptions
    },
    _select (index) {
      // this.value = index
      this._close()
      this.$emit('input', index)
    },
    _enter (el, done) {
      this.optionListHeight = el.offsetHeight
      this.$refs.optionListContent.style.opacity = 0

      Promise.all([
        Velocity(el, 'stop'),
        Velocity(this.$refs.bottomLine, 'stop'),
        Velocity(this.$refs.optionListContent, 'stop'),
        Velocity(el, {
          scaleY: [1, 0]
        }, {
          duration: 300,
          easing: [0.215, 0.61, 0.355, 1]
        }),
        Velocity(this.$refs.bottomLine, {
          translateY: [`${this.optionListHeight}px`, 0]
        }, {
          duration: 300,
          easing: [0.215, 0.61, 0.355, 1]
        }),
        Velocity(this.$refs.optionListContent, {
          opacity: [1, 0]
        }, {
          duration: 200,
          delay: 150
        })
      ]).then(done)
    },
    _leave (el, done) {
      Promise.all([
        Velocity(el, 'stop'),
        Velocity(this.$refs.bottomLine, 'stop'),
        Velocity(this.$refs.optionListContent, 'stop'),
        Velocity(this.$refs.optionListContent, {
          opacity: 0
        }, {
          duration: 200
        }),
        Velocity(el, {
          scaleY: 0
        }, {
          duration: 300,
          easing: [0.47, 0, 0.745, 0.715],
          delay: 100
        }),
        Velocity(this.$refs.bottomLine, {
          translateY: [0, `${this.optionListHeight}px`]
        }, {
          duration: 300,
          easing: [0.47, 0, 0.745, 0.715],
          delay: 100
        })
      ]).then(() => {
        this.$refs.bottomLine.style.transform = ''
        done()
      })
    }
  }
}
</script>
