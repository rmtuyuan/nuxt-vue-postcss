<style lang="less">
.nav-mobile {
  padding: 0 1rem;
  height: 3rem;
  overflow: hidden;
  // overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  transition: height .3s;
  // display: flex;
  // flex-direction: column;
  // justify-content: space-between;

  &.open {
    height: 100vh;
  }

  ul {
    margin: 0;
    margin-bottom: 3rem;
    overflow: hidden;
    transition: transform .3s;

    li {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: center;
      border-bottom: 1px solid black;
      // padding: 1rem 0;

      &.lang {
        flex-direction: row;
        margin-left: -.5rem;
        margin-right: -.5rem;

        a {
          height: 3rem;
          flex: 1;
          justify-content: center;
          border-bottom: 1px solid black;
          margin: 0 .5rem;
        }
      }

      &:last-child {
        border-bottom: none;
      }

      .category-inner {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;

        .btn-open-subnav {
          width: 40px;
          flex: initial;
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }

      .subnav {
        width: 100%;
      }

      ul {
        margin: 0;
        // padding-bottom: 1rem;

        li {
          padding: 0;
          border: none;
          flex-direction: row;
          // border-top: 1px solid black;

          &:last-child {
            margin-bottom: 1rem;
          }
        }
      }

      hr {
        flex: 1;
        margin: 0;
      }

      button {
        background: none;
        border: none;
        outline: none;
        padding: 0;
        min-height: 3rem;
        width: 40px;
        text-align: center;
        color: black;
        font-size: .875rem;
        font-weight: bold;
      }

        

      a {
        height: 2rem;
        display: flex;
        align-items: center;
        color: black;
        font-size: .75rem;
        font-weight: bold;

        h5 {
          font-weight: 700;
        }
      }

      .category-left {
        width: 40px;
        height: 3rem;
        display: flex;
        align-items: center;
        justify-content: center;
        // margin-left: 1rem;
      }

      .category-right {
        flex: 1;
        // border-top: 1px solid black;
      }

      &.home {
        transition: padding 300ms;
        // padding-left: 40px;

        a {
          height: 3rem;
          transition: height 300ms;
        }

        .logo {
          // padding: .5rem 0;
          svg {
            width: auto;
            height: 2rem;
            transition: height 300ms;
          }
        }
      }
    }
  }

  button.btn-close {
    width: 100%;
    height: 3rem;
    padding: 0;
    margin: 0;
    border: none;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    background: transparent;
    outline: none;
    display: flex;
    align-items: center;
    justify-content: center;

  }

  .caret {
    margin: 0;
    transform: rotate(90deg);
    transition: transform .3s;
  }

  .caret.reverse {
    transform: rotate(0deg);
  }

  button.btn-toggle-nav {
    background: none;
    border: none;
    box-shadow: none;
    outline: none;
    position: absolute;
    right: 1rem;
    top: 0px;
    width: 40px;
    height: 3rem;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    transform: translateY(0);
    transition: transform .3s;

    span {
      display: black;
      width: 20px;
      height: 2px;
      margin: 2px;
      background-color: black;
      transition: transform .3s, opacity .2s;
    }
  }

  &.open {
    // overflow-y: scroll;

    .home {
      padding: 1rem 0;

      a {
        height: 3rem;

        .logo {
          svg {
            height: 3rem;
          }
        }
      }
    }

    button.btn-toggle-nav {
      transform: translateY(1rem);

      span:first-child {
        transform: translateY(6px) rotate(45deg);
      }

      span:nth-child(2) {
        opacity: 0;
      }

      span:last-child {
        transform: translateY(-6px) rotate(-45deg);
      }
    }
  }
}
</style>

<template>
  <nav class="nav-mobile" :class="{'open': open}">
    <div ref="atop"></div>
    <ul class="list-unstyled" :style="navOffset">
      <li class="home">
        <div class="category-inner">
          <div class="category-left">
            <!-- <button @click="scroll">sss</button> -->
          </div>
          <nuxt-link :to="`/${$route.params.lang}`">
            <Logo></Logo>
          </nuxt-link>
          <div class="category-left"></div>
        </div>
      </li>
      <template v-for="(category, index) in navItems">
        <li>
        <!-- </li>
        <li v-if="open || currentNavIdx === index"> -->
          <div class="category-inner">
            <div class="category-left">
              <category-icon :category="category.name_zh"></category-icon>
            </div>
            <!-- <div class="category-right">
              <button>{{category.name_zh}}</button>
              
            </div> -->
            <nuxt-link :to="`/${$route.params.lang}${category.link}`">
              <h5>{{category[`name_${$route.params.lang}`]}}</h5>
            </nuxt-link>
            <div class="category-left">
              <button class="btn-open-subnav" @click="toggleSubNav(index)" v-if="open">
                <span class="caret" :class="{'reverse': currentNavIdx === index}" v-if="category.children_nav && category.children_nav.length > 0"></span>
              </button>
            </div>
          </div>
          <div class="subnav">
            <transition :css="false"
                        @enter="enter"
                        @leave="leave">
              <ul class="list-unstyled" v-if="open && currentNavIdx === index">
                <li v-for="(section, index) in category.children_nav">
                  <nuxt-link :to="`/${$route.params.lang}${section.link}`">{{section[`name_${$route.params.lang}`]}}</nuxt-link>
                </li>
              </ul>
            </transition>
          </div>
        </li>
      </template>
      <!-- <li v-if="open"> -->
      <!-- </li>
      <li v-if="open"> -->
        <!-- <button class="btn-close" @click="open = false">
          <span class="caret" :class="{'reverse': open}"></span>
        </button>
      </li> -->
      <li class="lang">
        <nuxt-link to="/zh">
          <h5>中</h5>
        </nuxt-link>
        <nuxt-link to="/en">
          <h5>EN</h5>
        </nuxt-link>
      </li>
    </ul>
    <!-- <button class="btn-close" @click="open = !open">
      <span class="caret" :class="{'reverse': open}"></span>
    </button> -->

    <button class="btn-toggle-nav" @click="toggleNav">
      <span></span>
      <span></span>
      <span></span>
    </button>
  </nav>
</template>

<script>
import CategoryIcon from './CategoryIcon'
import Logo from './Logo.vue'
import { findCurrentCategory } from '~/assets/js/utils'
import Velocity from 'velocity-animate-server'

export default {
  components: {
    Logo, CategoryIcon
  },
  data () {
    return {
      open: false,
      currentNavIdx: 0,
      showSubNavIdx: 0
    }
  },
  computed: {
    navItems () {
      return this.$store.state.nav
    },
    currentCategory () {
      return findCurrentCategory(this.$store.state.nav, this.$route.fullPath)
    // },
    // currentNavIdx () {
    //   return this.navItems.reduce((idx, item, index) => {
    //     console.log(item.absname, this.currentCategory.absname, index)
    //     if (item.absname === this.currentCategory.absname) {
    //       return index + 1
    //     } else {
    //       return idx
    //     }
    //   }, 0)
    },
    navOffset () {
      if (this.open) {
        return {
          transform: 'translateY(0)'
        }
      } else {
        return {
          transform: `translateY(-${(this.currentNavIdx + 1) * 49}px)`
        }
      }
    }
  },
  watch: {
    $route () {
      this.open = false
      this.currentNavIdx = this.getCurrentNavIdx()
    }
  },
  methods: {
    scroll () {
      Velocity(this.$refs.atop, 'scroll', {
        duration: 300,
        offset: 4,
        container: this.$el,
        axis: 'y'
      }).then(() => {
        this.$el.offsetTop = 0
      })
    },
    toggleNav () {
      this.$el.scrollTop = 0
      this.open = !this.open
      // this.$el.scrollTop = 0

      // Velocity(this.$refs.atop, 'scroll', {duration: 300, container: this.$el, axis: 'y', offset: 0}).then(() => {
      //   this.$nextTick(() => {
      //     this.open = !this.open
      //   })
      // })
    },
    toggleSubNav (idx) {
      // if (this.currentNavIdx === idx) {
      // this.open = !this.open
      // } else {
      if (this.currentNavIdx === idx) {
        this.currentNavIdx = 0
      } else {
        this.currentNavIdx = idx
      }
      // }
    },
    enter (el, done) {
      const h = el.offsetHeight
      el.style.opacity = 0

      Promise.all([
        Velocity(el, 'stop'),
        Velocity(el, {
          height: [h, 0],
          opacity: 1
        }, {
          duration: 300,
          easing: [0.645, 0.045, 0.355, 1]
        })
      ]).then(() => {
        el.style.height = ''
        done()
      })
    },
    leave (el, done) {
      Promise.all([
        Velocity(el, 'stop'),
        Velocity(el, {
          height: 0,
          opacity: 0
        }, {
          duration: 300,
          easing: [0.645, 0.045, 0.355, 1]
        })
      ]).then(() => {
        el.style.height = ''
        done()
      })
    },
    getCurrentNavIdx () {
      return this.navItems.reduce((idx, item, index) => {
        if (this.currentCategory && 'absname' in this.currentCategory && item.absname === this.currentCategory.absname) {
          return index
        } else {
          return idx
        }
      }, -1)
    }
  },
  mounted () {
    this.currentNavIdx = this.getCurrentNavIdx()
  }
}
</script>
