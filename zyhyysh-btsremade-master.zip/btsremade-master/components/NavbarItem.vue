<style lang="less">
.navbar-item {
  display: flex;
  flex-direction: column;

  &:before {
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    // height: 54px;
    content: '';
    background-color: white;
    z-index: 0;
  }

  .main-anchor {
    overflow: hidden;
  }

  a {
    z-index: 1;
    &:hover,
    &:focus {
      text-decoration: none;

      span {
        background-color: black;
        color: white;
      }
    }
  }

  .mainlink {
    height: 54px;
    display: flex;
    align-items: center;
    overflow: hidden;

    &:hover {
      // background-color: white;
    }

    &.disabled {
      cursor: not-allowed;

      span {
        background: none;
        color: black;
      }
    }
  }

  svg {
    margin-right: .5rem;
    text-decoration: none;
  }

  span {
    font-size: .875rem;
    color: black;
    font-weight: bold;
    letter-spacing: .2em;
  }

  .subnav {
    position: relative;
    width: 100%;
    overflow: hidden;
    // background: white;
    transform-origin: top;
    z-index: 999;
    // border-left: 1px solid black;
    // border-right: 1px solid black;

    @media only screen and (min-width: 720px) {
      position: absolute;
    }

    .subnav-inner {
      background-color: white;
      display: flex;
      margin-left: -10px;
      margin-right: -10px;
      padding-left: 10px;
      padding-right: 10px;
    }

    svg {
      visibility: hidden;
      opacity: 0;
    }
    ul {
      flex: 1;
    }

    a {
      display: flex;
      height: 32px;
      align-items: center;

      span {
        font-size: .75rem;
        line-height: 1.5em;
      }
    }
  }

  hr {
    position: relative;
    z-index: 999;
  }

  &:first-child {
    &:before {
      left: 10px;
    }

    .subnav-inner {
      // border-left: none;
      margin-left: 0;
      padding-left: 0;
    }

    hr {
      margin-left: 10px;
    }
  }

  &:last-child {
    &:before {
      right: 10px;
    }

    .subnav-inner {
      // border-right: none;
      margin-right: 0;
      padding-right: 0;
    }
    
    hr {
      margin-right: 10px;
    }
  }
}

.en .navbar-item span{
  letter-spacing: 0;
}
</style>

<template>
  <div class="navbar-item" @mouseenter="_menter" @mouseleave="_mleave">
    <nuxt-link class="mainlink" :to="link">
      <category-icon :category="category"></category-icon>
      <span>{{title}}</span>
    </nuxt-link>
    <div class="row subnav-anchor">
      <transition :css="false"
                  @enter="_enter"
                  @leave="_leave">
        <div class="subnav col-xs-12" ref="subnav" v-if="showSubnav">
          <div class="subnav-inner">
            <category-icon :category="category"></category-icon>
            <ul class="list-unstyled" ref="subnavContent">
              <li v-for="item in sub">
                <nuxt-link :to="`/${$route.params.lang}${item.link}`" :class="{'disabled': item.hide}">
                  <span>{{isEn ? item.name_en : item.name_zh}}</span>
                </nuxt-link>
              </li>
            </ul>
          </div>
        </div>
      </transition>
    </div>
    <div class="row nav-bottom-line" ref="bottomLine">
      <hr>
    </div>
  </div>
</template>

<script>
import CategoryIcon from './CategoryIcon.vue'
import Velocity from 'velocity-animate-server'

export default {
  components: {
    CategoryIcon
  },
  props: {
    hidden: {
      type: Boolean,
      default: false
    },
    showSubnav: {
      type: Boolean,
      default: false
    },
    category: [String, Number],
    title: String,
    link: {
      type: String,
      default: '#'
    },
    sub: Array
  },
  data () {
    return {
      // showSubnav: false,
      subnavHeight: 0
    }
  },
  computed: {
    isEn () {
      return this.$route.params.lang === 'en'
    },
    mainlink () {
      if (this.link === '#') {
        return this.$route.path
      } else {
        return this.link
      }
    }
  },
  methods: {
    sublink (item) {
      if (this.link === 'baita_event') {
        return `/${this.link}#${item.name}`
      } else {
        return `/${this.link}/${item.name}`
      }
    },
    enter (el, done) {
      el.style.height = '0'

      Promise.all([
        Velocity(el, 'stop'),
        Velocity(el, {
          height: '54px'
        }, {
          duration: 200
          // delay: 300
        })
      ]).then(() => {
        el.style.height = 'auto'
        done()
      })
    },
    leave (el, done) {
      Promise.all([
        Velocity(el, 'stop'),
        Velocity(el, {
          height: '0'
        }, {
          duration: 200
          // delay: 300
        })
      ]).then(() => {
        el.style.height = '54px'
        done()
      })
    },
    _menter () {
      this.$emit('subnav:toggle', true)
    },
    _mleave () {
      this.$emit('subnav:toggle', false)
    },
    _enter (el, done) {
      this.subnavHeight = el.offsetHeight
      this.$refs.subnavContent.style.opacity = 0

      Promise.all([
        Velocity(el, 'stop'),
        Velocity(this.$refs.bottomLine, 'stop'),
        Velocity(this.$refs.subnavContent, 'stop'),
        Velocity(el, {
          // scaleY: [1, 0]
          height: [this.subnavHeight, 0]
        }, {
          duration: 300,
          easing: [0.645, 0.045, 0.355, 1]
        }),
        Velocity(this.$refs.bottomLine, {
          translateY: [`${window.innerWidth >= 720 ? this.subnavHeight : 0}px`, 0]
        }, {
          duration: 300,
          easing: [0.645, 0.045, 0.355, 1]
        }),
        Velocity(this.$refs.subnavContent, {
          opacity: [1, 0]
        }, {
          duration: 300,
          delay: 150
        })
      ]).then(done)
    },
    _leave (el, done) {
      Promise.all([
        Velocity(el, 'stop'),
        Velocity(this.$refs.bottomLine, 'stop'),
        Velocity(this.$refs.subnavContent, 'stop'),
        Velocity(this.$refs.subnavContent, {
          opacity: 0
        }, {
          duration: 300
        }),
        Velocity(el, {
          // scaleY: 0
          height: 0
        }, {
          duration: 300,
          easing: [0.645, 0.045, 0.355, 1],
          delay: 100
        }),
        Velocity(this.$refs.bottomLine, {
          translateY: [0, `${window.innerWidth >= 720 ? this.subnavHeight : 0}px`]
        }, {
          duration: 300,
          easing: [0.645, 0.045, 0.355, 1],
          delay: 100
        })
      ]).then(() => {
        this.$refs.bottomLine.style.transform = ''
        done()
      })
    }
  }
}
</script>
