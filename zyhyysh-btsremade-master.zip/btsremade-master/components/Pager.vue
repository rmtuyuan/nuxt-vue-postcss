<style lang="less">
.pager {
  display: flex;
  align-items: center;
  justify-content: center;

  .pager-inner {
    width: 320px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  button {
    width: 2.5rem;
    height: 2.5rem;
    border: 1px solid black;
    background: none;
    outline: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 .5rem;
    border-color: transparent;

    &.btn-page-prev .caret {
      transform: rotate(90deg) scale(1.5);
    }

    &.btn-page-next .caret {
      transform: rotate(-90deg) scale(1.5);
    }

    &:hover,
    &:active {
      border-color: black;
      cursor: pointer;
    }

    &:disabled {
      border-color: transparent;
      opacity: .1;
      cursor: not-allowed;
    }
  }

  input {
    -webkit-appearance: textfield;
    width: 2.5rem;
    height: 2.5rem;
    border: 1px solid black;
    background: white;
    outline: none;
    text-align: center;
    padding: 0;
    margin: 0 .5rem;

    &::-webkit-outer-spin-button,
    &::-webkit-inner-spin-button {
        /* display: none; <- Crashes Chrome on hover */
        -webkit-appearance: none;
        margin: 0; /* <-- Apparently some margin are still there even though it's hidden */
    }

    &.error {
      border-color: #ee0000;
    }
  }

  span {
    line-height: 2.5rem;
    margin: 0;
  }
}
</style>

<template>
  <div class="pager">
    <div class="pager-inner">
      <button class="btn-page-prev" :disabled="value === 1" @click="jump(-1)">
        <span class="caret"></span>
      </button>
      <div>
        <input :class="{'error': mValue <= 0 || mValue > max}" type="number" v-model="mValue" min="0" :max="max" @keypress.enter="vChange($event.target.value)" @blur="vChange($event.target.value)">
        <span class="total-page"> / {{max}}</span>
      </div>
      <button class="btn-page-next" :disabled="value === max" @click="jump(1)">
        <span class="caret"></span>
      </button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    value: Number,
    max: Number
  },
  data () {
    return {
      mValue: 0
    }
  },
  watch: {
    value (v, oldV) {
      console.log(v, oldV)
      this.mValue = this.value
      console.log(v, oldV, this.mValue)
    }
  },
  methods: {
    vChange (n) {
      const newValue = Number(n)
      console.log(newValue, this.max)
      if (newValue <= this.max && newValue > 0) {
        this.$emit('input', newValue)
      }
      this.mValue = 0
      this.$nextTick(() => {
        this.mValue = this.value
      })
    },
    jump (n) {
      const newValue = this.value + n
      this.vChange(newValue)
    }
  },
  mounted () {
    console.log('mounted')
    this.mValue = this.value
  },
  updated () {
    console.log('updated')
  }
}
</script>
