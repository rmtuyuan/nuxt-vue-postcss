<script>
export default {
  props: {
    content: {
      type: [String, Object],
      required: true
    },
    acceptTags: {
      type: Array,
      default: () => ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'img', 'b', 'font', 'i', 'ol', 'ul', 'li', 'a']
    },
    acceptAttrs: {
      type: Array,
      default: () => ['src', 'style', 'size', 'class', 'href']
    },
    ignoreClasses: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    jsonContent () {
      let obj = {node: 'root', child: []}
      if (typeof this.content === 'string') {
        const json = JSON || window.JSON

        try {
          obj = json.parse(this.content)
        } catch (e) {
          console.error('parse json error', e)
        }
      } else if ('tag' in this.content && 'child' in this.content) {
        obj = this.content
      }

      return obj
    },
    shouldIgnoreClasses () {
      return this.ignoreClasses.concat(['text-handle_list', 'paragraph'])
    }
  },
  render (createElement) {
    const self = this

    function convertAttr (attr, tag) {
      const isImg = tag === 'img'
      if (attr) {
        return self.acceptAttrs.reduce((obj, key) => {
          if (key in attr) {
            if (key === 'src' && isImg) {
              obj[key] = `${attr[key]}?x-oss-process=image/resize,w_1200`
            } else {
              obj[key] = attr[key]
            }
          }

          return obj
        }, {})
      } else {
        return {}
      }
    }

    function renderChildNodes (createElement, nodes, accept) {
      return nodes.reduce((l, n) => {
        if (n.node === 'text') {
          if (accept && 'text' in n && !n.text.match(/(请输入文本|undefined)/g)) {
            return l.concat([`${n.text}`])
          } else {
            return l
          }
        } else if (n.node === 'element') {
          if ('attr' in n && 'class' in n.attr && self.ignoreClasses.includes(n.attr.class)) {
            return l
          } else if (self.acceptTags.includes(n.tag)) {
            return l.concat([createElement(
              n.tag,
              { attrs: convertAttr(n.attr, n.tag) },
              'child' in n ? renderChildNodes(createElement, n.child, self.acceptTags.includes(n.tag)) : []
            )])
          } else if ('child' in n) {
            return l.concat(renderChildNodes(createElement, n.child, self.acceptTags.includes(n.tag)))
          } else {
            return l
          }
        } else {
          return l
        }
      }, [])
    }

    // function renderNode (createElement, node, isp) {
    //   console.log('renderNode', node.node)
    //   if (node.node === 'text') {
    //     /* 文字节点过滤后直接输出 */
    //     if (isp && 'text' in node && !node.text.match(/(请输入文本|undefined)/g)) {
    //       return `${node.text}`
    //     } else {
    //       return ''
    //     }
    //   } else if (node.node === 'root') {
    //     /* 根结点遍历递归子节点 */
    //     return node.child.map(c => {
    //       return renderNode(createElement, c, isp)
    //     })
    //   } else if (node.node === 'element') {
    //     /* 元素节点，判断是否需要显示节点 */
    //     if ('attr' in node && 'class' in node.attr && self.ignoreClasses.includes(node.attr.class)) {
    //       return ''
    //     }

    //     // let nodePrefix = ''
    //     // let nodeAffix = ''
    //     // let nodeChild = []

    //     // if (nodePrefix || acceptTags.includes(node.tag)) {
    //     //   nodePrefix = `<${node.tag} ${convertAttr(node.attr, node.tag === 'img')}>`
    //     //   nodeAffix = `</${node.tag}>`
    //     // }

    //     // if ('child' in node) {
    //     //   nodeChild = node.child.map(c => {
    //     //     return renderNode(createElement, c, true)
    //     //     // return renderNode(createElement, c, isp || self.acceptTags.includes(node.tag))
    //     //   })
    //     // }

    //     // return `${nodePrefix}${nodeChild}${nodeAffix}`
    //     if (isp) {
    //       return createElement(
    //         node.tag,
    //         { attrs: convertAttr(node.attr, node.tag === 'img') },
    //         // { attrs: node.attr },
    //         'child' in node ? node.child.map(c => renderNode(createElement, c, isp || self.acceptTags.includes(node.tag))) : [])
    //     } else {
    //       return 'child' in node ? node.child.map(c => renderNode(createElement, c, false)) : []
    //     }
    //   }
    // }

    const renderNodes = this.jsonContent.node === 'root' ? this.jsonContent.child : [this.jsonContent]

    return createElement(
      'article',
      {
        'class': 'g-article'
      },
      renderChildNodes(createElement, renderNodes, true)
    )
  }
}
</script>