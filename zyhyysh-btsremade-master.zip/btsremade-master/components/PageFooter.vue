<style lang="less">
.page-footer {
  padding: 72px 0;
  background: black;

  p {
    text-align: center;
    font-size: .875rem;
    color: #A4A4A4;

    @media only screen and (min-width: 767px) {
      text-align: right;
    }
  }

  p + p {
    font-size: .75rem;
    color: #A4A4A4;
    margin-top: 2rem;
  }

  .logo {
    margin-bottom: 50px;
  }

  .footer-c {
    text-align: center;
    @media only screen and (min-width: 767px) {
      text-align: left;
    }
  }
}
</style>

<template>
  <footer class="page-footer">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-6 footer-c">
          <logo tint="light"></logo>
        </div>
        <div class="col-xs-12 col-sm-6">
          <p>contact@btsremade.org<br>白塔寺再生计划微信公众号：baitasiproject</p>
          <p>FOLLOW ON WHCHAT FOR PROGRAM UPDATES!<br>Wechat:baitasiproject</p>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
import Logo from './Logo.vue'
export default {
  components: {
    Logo
  }
}
</script>