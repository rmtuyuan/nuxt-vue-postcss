# Stoyard 官网 2018 版

> 超屌哦😎

## Build Setup

``` bash
# install dependencies
$ npm install # Or yarn install

# serve with hot reload at localhost:3000
$ npm run dev

# build for production and launch server
$ npm run build
$ npm start

# generate static project
$ npm run generate
```

## 框架 & 插件说明

#### 服务端渲染
* [nuxt.js](https://github.com/nuxt/nuxt.js)

#### 网络请求
* [axios(@nuxt/proxy)](https://github.com/nuxt-community/axios-module)
* [@nuxt/proxy](https://github.com/nuxt-community/modules/tree/master/packages/proxy)

#### JS 动画
* [velocity](http://velocityjs.org) | 支持服务端渲染版本：velocity-animate-server

#### CSS 预处理
PostCSS 兼容 Less/Sass/Stylus 等，可以作为通用框架，按需添加其他插件
* 框架：[postcss](https://github.com/postcss/postcss)
* BEM：[postcss-bemed](https://github.com/Ximik/postcss-bemed)
* CSS4 语法、功能支持：[cssnext](http://cssnext.io)
* 缓动参数：[postcss-easings](https://github.com/postcss/postcss-easings)
* 工具库：[Tailwind](https://tailwindcss.com/docs/what-is-tailwind)
* [postcss-import](https://github.com/postcss/postcss-import)
* [postcss-mixins](https://github.com/postcss/postcss-mixins)
