<script>
  export default {}
</script>

<template>
  <div class="page-coding-style">
    <nav class="article-nav">
      <ol>
        <li>
          <a href="#模块化">模块化</a>
        </li>
      </ol>
    </nav>
    <article class="article-content">
      <h1>Stoyard 前端代码设计风格指南</h1>
      <h6>version 0.0.1-alpha</h6>

      
    </article>
  </div>
</template>

<style>
/*@import '~assets/style/media_vars.css';*/
@tailwind preflight;
@tailwind utilities;

:root {
  --color: #333;
}

.page-coding-style {
  color: var(--color);

  @apply .flex .flex-wrap;

  & .article-nav {
    /*lost-column: 1/4;

    @media (--mobile-screen) {
      lost-column: 1/3;
    }*/

    @apply .w-full;

    @screen sm {
      @apply .w-1/3 px-2;
    }
  }

  & .article-content {
    /*lost-column: 3/4;

    @media (--mobile-screen) {
      lost-column: 2/3;
    }*/
    @apply .w-full;

    @screen sm {
      @apply .w-2/3 px-2;
    }


    & :matches(h1, h2, h3, h4, h5, h6)[id]:before {
      content: '#';
      display: inline-block;
      width: 1em;
      margin-left: -1em;
      opacity: .3;
    }

    & blockquote {
      padding: 1rem;
      background-color: white;
      border-left: 1px solid config(colors.red-dark);
    }
  }
}
</style>