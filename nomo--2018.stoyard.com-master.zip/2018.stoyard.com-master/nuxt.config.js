const path = require('path')

module.exports = {
  /*
  ** Headers of the page
  */
  head: {
    title: 'Stoyard | 北京熙呈互动',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: 'Stoyard, G_Lab, 北京熙呈互动科技有限公司' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ]
  },
  /*
  ** Customize the progress bar color
  */
  loading: { color: '#000000' },
  /*
  ** Build configuration
  */
  build: {
    /*
    ** Run ESLint on save
    */
    extend (config, ctx) {
      if (ctx.dev && ctx.isClient) {
        config.module.rules.push({
          enforce: 'pre',
          test: /\.(js|vue)$/,
          loader: 'eslint-loader',
          exclude: /(node_modules)/
        })
      }
    },
    postcss: {
      plugins: {
        'tailwindcss': './tailwind.js',
        'postcss-bemed': {},
        'postcss-import': {
          resolve (id, basedir, importOptions) {
            if (id.split('/')[0] === '~') {
              return path.join(__dirname, id.slice(2))
            }

            return path.resolve(basedir, id)
          }
        },
        'postcss-mixins': {},
        'postcss-easings': {},
        'postcss-cssnext': {
          browsers: 'last 3 versions'
        }
        // 'lost': {},
      }
    }
  },
  /*
  ** 外部插件
  */
  vendor: ['velocity-animate-server'],
  /*
  ** 全局样式
  */
  css: [
    {
      src: '~assets/style/main.css', lang: 'postcss'
    }
  ],
  /*
  ** nuxt.js 模块
  */
  modules: [
    '@nuxtjs/proxy',
    '@nuxtjs/axios'
  ],
  /*
  ** 代理设置
  */
  // proxy: [
  //   'https://stoyard.com/api'
  // ]
  /*
  ** 网络请求设置
  */
  // axios: {
  //   baseURL: 'https://stoyard.com/api',
  //   browserBaseURL: '/api',
  //   credentials: false
  // }
}
